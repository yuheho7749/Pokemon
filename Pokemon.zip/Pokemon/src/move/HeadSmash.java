package move;

public class HeadSmash extends Move {
	
	public HeadSmash() {
		this.name = "HeadSmash";
		this.description = "The user attacks the target with a hazardous, full-power headbutt. This also damages the user terribly.";

		this.power = 150;
		this.accuracy = .8;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Rock";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}