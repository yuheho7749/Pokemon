package move;

public class Eruption extends Move {
	
	public Eruption() {
        this.name = "Eruption";
		this.description = "The user attacks opposing Pokemon with explosive fury.";

		this.power = 150;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fire";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
} 