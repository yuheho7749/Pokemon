package move;

public class RazorLeaf extends Move {
	
	public RazorLeaf() {
		this.name = "RazorLeaf";
		this.description = "Sharp-edged leaves are launched to slash at the opposing Pokémon. ";

		this.power = 85;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}