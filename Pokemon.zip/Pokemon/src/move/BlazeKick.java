package move;

public class BlazeKick extends Move {
	
	public BlazeKick() {
        this.name = "BlazeKick";
		this.description = "The user launches a kick that lands a critical hit more easily. This may also leave the target with a burn.";

		this.power = 85;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.1;
	}
}