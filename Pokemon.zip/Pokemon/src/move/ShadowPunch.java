package move;

public class ShadowPunch extends Move {
	
	public ShadowPunch() {
		this.name = "ShadowPunch";
		this.description = "The user throws a punch from the shadows. ";

		this.power = 69;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Ghost";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}