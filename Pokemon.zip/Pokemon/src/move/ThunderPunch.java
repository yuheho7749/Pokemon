package move;

public class ThunderPunch extends Move {
	
	public ThunderPunch() {
		this.name = "ThunderPunch";
		this.description = "The target is punched with an electrified fist. This may also leave the target with paralysis.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.1;
	}
}