package move;

public class BulletSeed extends Move {
	
	public BulletSeed() {
		this.name = "BulletSeed";
		this.description = "The user forcefully shoots seeds at the target, confusing them by doing so.";

		this.power = 25;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Grass";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}
}