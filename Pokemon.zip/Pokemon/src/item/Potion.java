	package item;
	import javafx.scene.image.ImageView;
	import main.*;
	import pokemon.*;


public class Potion extends Heal{
	
	

	
	public Potion(){
		super();
		name = "Potion";
		this.description = "Restores 20 HP.";
		healHealth = 20;
		healStatus ="None";
		cost = 300;
		sellPrice = 150;
	}
	public Potion(int q) {
		super(q);
		name = "Potion";
		this.description = "Restores 20 HP.";
		healHealth = 20;
		healStatus ="None";
		cost = 300;
		sellPrice = 150;
	}



}