package move;

public class DragonHammer extends Move {
	
	public DragonHammer() {
		this.name = "DragonHammer";
		this.description = "The user uses its body like a hammer to attack the target and inflict damage.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dragon";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}