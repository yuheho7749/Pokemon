/**
 * Defines the basic structure of a Map.
 * @author 
 * @version 1.00.00
 */

package map;

import main.*;
import character.*;
import tile.*;
import building.*;

import java.util.ArrayList;

import javafx.scene.layout.*;


abstract public class Map {
	protected String name;
	protected Pane body;
	protected ArrayList<Tile> tiles = new ArrayList<Tile>();
	protected double spawnX = 0, spawnY = 0; // spawn location in terms of the grid location not pixel location
	protected int width = 0, height = 0;

	public Map() {
		this.body = new Pane();
		this.body.setStyle("-fx-background-color: Tan;");
	}

	public String getName() {return this.name;}
	public Pane getBody() {return this.body;}
	public ArrayList<Tile> getTiles() {return this.tiles;}
	public double getCenterX() {return this.body.getLayoutX() + (this.body.getWidth()/2);}
	public double getCenterY() {return this.body.getLayoutY() + (this.body.getHeight()/2);}

	public void setName(String n) {this.name = n;}
	public void setBody(Pane p) {this.body = p;}
	public void setCenterX(double x) {this.body.setLayoutX(x - (this.body.getWidth()/2));}
	public void setCenterY(double y) {this.body.setLayoutY(y - (this.body.getHeight()/2));}
	public void setSpawnX(double x) {this.spawnX = x;}
	public void setSpawnY(double y) {this.spawnY = y;}

	public void moveRight(double spd) {
		this.body.setLayoutX(this.body.getLayoutX() - spd);
	}
	public void moveLeft(double spd) {
		this.body.setLayoutX(this.body.getLayoutX() + spd);
	}
	public void moveUp(double spd) {
		this.body.setLayoutY(this.body.getLayoutY() + spd);
	}
	public void moveDown(double spd) {
		this.body.setLayoutY(this.body.getLayoutY() - spd);
	}


	/**
	 * Adds the tile to the correct location on the map.
	 * @param tile the tile that is relocated
	 */
	public void addTile(Tile tile) {
		this.tiles.add(tile);
		this.body.getChildren().add(tile.getBody());
	}

	/**
	 * Adds the tile to the correct location on the map.
	 * @param tile the tile that is relocated
	 * @param x the x grid location (not pixel location)
	 * @param y the y grid location (not pixel location)
	 */
	public void setTile(Tile tile, int x , int y) {
		tile.getBody().setLayoutX(x * Entity.SCALEFACTOR);
		tile.getBody().setLayoutY(y * Entity.SCALEFACTOR);
		this.tiles.add(tile);
		this.body.getChildren().add(tile.getBody());
	}

	/**
	 * Adds a building to the correct location on the map.
	 * @param building the building that is relocated
	 * @param x the x grid location
	 * @param y the y grid location
	 */
	public void setBuilding(Building building, int x, int y) {
		building.setPosition(x, y);
		this.body.getChildren().add(building.getBody());
		for (Tile t : building.getTiles()) {
			this.addTile(t);
		}
		// this.body.getChildren().add(building.getBody());
	}

	/** 
	 * Sets the current map spawn point to the center of the screen.
	 * @param viewWidth the width of the screen
	 * @param viewHeight the height of the screen
	 */
	public void spawn(Player p, double viewWidth, double viewHeight) {
		double x = this.spawnX * Entity.SCALEFACTOR + Entity.SCALEFACTOR/2;
		double y = this.spawnY * Entity.SCALEFACTOR + Entity.SCALEFACTOR/2;

		this.body.setLayoutX(viewWidth/2 - x);
		this.body.setLayoutY(viewHeight/2 - y);

		p.getBody().setLayoutX(this.spawnX * Entity.SCALEFACTOR);
		p.getBody().setLayoutY(this.spawnY * Entity.SCALEFACTOR);

		this.body.getChildren().add(p.getBody());
	}

	/**
	 * Checks if the player collide with a barrier tile.
	 * @return true if the player collide with tile
	 */
	public boolean isCollideBarrier(Player p) {
		for (Tile t : this.tiles) {
			if (t instanceof Barrier && ((Barrier)t).getHasCollision() &&
				t.getBody().getLayoutX() == p.getBody().getLayoutX() &&
				t.getBody().getLayoutY() == p.getBody().getLayoutY()) { // need to test this way cuz the pane are too close and will "always collide"
				return true;
			}
		}
		return false;
	}

}