/**
 * Defines the basic structure for the battle map layouts.
 * @author
 * @version 1.00.00
 */

package battlemap;

import main.*;
import pokemon.*;
import item.*;
import character.*;
import move.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.paint.*;

public class BattleMap {
	protected Pane body;
	protected int turnCount = 0;
	protected Trainer[] trainers = new Trainer[2]; // the two trainers battling
	protected Pokemons[] activePokemons = new Pokemons[2]; // the two pokemon in battle
	protected PokemonSummary[] battleSummary = new PokemonSummary[2]; // health etc of the active pokemon
	
	Pane p1;
	Pane p2;
	Pane s1;
	Pane s2;

	public BattleMap(double viewWidth, double viewHeight) {
		this.body = new Pane();
		this.body.setPrefSize(viewWidth, viewHeight);

		
		
		
		// for testing
		body.setStyle("-fx-background-color: pink;");
		//body.setOpacity(.5);
		
	}

	public Pane getBody() {return this.body;}

	/**
	 * Sets the two trainers in battle.
	 * @param p1 the first trainer (the player)
	 * @param p2 the second trainer (computer)
	 */
	public void setTrainers(Trainer p1, Trainer p2) {
		this.trainers[0] = p1;
		this.trainers[1] = p2;
		this.activePokemons[0] = this.trainers[0].getParty().get(0);
		this.activePokemons[1] = this.trainers[1].getParty().get(1);
		battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
		battleSummary[1] = new PokemonSummary(this.activePokemons[1]);
		
	}

	/**
	 * Sets the trainer and wild pokemon battle.
	 * @param p1 the player
	 * @param pokemon the wild pokemon
	 */
	public void setWildPokemon(Trainer p1, Pokemons pokemon) {
		this.trainers[0] = p1;
		this.activePokemons[0] = this.trainers[0].getParty().get(0);
		this.activePokemons[1] = pokemon;
		battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
		battleSummary[1] = new PokemonSummary(this.activePokemons[1]);
	}

	/**
	 * Switches the trainer's active pokemon if the trainer owns the pokemon.
	 * @param p the trainer
	 * @param ps the pokemon
	 * @return true if the swap is successful
	 *
	 
	 CURRENTLY ERRORS 
	 
	public boolean swapActivePokemon(Trainer p, Pokemon ps) {
		for (int i = 0; i < this.trainers.length; i ++) {
			if (p.getId() == t[i].getId()) {
				for (Pokemon pokemon : p.getParty()) {
					if (pokemon.getId() == ps.getId()) {
						activePokemons[i] = p;
						// don't forget to switch body.getChildren()...
					}
				}
			}
		}
	}
	*/

	public void takeTurn(Move move) {
		
	// 	if (this.turnCount % this.trainers.length == 0) {
	// 		this.turnCount = 0;
	// 	}
	
	// //	Move moveSelected = this.trainers[this.turnCount].takeTurn();
	// //		Take turn must send parameter

	// 	//damage calculations here

	// 	this.turnCount ++;
	}
	
	public Pane generateBody(){
		p1 = activePokemons[0].getBattleSprite();
		p2 = activePokemons[1].getBattleSprite();
		s1 = battleSummary[0].getSummary();
		s2 = battleSummary[1].getSummary();
		body.getChildren().addAll(p1,p2,s1,s2);
		activePokemons[0].getBattleSprite().setLayoutX(200);
		activePokemons[0].getBattleSprite().setLayoutY(450);
		activePokemons[1].getBattleSprite().setLayoutX(600);
		activePokemons[1].getBattleSprite().setLayoutY(150);
		s1.setLayoutX(530);
		s1.setLayoutY(390);
		s2.setLayoutX(10);
		s2.setLayoutY(10);
		return body;
	}
	
	public void updateInfo(){
		battleSummary[0].updateHealth(); 
		battleSummary[1].updateHealth();
	}

}