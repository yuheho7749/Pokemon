package move;

public class DragonBreath extends Move {
	
	public DragonBreath() {
		this.name = "DragonBreath";
		this.description = "The user exhales a mighty gust that inflicts damage. This may also leave the target with paralysis.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Dragon";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.35;
	}
}