package move;

public class WaterShuriken extends Move {
	
	public WaterShuriken() {
        this.name = "WaterShuriken";
		this.description = "The user launches a barrage of throwing stars at the target. This move always goes first.";
        this.priority = true;

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}