/**
 * Defines the dialogue for healing party of pokemon.
 * @author
 * @version 1.00.00
 */

package character;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class HealingDialogue extends Dialogue{
	

	public HealingDialogue() {
		super();
		this.message.add("Welcome to the Pokemon Center.");
		this.message.add("We will heal your Pokemon back to full health.");
		this.message.add("Shall we heal your Pokemon?");
		this.message.add("I will heal your Pokemon whether you like it or not since the declining option has not been implemented yet.");
		this.message.add("If you have anything to say about it, talk to the hand!");
		this.message.add("Ok! We'll need your Pokemon, so hand it over, NOW!");
		this.message.add("Oops, I meant to say it nicely.");
		this.message.add("Thank you! We have stolen and uploaded all your Pokemon's info into our database ... um ... I mean I have fully healed your Pokemon.");
		this.message.add("We hope to see you again!");
		

	}

}