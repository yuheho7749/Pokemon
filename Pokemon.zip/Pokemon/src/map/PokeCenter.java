/**
 * Defines the Pokemon Center.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class PokeCenter extends Map {
	public PokeCenter() {
		super();
		this.name = "PokeCenter";
		this.width = 11;
		this.height = 9;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);
		// this.body.setStyle("-fx-background-color: Tan;");


		// temp background
		StackPane pokeballDesign = new StackPane();
		pokeballDesign.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR * .8);
		Circle ball = new Circle(Entity.SCALEFACTOR * 1.5);
		ball.setFill(Color.RED);
		Rectangle strip = new Rectangle(Entity.SCALEFACTOR * 3, Entity.SCALEFACTOR);
		strip.setFill(Color.WHITE);
		Circle button = new Circle(Entity.SCALEFACTOR * .5);
		button.setFill(Color.GRAY);
		pokeballDesign.getChildren().addAll(ball, strip, button);
		this.body.getChildren().add(pokeballDesign);



		// creates the tiles
		this.setTile(new WarpTile("PalletTown", 28, 8), 5, 8);

		this.setTile(new PCTile(), 0, 0);

		this.setTile(new HealTile(), 5, 0);

		for (int i = 0; i < width; i ++) {
			if (i == 5) {continue;}
			this.setTile(new VoidBarrier(), i , 8);
		}
	}
}