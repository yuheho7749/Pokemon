package move;

public class Extrasensory extends Move {
	
	public Extrasensory() {
		this.name = "Extrasensory";
		this.description = "	The user attacks with an odd, unseeable power. This may also make the target flinch.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Psychic";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}