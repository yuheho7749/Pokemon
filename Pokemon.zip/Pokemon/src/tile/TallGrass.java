/**
 * Defines the tall grass.
 * @author
 * @version 1.00.00
 */

package tile;

import character.*;
import main.*;
import pokemon.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

public class TallGrass extends Tile {
	private double encounterChance = 0.1;
	private Pokemons[] availablePokemon = new Pokemons[] {new Pikachu()}; // set default pokemon to something later

	public TallGrass() {
		super();
		this.name = "TallGrass";

		// Pane design = new Pane();
		// Rectangle grass = new Rectangle(Entity.SCALEFACTOR * .9, Entity.SCALEFACTOR * .9);
		// grass.setX(Entity.SCALEFACTOR * .05);
		// grass.setY(Entity.SCALEFACTOR * .05);
		// grass.setFill(Color.rgb(0, 175, 0));
		// design.getChildren().addAll(grass);

		ImageView image = new ImageView("file:res/tile/TallGrass.png");
		image.setFitWidth(Entity.SCALEFACTOR);
		image.setFitHeight(Entity.SCALEFACTOR);
		image.setCache(true);

		this.body.getChildren().addAll(image);

		this.labelSelf(); // just for testing purposes


	}

	public double getEncounterChance() {return this.encounterChance;}

	public Pokemons getRandomPokemon() {
		return this.availablePokemon[(int)(Math.random() * this.availablePokemon.length)];
	}

	public void setEncounterChance(double ec) {this.encounterChance = ec;}

	public void setAvailablePokemon(Pokemons[] p) {this.availablePokemon = p;} 

	@Override
	public boolean tileEffect(Player p) {
		if (Math.random() < this.encounterChance) {
			System.out.println("Wild Pokemon encountered");
			return true;
		}
		return false;
	}

}