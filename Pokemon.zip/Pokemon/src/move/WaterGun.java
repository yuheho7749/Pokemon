package move;

public class WaterGun extends Move {
	
	public WaterGun() {
		super();
		this.name = "WaterGun";
		this.description = "The target is blasted with a forceful shot of water.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 25;
		this.maxPP = 25;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}