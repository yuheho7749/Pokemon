package move;

public class TailWhip extends Move {
	
	public TailWhip() {
		super();
		this.name = "TailWhip";
		this.description = "The user wags its tail cutely, making opposing Pokemon less wary and lowering their Defense stat.";

		this.power = 0;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		
		this.pp = 30;
		this.maxPP = 30;

		this.type = "Normal";
		this.statusEffect = "DefenseDown1";
		this.statusChance = 1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}