package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Machamp extends Pokemons{
	
	public Machamp(){
		super();
		this.name = "Machamp";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Fighting";
		this.type[1] = "Nope";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 90;this.bAtk = 130;this.bDef = 80;
        this.bSpAtk = 65;this.bSpDef = 85;this.bSpd = 55;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/machamp.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/machamp.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/machamp.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	public void update(){}
}

