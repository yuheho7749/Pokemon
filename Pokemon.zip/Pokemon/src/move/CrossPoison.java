package move;

public class CrossPoison extends Move {
	
	public CrossPoison() {
		this.name = "CrossPoison";
		this.description = "A slashing attack with a poisonous blade that may also poison the target. ";

		this.power = 70;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.2;
	}
}