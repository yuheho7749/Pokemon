package move;

public class DizzyPunch extends Move {
	
	public DizzyPunch() {
		super();
		this.name = "DizzyPunch";
		this.description = "The target is hit with rhythmically launched punches that may also leave it confused.";

		this.power = 70;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Normal";
		this.statusEffect = "Confused";
		this.statusChance = .2;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}