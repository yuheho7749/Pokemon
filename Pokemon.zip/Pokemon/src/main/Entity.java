/**
 * Defines the basic structure of an object inside our world of Pokemon.
 * 		Note: Every class will inherit this
 * @author 
 * @version 1.00.00
 */

package main;

import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.util.*;
import javafx.geometry.*;

abstract public class Entity {
	public static int SCALEFACTOR = 60; // (Played at 60, map testing at 20, but must be multiple of 4 regardless) (updated to not final)
	public static boolean enableHitBox = false; // for debugging only
	public Pane body;

	public Entity() {
		this.body = new Pane();
		this.body.setStyle("-fx-background-color: Transparent;");
		if (enableHitBox){
			this.body.setStyle("-fx-border-color: Black; -fx-border-width: 1px;");
		}
		this.body.setPrefSize(SCALEFACTOR, SCALEFACTOR);
	}

	public Pane getBody() {return this.body;}

	public void setBody(Pane b) {this.body = b;}

}