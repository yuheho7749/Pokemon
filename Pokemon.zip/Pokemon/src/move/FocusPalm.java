package move;

public class FocusPalm extends Move {
	
	public FocusPalm() {
		this.name = "FocusPalm";
		this.description = "The target is attacked with a shock wave. This may also leave the target with paralysis.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fighting";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.2;
	}
}