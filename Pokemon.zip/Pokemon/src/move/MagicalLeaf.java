package move;

public class MagicalLeaf extends Move {
	
	public MagicalLeaf() {
		this.name = "MagicalLeaf";
		this.description = "	The user scatters curious leaves that chase the target. This attack always go first.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = true;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}