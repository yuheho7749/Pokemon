package move;

public class PsychoBoost extends Move {
	
	public PsychoBoost() {
		this.name = "PsychoBoost";
		this.description = "	The user attacks the target at full power. The attack's recoil harshly lowers the user's health.";

		this.power = 140;
		this.accuracy = .9;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Psychic";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}