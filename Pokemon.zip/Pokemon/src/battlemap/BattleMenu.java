/**
 * Defines the basic structure of a "pop-up" menu in the battle scene.
 * @author
 * @version 1.00.00
 */

package battlemap;

import main.*;
import pokemon.*;
import move.*;

import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.shape.*;

public class BattleMenu {
 	protected Pane body;
 	protected Pane movesBody;
 	protected Pokemons currentPokemon;
 	private double width;
 	private double height;
 	private int selectionPosition = 0;
 	private int moveSelectionPosition=0;
 	private Pane cursor;
 	private Pane moveCursor;
 	private boolean fighting = false;
 	
 	
 	public BattleMenu(double viewWidth,double viewHeight,Pokemons p) {
 		currentPokemon = p;
		width = viewWidth;
		height = viewHeight;
		
		this.generateMovesBody();
		this.generateMoveBody();		
 	}
 	
 	public Pane getBody(){return body;}
 	public Pane getMovesBody(){return movesBody;}
 	public void setCurrentPokemon(Pokemons p){currentPokemon = p;}
 	public void setFighting(boolean b) {this.fighting = b;}
 	public boolean getFighting() {return this.fighting;}
 	
 	
 	public Pane generateMoveBody(){
		this.body = new Pane();
 		body.setStyle("-fx-background-color:blue;");
		this.body.setPrefSize(width, height);
		//body.setLayoutX(0);
		//body.setLayoutY(height);
		
		StackPane fightButton = new StackPane();
		fightButton.setPrefSize(width/4,height);
		fightButton.setStyle("-fx-background-color:red;");
		Text fight = new Text("Fight");
		fight.setFont(new Font(Game.VIEW_HEIGHT/20));
		fight.setTextAlignment(TextAlignment.CENTER);
		fightButton.getChildren().add(fight);
		
		StackPane runButton = new StackPane();
		runButton.setPrefSize(width/4,height);
		runButton.setLayoutX(width/4);
		runButton.setStyle("-fx-background-color:orange;");
		Text run = new Text("Run");
		run.setFont(new Font(Game.VIEW_HEIGHT/20));
		run.setTextAlignment(TextAlignment.CENTER);
		runButton.getChildren().add(run);
		
		StackPane pokemonsButton = new StackPane();
		pokemonsButton.setPrefSize(width/4,height);
		pokemonsButton.setLayoutX(width/2);
		pokemonsButton.setStyle("-fx-background-color:green;");
		Text pokemons = new Text("Pokemons");
		pokemons.setFont(new Font(Game.VIEW_HEIGHT/20));
		pokemons.setTextAlignment(TextAlignment.CENTER);
		pokemonsButton.getChildren().add(pokemons);
		
		StackPane bagsButton = new StackPane();
		bagsButton.setPrefSize(width/4,height);
		bagsButton.setLayoutX(width*.75);
		bagsButton.setStyle("-fx-background-color:blue;");
		Text bag = new Text("Bags");
		bag.setFont(new Font(Game.VIEW_HEIGHT/20));
		bag.setTextAlignment(TextAlignment.CENTER);
		bagsButton.getChildren().add(bag);
		
		
		body.getChildren().addAll(fightButton,runButton,pokemonsButton,bagsButton,createCursor());
		
		return body;
	}
	
	public Pane generateMovesBody(){
		this.movesBody = new Pane();
 		movesBody.setStyle("-fx-background-color:pink;");
		this.movesBody.setPrefSize(width, height);
		//movesBody.setLayoutX(0);
		//movesBody.setLayoutY(height);
		
		StackPane move1 = new StackPane();
		move1.setPrefSize(width/4,height);
		move1.setStyle("-fx-background-color:lime;");
		Text moveName1 = new Text(currentPokemon.getMoveSet()[1].getName());
		moveName1.setFont(new Font(Game.VIEW_HEIGHT/20));
		moveName1.setTextAlignment(TextAlignment.CENTER);
		move1.getChildren().add(moveName1);
		
		StackPane move2 = new StackPane();
		move2.setPrefSize(width/4,height);
		move2.setLayoutX(width/4);
		move2.setStyle("-fx-background-color:salmon;");
		Text moveName2 = new Text(currentPokemon.getMoveSet()[2].getName());
		moveName2.setFont(new Font(Game.VIEW_HEIGHT/20));
		moveName2.setTextAlignment(TextAlignment.CENTER);
		move2.getChildren().add(moveName2);
		
		StackPane move3 = new StackPane();
		move3.setPrefSize(width/4,height);
		move3.setLayoutX(width/2);
		move3.setStyle("-fx-background-color:maroon;");
		Text moveName3 = new Text(currentPokemon.getMoveSet()[3].getName());
		moveName3.setFont(new Font(Game.VIEW_HEIGHT/20));
		moveName3.setTextAlignment(TextAlignment.CENTER);
		move3.getChildren().add(moveName3);
		
		StackPane move4 = new StackPane();
		move4.setPrefSize(width/4,height);
		move4.setLayoutX(width*.75);
		move4.setStyle("-fx-background-color:gray;");
		Text moveName4 = new Text(currentPokemon.getMoveSet()[4].getName());
		moveName4.setFont(new Font(Game.VIEW_HEIGHT/20));
		moveName4.setTextAlignment(TextAlignment.CENTER);
		move4.getChildren().add(moveName4);
		
		
		movesBody.getChildren().addAll(move1,move2,move3,move4,createMoveCursor());
		
		return movesBody;
	}
	
	/*
	Not used
	public Pane generateBackButton(){
		body = new Pane();
		this.body = new Pane();
 		body.setStyle("-fx-background-color:blue;");
		this.body.setPrefSize(width, height);
		body.setLayoutX(0);
		body.setLayoutY(height);
		
		StackPane backButton = new StackPane();
		backButton.setPrefSize(width/4,height);
		backButton.setStyle("-fx-background-color:green;");
		Text back = new Text("Back");
		back.setFont(new Font(20));
		back.setTextAlignment(TextAlignment.CENTER);
		backButton.getChildren().add(back);
		
		
		body.getChildren().addAll(backButton);
		
		return body;
	}
	*/
	private Pane createCursor(){
		cursor = new Pane();
		cursor.setPrefSize(width/4,height);
		cursor.setLayoutX(0);
		Rectangle rec1 = new Rectangle(5,5,10,50);
		Rectangle rec2 = new Rectangle(5,5,50,10);
		Rectangle rec3 = new Rectangle((width/4)-15,5,10,50);
		Rectangle rec4 = new Rectangle((width/4)-55,5,50,10);
		Rectangle rec5 = new Rectangle(5,height-55,10,50);
		Rectangle rec6 = new Rectangle(5,height-15,50,10);
		Rectangle rec7 = new Rectangle((width/4)-15,height-55,10,50);
		Rectangle rec8 = new Rectangle((width/4)-55,height-15,50,10);
		
		
		cursor.getChildren().addAll(rec1,rec2,rec3,rec4,rec5,rec6,rec7,rec8);
		return cursor;
	}
	
	
	private Pane createMoveCursor(){
		moveCursor = new Pane();
		moveCursor.setPrefSize(width/4,height);
		moveCursor.setLayoutX(0);
		Rectangle rec1 = new Rectangle(5,5,10,50);
		Rectangle rec2 = new Rectangle(5,5,50,10);
		Rectangle rec3 = new Rectangle((width/4)-15,5,10,50);
		Rectangle rec4 = new Rectangle((width/4)-55,5,50,10);
		Rectangle rec5 = new Rectangle(5,height-55,10,50);
		Rectangle rec6 = new Rectangle(5,height-15,50,10);
		Rectangle rec7 = new Rectangle((width/4)-15,height-55,10,50);
		Rectangle rec8 = new Rectangle((width/4)-55,height-15,50,10);
		
		
		moveCursor.getChildren().addAll(rec1,rec2,rec3,rec4,rec5,rec6,rec7,rec8);
		return moveCursor;
	}
	public void moveRight() {
		this.selectionPosition ++;
		if (selectionPosition > 3) {
			this.selectionPosition = 0;
			cursor.setLayoutX(0);
		} else {
			cursor.setLayoutX(cursor.getLayoutX() + width/4);
		}
		
	
	}
	
	public void moveLeft() {
		this.selectionPosition --;
		if (selectionPosition < 0) {
			this.selectionPosition = 3;
			cursor.setLayoutX((3*width)/4);
		} else {
			cursor.setLayoutX(cursor.getLayoutX() - width/4);
		}
	
	
	}
	
	public void moveMoveRight() {
		this.moveSelectionPosition ++;
		if (moveSelectionPosition > 3) {
			this.moveSelectionPosition = 0;
			moveCursor.setLayoutX(0);
		} else {
			moveCursor.setLayoutX(moveCursor.getLayoutX() + width/4);
		}
		
	
	}
	
	public void moveMoveLeft() {
		this.moveSelectionPosition --;
		if (moveSelectionPosition < 0) {
			this.moveSelectionPosition = 3;
			moveCursor.setLayoutX((3*width)/4);
		} else {
			moveCursor.setLayoutX(moveCursor.getLayoutX() - width/4);
		}
	
	
	}
	
	public Move useMove() {
		return this.currentPokemon.useMove(moveSelectionPosition + 1); // because first move is struggle
	}
	
	
	public int getSelectionPosition() {return this.selectionPosition;}
	public int getMoveSelectionPosition() {return this.moveSelectionPosition;}
	
}


