package move;

public class Sludge extends Move {
	
	public Sludge() {
		this.name = "Sludge";
		this.description = "Unsanitary sludge is hurled at the target. This may also poison the target.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.3;
	}
}