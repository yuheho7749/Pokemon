/**
 * Defines the dialogue for losing the game.
 * @author
 * @version 1.00.00
 */

package character;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class LoseDialogue extends Dialogue{
	

	public LoseDialogue() {
		super();
		this.textSpeed = Dialogue.SLOW_TEXT_SPEED;

		this.message.add("A wild Pokemon appeared, but you are out of Pokemon!");
		this.message.add("You lose...");
		this.message.add("...as in you life...");
		this.message.add("Good bye!");
		

		
		

	}

}