package move;

public class Hypnosis extends Move {
	
	public Hypnosis() {
		this.name = "Hypnosis";
		this.description = "The user employs hypnotic suggestion to make the target fall into a deep sleep.";

		this.power = 0;
		this.accuracy = .6;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Psychic";
		this.statusEffect = "Slept";
		this.statusChance = 0;
	}
}