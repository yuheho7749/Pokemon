package move;

public class FlashCannon extends Move {
	
	public FlashCannon() {
		this.name = "FlashCannon";
		this.description = "The user gathers all its light energy and releases it all at once.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Steel";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}