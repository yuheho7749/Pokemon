package move;

public class JumpKick extends Move {
	
	public JumpKick() {
		this.name = "JumpKick";
		this.description = "The user jumps up high, then strikes with a kick.";

		this.power = 100;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}