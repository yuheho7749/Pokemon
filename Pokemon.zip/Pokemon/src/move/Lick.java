package move;

public class Lick extends Move {
	
	public Lick() {
		this.name = "Lick";
		this.description = "	The target is licked with a long tongue, causing damage. This may also leave the target with paralysis.";

		this.power = 30;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Ghost";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.3;
	}
}