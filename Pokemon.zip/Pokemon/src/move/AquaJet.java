package move;

public class AquaJet extends Move {
	
	public AquaJet() {
		this.name = "AquaJet";
		this.description = "The user lunges at the target at a speed that makes it almost invisible. This move always goes first.";
		this.priority = true;

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}