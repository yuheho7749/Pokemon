package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.image.*;

public class Froakie extends Pokemons{
	
	public Froakie(){
		this.name = "Froakie";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Water";
		body.getChildren().add(new Circle(100,Color.BLUE));
		this.moveSet[0] = new Struggle();
		
		//set base stats of Pokemon
		this.bHp = 41;this.bAtk = 56;this.bDef = 40;this.bSpDef = 44;this.bSpAtk = 62;this.bSpd = 71;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		
		this.moveSet[1] = new Tackle();
		this.moveSet[2] = new TailWhip();
		this.moveSet[3] = new QuickAttack();
		this.moveSet[4] = new WaterGun();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

