package move;

public class IcicleCrash extends Move {
	
	public IcicleCrash() {
		this.name = "IcicleCrash";
		this.description = "The user attacks by harshly dropping large icicles onto the target. This may also make the target flinch.";

		this.power = 85;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ice";
		this.statusEffect = "Flinched";
		this.statusChance = 0.2;
	}
}