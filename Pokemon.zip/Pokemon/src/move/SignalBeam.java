package move;

public class SignalBeam extends Move {
	
	public SignalBeam() {
		this.name = "SignalBeam";
		this.description = "The user attacks with a sinister beam of light. This may also confuse the target.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Bug";
		this.statusEffect = "Confused";
		this.statusChance = 0.3;
	}
}