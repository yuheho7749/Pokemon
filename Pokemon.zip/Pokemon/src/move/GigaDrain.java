package move;

public class GigaDrain extends Move {
	
	public GigaDrain() {
		this.name = "GigaDrain";
		this.description = "	A harsh attack that absorbs the target's life force to restore HP.";

		this.power = 95;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 1;
	}
}