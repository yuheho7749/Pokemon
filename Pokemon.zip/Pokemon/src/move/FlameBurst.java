package move;

public class FlameBurst extends Move {
	
	public FlameBurst() {
        this.name = "FlameBurst";
		this.description = "The user attacks the target with a bursting flame.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
} 