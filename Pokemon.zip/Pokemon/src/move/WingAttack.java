package move;

public class WingAttack extends Move {
	
	public WingAttack() {
		this.name = "WingAttack";
		this.description = "	The target is struck with large, imposing wings spread wide to inflict damage.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 35;
		this.maxPP = 35;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}