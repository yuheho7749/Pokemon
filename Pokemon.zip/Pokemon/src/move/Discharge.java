package move;

public class Discharge extends Move {
	
	public Discharge() {
		this.name = "Discharge";
		this.description = "The user strikes everything around it by letting loose a flare of electricity. This may also cause paralysis.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.1;
	}

}