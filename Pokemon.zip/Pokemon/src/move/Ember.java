package move;

public class Ember extends Move {
	
	public Ember() {
		super();
		this.name = "Ember";
		this.description = "The target is attacked with small flames. It may also leave the target with a burn.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 25;
		this.maxPP = 25;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}