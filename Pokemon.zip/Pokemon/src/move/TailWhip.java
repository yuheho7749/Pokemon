package move;

public class TailWhip extends Move {
	
	public TailWhip() {
		super();
		this.name = "TailWhip";
		this.description = "The user wags its tail cutely, making opposing Pokemon less wary and confuse them in the process.";

		this.power = 0;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		this.priority = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Normal";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}