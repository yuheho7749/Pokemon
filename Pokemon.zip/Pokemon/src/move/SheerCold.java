package move;

public class SheerCold extends Move {
	
	public SheerCold() {
		this.name = "SheerCold";
		this.description = "The target is attacked with a blast of absolute-zero cold. The target instantly faints if it hits.";

		this.power = 999999;
		this.accuracy = .3;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Ice";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}