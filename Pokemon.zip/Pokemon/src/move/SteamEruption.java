package move;

public class SteamEruption extends Move {
	
	public SteamEruption() {
        this.name = "SteamEruption";
		this.description = "The user immerses the target in superheated steam. This may also leave the target with a burn.";

		this.power = 110;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Water";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
}