package move;

public class VacuumWave extends Move {
	
	public VacuumWave() {
		this.name = "VacuumWave";
		this.description = "The user whirls its fists to send a wave of pure vacuum at the target. This move always goes first.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}