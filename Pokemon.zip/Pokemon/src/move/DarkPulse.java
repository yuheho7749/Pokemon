package move;

public class DarkPulse extends Move {
	
	public DarkPulse() {
		this.name = "DarkPulse";
		this.description = "The user releases a horrible aura imbued with dark thoughts. This may also make the target flinch.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dark";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}