package move;

public class WillOWisp extends Move {
	
	public WillOWisp() {
		this.name = "WillOWisp";
		this.description = "The user shoots a sinister, bluish-white flame at the target to inflict a burn.";

		this.power = 0;
		this.accuracy = 0.85;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		
		this.pp = 14;
		this.maxPP = 14;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 1;
	}
}