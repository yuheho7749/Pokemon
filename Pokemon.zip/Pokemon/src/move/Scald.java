package move;

public class Scald extends Move {
	
	public Scald() {
        this.name = "Scald";
		this.description = "The user shoots boiling hot water at its target. This may also leave the target with a burn.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Water";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
}