package move;

public class TakeDown extends Move {
	
	public TakeDown() {
		super();
		this.name = "TakeDown";
		this.description = "A physical attack in which the user charges and slams into the target with its whole body.";

		this.power = 90;
		this.accuracy = 0.85;
		this.recoil = 0.25;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}