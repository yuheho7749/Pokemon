package move;

public class Absorb extends Move {
	
	public Absorb() {
		this.name = "Absorb";
		this.description = "	A nutrient-draining attack. The user restore its HP afterwards.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 1;
	}
}