package move;

public class Tackle extends Move {
	
	public Tackle() {
		super();
		this.name = "Tackle";
		this.description = "A physical attack in which the user charges and slams into the target with its whole body.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 35;
		this.maxPP = 35;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}