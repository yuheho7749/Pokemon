package move;

public class Hurricane extends Move {
	
	public Hurricane() {
		this.name = "Hurricane";
		this.description = "The user attacks by wrapping its opponent in a fierce wind that flies up into the sky. This may also confuse the target.";

		this.power = 110;
		this.accuracy = .7;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Flying";
		this.statusEffect = "Confused";
		this.statusChance = 0.3;
	}
}