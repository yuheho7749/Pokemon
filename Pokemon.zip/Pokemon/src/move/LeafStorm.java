package move;

public class LeafStorm extends Move {
	
	public LeafStorm() {
		this.name = "LeafStorm";
		this.description = "The user whips up a storm of leaves around the target while taking harsh damage.";

		this.power = 130;
		this.accuracy = .9;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}