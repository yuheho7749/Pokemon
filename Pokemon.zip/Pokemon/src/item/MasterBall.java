/**
 * Defines a pokeball.
 * @author
 * @version 1.00.00
 */

package item;

import main.*;
import pokemon.*;


public class MasterBall extends PokeBall {
	

	public MasterBall() {
		super();
		name = "Master Ball";
		this.description = "A ball that catches all pokemon without fail.";
		successRate = 1;
	}

	public MasterBall(int q) {
		super(q);
		name = "Master Ball";
		this.description = "A ball that catches all pokemon without fail.";
		successRate = 1;
	}




}