/**
 * Defines the map for Pallet Town.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class PalletTown extends Map {
	public PalletTown() {
		super();
		this.name = "PalletTown";
		this.width = 42;
		this.height = 32;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);
		this.body.setStyle("-fx-background-color: Lightgreen;");

		// must make background image first
		ImageView background = new ImageView("file:res/map/PalletTownTest.png");
		background.setFitWidth(width * Entity.SCALEFACTOR);
		background.setFitHeight(height * Entity.SCALEFACTOR);
		background.setCache(true);
		this.body.getChildren().add(background);



		// creates the tiles and buildings
		this.setTile(new WarpTile("Route1", 12, 39), this.width/2 - 1, 0);
		this.setTile(new WarpTile("Route1", 13, 39), this.width/2, 0);
		


		// add home building here
		HomeBuilding homeBuilding = new HomeBuilding();
		homeBuilding.setTile(new WarpTile("Home", 4, 7), 2, 2);
		this.setBuilding(homeBuilding, 27, 18);


		// testing PokeCenter
		PokeCenterBuilding pokeCenterBuilding = new PokeCenterBuilding();
		pokeCenterBuilding.setTile(new WarpTile("PokeCenterPalletTown", 5, 8), 3, 4);
		this.setBuilding(pokeCenterBuilding, 25, 4);



		// adding trees
		for (int i = 0; i < this.width; i += 2) {
			if (i == 20) {i += 2;}
			BigTree tree = new BigTree();
			this.setBuilding(tree, i , 0);
		}
		for (int i = 0; i < this.width; i += 2) {
			BigTree tree = new BigTree();
			this.setBuilding(tree, i , this.height - 2);
		}
		for (int i = 2; i < this.height; i += 2) {
			BigTree tree = new BigTree();
			this.setBuilding(tree, 0, i);
		}
		for (int i = 2; i < this.height; i += 2) {
			BigTree tree = new BigTree();
			this.setBuilding(tree, this.width - 2, i);
		}



		

	}
}