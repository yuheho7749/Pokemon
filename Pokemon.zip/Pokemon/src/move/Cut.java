package move;

public class Cut extends Move {
	
	public Cut() {
		super();
		this.name = "Cut";
		this.description = "The target is cut with a scythe or a claw. It can also be used to cut down thin trees.";

		this.power = 50;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 30;
		this.maxPP = 30;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}