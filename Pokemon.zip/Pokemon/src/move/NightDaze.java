package move;

public class NightDaze extends Move {
	
	public NightDaze() {
		this.name = "NightDaze";
		this.description = "	The user lets loose a pitch-black shock wave at its target.";

		this.power = 85;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Dark";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}