/**
 * Defines the basic structure of a pokemon.
 * @author
 * @version 1.00.00
 */

package pokemon;

import main.*;
import move.*;
import item.*;

import java.util.ArrayList;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.image.*;

abstract public class Pokemons {
	protected Pane body = new Pane();
	protected Pane battleSprite = new Pane();
	protected Pane inboxSprite = new Pane();
	protected int id;
	protected int dexID;
	protected String[] type = new String[2];
	protected ArrayList<String> status = new ArrayList<String>();
	// protected Ability ability;
	protected String nickname;
	protected String name;
	protected String OT; //Original trainer
	protected String description; // Pokemon entry
	protected String expType;
	protected String nature;
	protected String ability;
	protected boolean isShiny;
	protected PokeBall pokeball; // the pokeball the pokemon is in
	
	protected Item item;
	protected int level = 1;
	protected int currentExp = 0; //Basically total exp
	protected int expNeeded = 0; //Needed exp for next level
	protected int health; //Actual health used in battle
	protected Move[] moveSet = new Move[5];
	protected Move[] learnableMoveSet = new Move[] {};
	
	protected int baseExp, atk, def, spDef, spAtk, spd, hp; //hp = max hp
	protected int evAtk, evDef, evSpDef, evSpAtk, evSpd, evHp;
	//iv stuff. Just ignore these. It works, trust me	-Mathew
	protected int ivAtk = (int)(Math.random()*((31)));protected int ivDef = (int)(Math.random()*((31)));protected int ivSpDef = (int)(Math.random()*((31))); protected int ivSpAtk = (int)(Math.random()*((31))); protected int ivSpd = (int)(Math.random()*((31))); protected int ivHp = (int)(Math.random()*((31)));
	protected int bAtk, bDef, bSpDef, bSpAtk, bSpd, bHp;
	protected int evTotal = 0;
	

	public Pokemons() {
		this.body = new Pane();
		this.name = "MissingNo.";
		this.type[0] = "Normal";
		this.moveSet[0] = new Struggle();
		this.health = hp;
		//set base stats to 1
		this.bHp = 1;this.bAtk = 1;this.bDef = 1;this.bSpDef = 1;this.bSpAtk = 1;this.bSpd = 1;
		//set iv stats = 0
		this.ivHp = 0;this.ivAtk = 0;this.ivDef = 0;this.ivSpDef = 0;this.ivSpAtk = 0;this.ivSpd = 0;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		finalStatCalc();
		
		
	}
	
	
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/tile/TallGrass.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
	}

	abstract public void update();
	
	public void addHealth(int i){
		if(health+i>hp){
			health = hp;
		}else{
			health+=i;
		}
	}
	

	public boolean isDead() {
		return (this.health <= 0);
	}
	
	public Move useMove(int i){return moveSet[i];}
	
	//Stats stuffs
	
	private int hpCalc(){
		int finalHp = (int)(( ( ( 2*bHp+ivHp+(evHp/4 ) )*level )/100 ) + level + 10); //Use this once iv and ev are finished
		//int finalHp = (int)(Math.round( ( ( ( 2.0*bHp )*level )/100 ) + level + 10));
		return finalHp;
	}
	
	private int statCalc(int base,int iv,int ev,int previous){
		int finalStat = (int)(Math.round( ( ( ( (base+iv) * 2.0 ) + (Math.sqrt(ev)/4.0) ) * level ) / 100.0 ) + 5); //Use this once iv and ev are finished
		//int finalStat = (int)(Math.round( ( ( ( (base) * 2.0 ) ) * level ) / 100 ) + 5);
		//int finalStat = (((2*base+previous)*level)/100)+5;
		return finalStat;
	}
	
	public void finalStatCalc(){
		health = hp; //might change this later
		hp = hpCalc();
		atk = statCalc(bAtk, ivAtk, evAtk,atk);
		def = statCalc(bDef, ivDef, evDef,def);
		spAtk = statCalc(bSpAtk, ivSpAtk, evSpAtk,spAtk);
		spDef = statCalc(bSpDef, ivSpDef, evSpDef,spDef);
		spd = statCalc(bSpd, ivSpd, evSpd,spd);
	}
	
	//If evTotal is less than 510 && evX is less than 252, add 4. Else, do nothing.
	public void addEvAtk(){if(evTotal<510){if(evAtk<252){evAtk+=16;}}}
	public void addEvDef(){if(evTotal<510){if(evDef<252){evDef+=16;}}}
	public void addEvSpAtk(){if(evTotal<510){if(evSpAtk<252){evSpAtk+=16;}}}
	public void addEvSpDef(){if(evTotal<510){if(evSpDef<252){evSpDef+=16;}}}
	public void addEvSpd(){if(evTotal<510){if(evSpd<252){evSpd+=16;}}}
	public void addEvHp(){if(evTotal<510){if(evHp<252){evHp+=16;}}}
	
	//Call this before exp gaining
	public void updateEv(){
		int rand = (int)(Math.random()*5);
		if(rand==0){addEvAtk();}else if(rand==1){addEvDef();}else if(rand==2){addEvSpAtk();}else if(rand==3){addEvSpDef();}else if(rand==4){addEvSpd();}else if(rand==5){addEvHp();}
		evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;
	}
	
	//For stat++ items
	public void addToEvAtk(int i){if(evTotal<510&&evAtk<252){evAtk+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	public void addToEvDef(int i){if(evTotal<510&&evDef<252){evDef+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	public void addToEvSpAtk(int i){if(evTotal<510&&evSpAtk<252){evSpAtk+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	public void addToEvSpDef(int i){if(evTotal<510&&evSpDef<252){evSpDef+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	public void addToEvSpd(int i){if(evTotal<510&&evSpd<252){evSpd+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	public void addToEvHp(int i){if(evTotal<510&&evHp<252){evHp+=i;}evTotal+=evAtk+evDef+evSpAtk+evSpDef+evSpd+evHp;}
	
	//Call this after the battle
	public void levelUp(){
		level++;
		double temp = ((double)health)/hp; // Mathew, u forgot to cast. Did it for u - Joseph Ng
		hp=(int)(( ( ( 2*(bHp*0.02)+ivHp+(evHp/4.0 ) )*level )/100.0 ) + level + 10.0);
		health=(int)((temp*hp) + .5); // Made it round to nearest int not round down always. Logic needs to improve for not accumulating rounding errors. (talk to me about this error) - Joseph Ng
		atk+=(int)(0.02*bAtk) + (int)((evAtk+ivAtk)*.01);
		def+=Math.round(0.02*bDef) + (int)((evDef+ivDef)*.01);
		spAtk+=Math.round(0.02*bSpAtk) + (int)((evSpAtk+ivSpAtk)*.01);
		spDef+=Math.round(0.02*bSpDef) + (int)((evSpDef+ivSpDef)*.01);
		spd+=Math.round(0.02*bSpd) + (int)((evSpd+ivSpd)*.01);
		
	}
	
	
	
	//Maybe excessive code
	public int totalExp(int n, Pokemons p){ //n = current level

        double fast = (4.0*Math.pow(n,3))/5;//use
        double mediumFast = Math.pow(n,3);//use
        double slow = (5.0*Math.pow(n,3))/4;//use
        
        double exp = 0;
        String s = p.getExpType();
        //check for correct exp type
        if(s.equalsIgnoreCase("fast")){exp = fast;}else if(s.equalsIgnoreCase("mediumFast")){exp=mediumFast;}else{exp = slow;}
        return (int)(exp);
    }
    
    public double expNeeded(int n, Pokemons p){ //n = current level
        double fast = ((4.0*Math.pow(n+1,3))/5)-currentExp;//use
        double mediumFast = (Math.pow(n+1,3))-currentExp;//use
        double slow = ((5.0*Math.pow(n+1,3))/4)-currentExp;//use
        String s = p.getExpType();
        double exp = 0;
        if(s.equalsIgnoreCase("fast")){exp = fast;}else if(s.equalsIgnoreCase("mediumFast")){exp=mediumFast;}else{exp = slow;}
        return (int)(exp);
    }
	
	//String getters
    public String getName(){return name;}
    public String getNickname(){return nickname;}
    public String getOT(){return OT;}
    public String getExpType(){return expType;}
    public String getNature(){return nature;}
    //public String getAbility(){return ability;}
    public String getDescription(){return description;}
    
    //int getters
    public int getID(){return id;}
    public int getDexID(){return dexID;}
    public int getLevel(){return level;}
    public int getBaseExp(){return baseExp;}
    public int getAtk(){return atk;}
    public int getDef(){return def;}
    public int getSpDef(){return spDef;}
    public int getSpAtk(){return spAtk;}
    public int getSpd(){return spd;}
    public int getHp(){return hp;}
    public int getHealth(){return health;}
    
    //boolean getters
    public boolean getIsShiny(){return isShiny;}
    
    //ArrayList getters
    public ArrayList<String> getStatus(){return status;}
    
    //Array getters
    public Move[] getLearnableMoveSet(){return learnableMoveSet;}
    public String[] getType(){return type;}
    public Move[] getMoveSet() {return this.moveSet;}
    
    //Pane getters
    public Pane getBody(){return body;}
    public Pane getBattleSprite(){return battleSprite;}
    public Pane getInboxSprite(){return inboxSprite;}
    
    //String setters
    public void setName(String s){name=s;}
    public void setNickname(String s){nickname=s;}
    public void setOT(String s){OT=s;}
    public void setExpType(String s){expType=s;}
    public void setNature(String s){nature=s;}
    public void setAbility(String s){ability=s;}
    
    //int setters
    public void setID(int s){id=s;}
    public void setDexID(int s){dexID=s;}
    public void setLevel(int s){level=s;}
    public void setBaseExp(int s){baseExp=s;}
    public void setAtk(int s){atk=s;}
    public void setDef(int s){def=s;}
    public void setSpAtk(int s){spAtk=s;}
    public void setSpDef(int s){spDef=s;}
    public void setSpd(int s){spd=s;}
    public void setHp(int s){hp=s;}
    public void setHealth(int s){health=s;}
    
    //boolean setters
    public void setIsShiny(boolean s){isShiny=s;}
    
    //ArrayList setters
    public void setStatus(ArrayList<String> s){status=s;}
    
    //Array setters
    public void setMoveSet(Move[] s){moveSet=s;}
    public void setLearnableMoveSet(Move[] s){learnableMoveSet=s;}
    public void setType(String[] s){type=s;}
    
    //Pane setters
    public void setBody(Pane p){body = p;}
    public void setBattleSprite(Pane p){battleSprite = p;}
    public void setInboxSprite(Pane p){inboxSprite = p;}
}