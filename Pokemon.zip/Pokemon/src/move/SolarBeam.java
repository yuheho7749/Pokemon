package move;

public class SolarBeam extends Move {
	
	public SolarBeam() {
		this.name = "SolarBeam";
		this.description = "The user gathers light, then blasts a bundled beam and heals itself.";

		this.power = 199;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 0;
	}
}