package move;

public class Zawarudo extends Move {
	
	public Zawarudo() {
		this.name = "Zawarudo";
		this.description = "The World stop time! Roadroller! MudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMudaMuda! When time stops, only Dio can move.";
		this.priority = true;

		this.power = Integer.MAX_VALUE;
		this.accuracy = Integer.MAX_VALUE;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = Integer.MAX_VALUE;
		this.maxPP = Integer.MAX_VALUE;

		this.type = "Nope";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}