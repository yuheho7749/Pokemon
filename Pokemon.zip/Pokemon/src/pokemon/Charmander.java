package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class Charmander extends Pokemons{
	
	public Charmander(){
		super();
		this.name = "Charmander";
		this.type[0] = "Fire";
		this.body = new Pane();
		pokeball = new PokeBall();
		body.getChildren().add(new Circle(100,Color.RED));
		this.moveSet[0] = new Struggle();
		//set base stats of Pokemon
		this.bHp = 39;this.bAtk = 52;this.bDef = 43;this.bSpDef = 50;this.bSpAtk = 60;this.bSpd = 65;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		finalStatCalc();
		
		this.moveSet[1] = new Tackle();
		this.moveSet[2] = new TailWhip();
		this.moveSet[3] = new QuickAttack();
		this.moveSet[4] = new Ember();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

