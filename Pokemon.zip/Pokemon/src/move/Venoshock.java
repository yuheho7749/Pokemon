package move;

public class Venoshock extends Move {
	
	public Venoshock() {
		this.name = "Venoshock";
		this.description = "The user drenches the target in a special poisonous liquid, poisoning the target with it.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 1;
	}
}