/**
 * Defines a basic structure for a building.
 * @author 
 * @version 1.00.00
 */

package building;

import main.*;
import character.*;
import tile.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

abstract public class Building extends Entity {
	protected String name;
	protected ArrayList<Tile> tiles = new ArrayList<Tile>();
	protected int width = 0, height = 0;

	public Building() {
		super();
	}

	public String getName() {return this.name;}
	public ArrayList<Tile> getTiles() {return this.tiles;}
	public int getWidth() {return this.width;}
	public int getHeight() {return this.height;}

	/**
	 * Adds the tile to the correct location on the map.
	 * @param tile the tile that is relocated
	 * @param x the x grid location (not pixel location)
	 * @param y the y grid location (not pixel location)
	 */
	public void setTile(Tile tile, int x , int y) {
		tile.getBody().setLayoutX(x * Entity.SCALEFACTOR);
		tile.getBody().setLayoutY(y * Entity.SCALEFACTOR);
		this.tiles.add(tile);
		this.body.getChildren().add(tile.getBody());
	}

	/**
	 * Sets the positions of the blocks and body in the map.
	 */
	public void setPosition(int x, int y) {
		this.body.setLayoutX(x * Entity.SCALEFACTOR);
		this.body.setLayoutY(y * Entity.SCALEFACTOR);
		for (Tile t : this.tiles) {
			t.getBody().setLayoutX(t.getBody().getLayoutX() + (x * Entity.SCALEFACTOR));
			t.getBody().setLayoutY(t.getBody().getLayoutY() + (y * Entity.SCALEFACTOR));
		}
	}

}