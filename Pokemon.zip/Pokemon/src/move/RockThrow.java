package move;

public class RockThrow extends Move {
	
	public RockThrow() {
		this.name = "RockThrow";
		this.description = "The user picks up and throws a small rock at the target to attack.";

		this.power = 50;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Rock";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}