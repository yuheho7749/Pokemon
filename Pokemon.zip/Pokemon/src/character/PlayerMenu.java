/**
 * Controls and displays the player menu.
 * @author
 * @version 1.00.00
 */

package character;

import main.*;

import java.util.ArrayList;

import javafx.stage.*;
import javafx.scene.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.control.*;

import javafx.util.*;
import javafx.geometry.*;

public class PlayerMenu {
	protected Pane body;
	protected Player player;
	protected VBox catalog;
	protected int selectionPosition = 0;
	//protected Circle cursor;


	// fields under this may not be used
	protected Pane partyMenu; // opens another screen with the inventory
	protected Pane bagMenu;

	protected Pane[] menuCatalog;

	public PlayerMenu(Player p) {
		this.player = p;
		this.body = new Pane();
		this.body.setPrefSize(Game.VIEW_WIDTH * .25, Game.VIEW_HEIGHT * .5);
		this.body.setLayoutX(Game.VIEW_WIDTH * .75); // always top right corner of game screen
		this.body.setLayoutY(0);

		this.body.setStyle("-fx-background-color: Gray;");

		// make cursor design here
		// cursor = new Circle(Game.VIEW_WIDTH/100);
		// cursor.setFill(Color.BLUE);
		// cursor.setCenterX(Game.VIEW_WIDTH/40);
		// cursor.setCenterY(Game.VIEW_HEIGHT/50 + Game.VIEW_HEIGHT/25);

		// add actual menu here
		this.partyMenu = this.player.getPartyMenu().getPartyView(); 
		this.bagMenu = this.player.getBagView().displayBag();
		this.menuCatalog = new Pane[] {partyMenu, bagMenu};


		// design the menu here
		catalog = new VBox();
		catalog.setSpacing(Game.VIEW_HEIGHT/100);
		catalog.setLayoutX(Game.VIEW_WIDTH/50);
		catalog.setLayoutY(Game.VIEW_HEIGHT/50);
		// catalog.setPadding(new Insets(Game.VIEW_HEIGHT/50,Game.VIEW_HEIGHT/50,Game.VIEW_HEIGHT/50,Game.VIEW_HEIGHT/50));

		Label partyLabel = new Label("Pokemon");
		partyLabel.setStyle("-fx-font-size: " + Game.VIEW_WIDTH/25 + ";");


		Label bagLabel = new Label("Bag");
		bagLabel.setStyle("-fx-font-size: " + Game.VIEW_WIDTH/25 + ";");

		Label exitLabel = new Label("Exit");
		exitLabel.setStyle("-fx-font-size: " + Game.VIEW_WIDTH/25 + ";");


		catalog.getChildren().addAll(partyLabel, bagLabel, exitLabel);
		this.body.getChildren().addAll(catalog);


		partyLabel.setTextFill(Color.WHITE);
		bagLabel.setTextFill(Color.BLACK);
		exitLabel.setTextFill(Color.BLACK);
		



	}

	public Player getPlayer() {return this.player;}
	public Pane[] getMenuCatalog() {return this.menuCatalog;}
	public Pane getCurrentMenuCatalog() {return this.menuCatalog[selectionPosition];}
	public Pane getBody() {return this.body;}
	public int getSelectionPosition() {return this.selectionPosition;}
	
	public void pressA() {
		// System.out.println("A");
	}
	
	public void pressB() {
		// System.out.println("B");
	}

	public void scrollDown() {
		// System.out.println("Go down");
		// this.cursor.setCenterY(this.cursor.getCenterY() + Game.VIEW_HEIGHT/10);
		((Label)this.catalog.getChildren().get(selectionPosition)).setTextFill(Color.BLACK);
		this.selectionPosition ++;
		if (this.selectionPosition >= this.catalog.getChildren().size()) {
			this.selectionPosition = 0;
		}
		((Label)this.catalog.getChildren().get(selectionPosition)).setTextFill(Color.WHITE);
	}

	public void scrollUp() {
		// System.out.println("Go Up");
		// this.cursor.setCenterY(this.cursor.getCenterY() - Game.VIEW_HEIGHT/10);
		((Label)this.catalog.getChildren().get(selectionPosition)).setTextFill(Color.BLACK);
		this.selectionPosition --;
		if (this.selectionPosition < 0) {
			this.selectionPosition = this.catalog.getChildren().size() - 1;
		}
		((Label)this.catalog.getChildren().get(selectionPosition)).setTextFill(Color.WHITE);
	}
}