package move;

public class ZapCannon extends Move {
	
	public ZapCannon() {
		this.name = "ZapCannon";
		this.description = "The user fires an electric blast like a cannon to inflict damage and cause paralysis.";

		this.power = 120;
		this.accuracy = .5;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Normal";
		this.statusEffect = "Paralyzed";
		this.statusChance = 1;
	}
}