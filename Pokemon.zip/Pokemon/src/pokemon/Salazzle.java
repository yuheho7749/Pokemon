package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Salazzle extends Pokemons{
	
	public Salazzle(){
		super();
		this.name = "Salazzle";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Poison";
		this.type[1] = "Fire";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 68;this.bAtk = 64;this.bDef = 60;
        this.bSpAtk = 111;this.bSpDef = 60;this.bSpd = 117;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/salazzle.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/salazzle.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/salazzle.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	public void update(){}
}

