package move;

public class Strength extends Move {
	
	public Strength() {
		super();
		this.name = "Strength";
		this.description = "The target is slugged with a punch thrown at maximum power. This move can also be used to move boulders.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}