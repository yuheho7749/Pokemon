/**
 * Defines the summary of the pokemon's battle conditions (health etc).
 * @author
 * @version 1.00.00
 */

package battlemap;
import main.*;
import pokemon.*;
import move.*;
import character.*;

import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;

public class PokemonSummary {
	public Pokemons mainPokemon;
	public Pane summary;
	public Pane healthBar;
	public Rectangle health;
	public Text hpNum;
	double scale = 1;
	
	public PokemonSummary(Pokemons main,double sizeMultiplier){
		mainPokemon = main; //t.getParty().get(0);
		scale = sizeMultiplier;
		generateBattleSummary(main);
	}	
	public PokemonSummary(Pokemons main){
		mainPokemon = main; //t.getParty().get(0);
		generateBattleSummary(main);
	}
	
	public Pane generateBattleSummary(Pokemons main){
		summary = new Pane();
		summary.setPrefSize(350*scale,200*scale);
		summary.setStyle("-fx-background-color: Gray;");
		
		healthBar = new Pane();
		healthBar.setPrefSize(330*scale,40*scale);
		healthBar.setLayoutX(10*scale);
		healthBar.setLayoutY(60*scale);
		healthBar.setStyle("-fx-background-color: Black;");
		health = new Rectangle(5*scale,5*scale,320*scale,30*scale);
		health.setFill(Color.GREEN);
		
		hpNum = new Text(180*scale,130*scale,""+mainPokemon.getHealth()+"/"+mainPokemon.getHp());
		hpNum.setFont(new Font(30*scale));
		
		Text name = new Text(10*scale,30*scale,mainPokemon.getName());
		name.setFont(new Font(30*scale));
		
		healthBar.getChildren().add(health);
		summary.getChildren().addAll(healthBar,hpNum,name);//drawPokeball(200,20,20,"red")
		return summary;
	}
	
	public Pane getSummary(){return summary;}

	
/*	public Pane drawPokeball(int size,double x,double y,String color){
		Pane pokeball = new Pane();
		pokeball.setLayoutX(x);
		pokeball.setLayoutY(y);
		pokeball.setPrefSize(50,50);
		Circle ball = new Circle(size/2,size/2,size/2);
		ball.setFill();
		pokeball.getChildren().add(ball);
		return pokeball;
	}
*/
	public void updateHealth(){
		double healthPercentage = ((double)mainPokemon.getHealth())/mainPokemon.getHp();
		health.setWidth(320*healthPercentage * scale); // John, you forgot the scale. Fixed it for u - Joseph Ng
		hpNum.setText(mainPokemon.getHealth()+"/"+mainPokemon.getHp());
		
	}
}