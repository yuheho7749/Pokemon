package move;

public class PoisonFang extends Move {
	
	public PoisonFang() {
		this.name = "PoisonFang";
		this.description = "The user bites the target with toxic fangs. This may also leave the target badly poisoned.";

		this.power = 50;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Poison";
		this.statusEffect = "poisoned";
		this.statusChance = 0.3;
	}
}