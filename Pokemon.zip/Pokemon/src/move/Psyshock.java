package move;

public class Psyshock extends Move {
	
	public Psyshock() {
		this.name = "Psyshock";
		this.description = "	The user materializes an odd psychic wave to attack the target.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Psychic";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}