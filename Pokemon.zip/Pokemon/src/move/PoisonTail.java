package move;

public class PoisonTail extends Move {
	
	public PoisonTail() {
		this.name = "PoisonTail";
		this.description = "The user hits the target with its tail. This may also poison the target. ";

		this.power = 50;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.175;
	}
}