package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Axew extends Pokemons{
	//Stat to be changed
	public Axew(){
		super();
		this.name = "Axew";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Dragon";
		
		
		this.moveSet[0] = new Struggle();
		//set base stats
		this.bHp = 46;this.bAtk = 87;this.bDef = 60;this.bSpAtk = 30;this.bSpDef = 40;this.bSpd = 57;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		
		
	}
	
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/axew.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/axew.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/axew.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

