package move;

public class HighJumpKick extends Move {
	
	public HighJumpKick() {
		this.name = "HighJumpKick";
		this.description = "The target is attacked with a knee kick from a jump.";

		this.power = 130;
		this.accuracy = .8;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}