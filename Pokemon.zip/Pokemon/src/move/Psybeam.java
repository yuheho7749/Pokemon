package move;

public class Psybeam extends Move {
	
	public Psybeam() {
		this.name = "Psybeam";
		this.description = "	The target is attacked with a peculiar ray. This may also leave the target confused.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Psychic";
		this.statusEffect = "Confused";
		this.statusChance = 0.3;
	}
}