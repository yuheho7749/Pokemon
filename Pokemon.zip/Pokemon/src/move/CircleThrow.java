package move;

public class CircleThrow extends Move {
	
	public CircleThrow() {
		this.name = "CircleThrow";
		this.description = "The user thrown the target away with all its might.";

		this.power = 60;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}