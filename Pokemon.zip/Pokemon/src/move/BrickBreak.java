package move;

public class BrickBreak extends Move {
	
	public BrickBreak() {
		this.name = "BrickBreak";
		this.description = "The user attacks with a swift chop.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}