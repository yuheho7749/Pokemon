package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Pangoro extends Pokemons{
	
	public Pangoro(){
		super();
		this.name = "Pangoro";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Fighting";
		this.type[1] = "Dark";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 95;this.bAtk = 124;this.bDef = 78;
        this.bSpAtk = 69;this.bSpDef = 71;this.bSpd = 58;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/pangoro.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/pangoro.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/pangoro.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	public void update(){}
}

