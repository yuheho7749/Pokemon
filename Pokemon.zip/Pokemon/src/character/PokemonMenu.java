/**
 * Displays items that the trainer has, trainer knows what items he has but the bag will display it.
 * @author
 * @version 1.00.00
 */
package character;


import main.*;
import character.*;
import item.*;
import battlemap.*;

import java.util.ArrayList;

import javafx.stage.*;
import javafx.scene.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.control.*;

import javafx.util.*;
import javafx.geometry.*;
public class PokemonMenu {
	
	private Pane partyView;
	private Player player;
	private FlowPane layoutFormat;
	
	private Pane[][] pokemonOrder = new Pane[3][2];
	private int verticalChoice; 
	private int horizontalChoice;
	
	
	

	public PokemonMenu(Player p) {
		this.player = p;
		this.partyView = new Pane();
		this.layoutFormat = new FlowPane();
		this.verticalChoice = 0;
		this.horizontalChoice = 0;
		this.partyView.setStyle("-fx-background-color: Salmon;");
		this.partyView.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		this.layoutFormat.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		
	
		int i = 0; 
		for(int k = 0; k < pokemonOrder.length; k++){
			for(int l = 0; l < pokemonOrder[k].length; l++){
			
				
				//note to self: change this part, currently it will fill all of the pokemon menu with panes even if there is no pokemon
				
				
				Pane pokemonSummary = new Pane();
				pokemonSummary.setPrefSize(Game.VIEW_WIDTH/2, Game.VIEW_HEIGHT/3);
				pokemonSummary.setStyle("-fx-background-color: Blue");
				BorderStroke border = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(5));
				pokemonSummary.setBorder(new Border(border));
				
			
				
				//puts all pokemon in player's party into the menu
				if(i < player.getParty().size()){
				
					Pane pokemonBody = player.getParty().get(i).getInboxSprite();
					pokemonBody.setLayoutX(5);
					pokemonBody.setLayoutY(5);

					
					
					PokemonSummary pokemonInfo = new PokemonSummary(player.getParty().get(i),0.9);
					pokemonInfo.updateHealth(); // Alex, y u no update health, bro. Fixed it for u - Joseph Ng
					pokemonInfo.summary.setStyle("-fx-background-color: transparent");
					pokemonInfo.hpNum.setX(10);
					pokemonInfo.hpNum.setY(120);
					Pane info = new Pane();
					info.getChildren().add(pokemonInfo.getSummary());
					info.setLayoutX(Game.VIEW_WIDTH/10);
					info.setLayoutY(5);
					
			
			
					pokemonSummary.getChildren().add(pokemonBody);
					pokemonSummary.getChildren().add(info);
					
					
					i++;
				}
				
				
				
				pokemonOrder[k][l] = pokemonSummary;
			}
		}	
		for(int m = 0; m < pokemonOrder.length; m++){
			for(int n = 0; n < pokemonOrder[m].length; n++){
				layoutFormat.getChildren().add(pokemonOrder[m][n]);
			}
		}
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
		partyView.getChildren().add(layoutFormat);
		
	
	}
	
	public Pane getPartyView() {return partyView;}
	
	
	//note to self: prevent player from moving the selection bar pass the pokemon they have; ie only 1 pokemon yet can move in the menu for other slots
	//also need to implement in game to see if works
	
	
	//navigation of the pokemon menu
	public void chooseRightPokemon(){
		//resets old selection back to original color
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		horizontalChoice++;
		 
		if(horizontalChoice > 1){
			horizontalChoice = 0;
		}
		//selected box will be highlighted
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseLeftPokemon(){
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		horizontalChoice--;
		 
		if(horizontalChoice < 0){
			horizontalChoice = 1;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseAbovePokemon(){
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		verticalChoice--;
		 
		if(verticalChoice < 0){
			verticalChoice = 2;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseBelowPokemon(){
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		verticalChoice++;
		 
		if(verticalChoice > 2){
			verticalChoice = 0;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
}