package move;

public class DragonRush extends Move {
	
	public DragonRush() {
		this.name = "DragonRush";
		this.description = "	The user tackles the target while exhibiting overwhelming menace. This may also make the target flinch.";

		this.power = 100;
		this.accuracy = .75;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Dragon";
		this.statusEffect = "Flinched";
		this.statusChance = 0.35;
	}
}