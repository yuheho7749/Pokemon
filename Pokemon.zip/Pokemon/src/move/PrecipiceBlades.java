package move;

public class PrecipiceBlades extends Move {
	
	public PrecipiceBlades() {
		this.name = "PrecipiceBlades";
		this.description = "	The user attacks opposing Pokémon by manifesting the power of the land in fearsome blades of stone.";

		this.power = 120;
		this.accuracy = .85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}