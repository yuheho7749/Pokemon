package move;

public class IronTail extends Move {
	
	public IronTail() {
		this.name = "IronTail";
		this.description = "The target is slammed with a steel-hard tail. This may also flinch the target.";

		this.power = 100;
		this.accuracy = .75;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Steel";
		this.statusEffect = "Flinched";
		this.statusChance = 0.2;
	}
}