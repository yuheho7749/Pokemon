package move;

public class Earthquake extends Move {
	
	public Earthquake() {
		this.name = "Earthquake";
		this.description = "The user sets off an earthquake that strikes every Pokémon around it.";

		this.power = 100;
		this.accuracy = 1;
		this.recoil = 0.2;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}