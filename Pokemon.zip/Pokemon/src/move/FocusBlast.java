package move;

public class FocusBlast extends Move {
	
	public FocusBlast() {
		this.name = "FocusBlast";
		this.description = "The user heightens its mental focus and unleashes its power.";

		this.power = 120;
		this.accuracy = .7;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}