package move;

public class LandsWrath extends Move {
	
	public LandsWrath() {
		this.name = "LandsWrath";
		this.description = "	The user gathers the energy of the land and focuses that power on opposing Pokémon to damage them.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}