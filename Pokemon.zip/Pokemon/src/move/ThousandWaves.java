package move;

public class ThousandWaves extends Move {
	
	public ThousandWaves() {
		this.name = "ThousandWaves";
		this.description = "	The user attacks with a wave that crawls along the ground and confuses the target.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}
}