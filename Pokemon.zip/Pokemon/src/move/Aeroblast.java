package move;

public class Aeroblast extends Move {
	
	public Aeroblast() {
		this.name = "Aeroblast";
		this.description = "A vortex of air is shot at the target to inflict a massive damage. ";

		this.power = 120;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}