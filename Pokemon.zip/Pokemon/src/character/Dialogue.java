/**
 * Encapsulates the dialogue of a person in a label.
 * @author
 * @version 1.00.00
 */

package character;

import main.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class Dialogue {
	public static final double FAST_TEXT_SPEED = 1.5;
	public static final double NORMAL_TEXT_SPEED = 2;
	public static final double SLOW_TEXT_SPEED = 3;

	protected Label dialogue;
	protected ArrayList<String> message = new ArrayList<String>();
	protected int page = 0;
	protected int bufferCharacters = 0; 
	protected double textSpeed = NORMAL_TEXT_SPEED;

	public Dialogue() {
		this.dialogue = new Label();
		this.dialogue.setLayoutX(10);
		this.dialogue.setLayoutY(10);
		this.dialogue.setFont(new Font("Courtier", 20));
		// this.dialogue.setStyle("-fx-font-size: 20px;");
	}

	public Label getDialogue() {return this.dialogue;}
	public void setMessage(ArrayList<String> s) {this.message = s;}
	public void changeDialogue(String s) {this.dialogue.setText(s);}
	public void setTextSpeed(double b) {this.textSpeed = b;}

	public boolean nextPage() {
		this.dialogue.setText("");
		this.bufferCharacters = 0;
		if (message.size() - 1 > page) {
			this.page++;
			return true;
		}
		return false;
	}

	public void skipSlowTalking() {
		// this.dialogue.setText(this.message.get(page)); // cheap way and will not go to next line automatically
		while (this.isStillSaying()) { // not good for computational time tho
			this.displayDialogue();
		}
	}

	public boolean isMoreText() {
		return this.page < this.message.size() - 1;
	}

	public boolean isStillSaying() {
		return message.get(page).length() + this.bufferCharacters > this.dialogue.getText().length();
	}

	// public void displayDialogue() {
	// 	for (int i = 0; i < (int)(Game.DELAY/this.textSpeed); i ++) {
	// 		if (this.dialogue.getText().length() < message.get(page).length() + this.bufferCharacters) {
	// 			this.dialogue.setText(this.dialogue.getText() + message.get(page).substring(this.dialogue.getText().length() - this.bufferCharacters, this.dialogue.getText().length() + 1 - this.bufferCharacters));
	// 			if ((this.dialogue.getText().length() - this.bufferCharacters) % 90 == 0) { // automatically skips to next line if line is too long
	// 				this.dialogue.setText(this.dialogue.getText() + "\n");
	// 				this.bufferCharacters ++;
	// 			}
	// 		}
	// 	}
	// }


	/**
	 * Displays the dialogue with animation.
	 */
	public void displayDialogue() { // updated version that handles the text breaks and wrapping
		for (int i = 0; i < (int)(Game.DELAY/this.textSpeed); i ++) {
			if (this.dialogue.getText().length() < message.get(page).length() + this.bufferCharacters) {
				this.dialogue.setText(this.dialogue.getText() + message.get(page).substring(this.dialogue.getText().length() - this.bufferCharacters, this.dialogue.getText().length() + 1 - this.bufferCharacters));
				if (this.dialogue.getText().length() != message.get(page).length() && (this.dialogue.getText().length() - this.bufferCharacters) % 80 == 0) { // automatically skips to next line if line is too long
					if (this.dialogue.getText().substring(this.dialogue.getText().length() - 1).equals(" ")) {
						this.dialogue.setText(this.dialogue.getText() + "\n");
						this.bufferCharacters ++;
					} else if (message.get(page).substring(this.dialogue.getText().length() - this.bufferCharacters, this.dialogue.getText().length() + 1 - this.bufferCharacters).equals(" ")) {
						this.dialogue.setText(this.dialogue.getText() + message.get(page).substring(this.dialogue.getText().length() - this.bufferCharacters, this.dialogue.getText().length() + 1 - this.bufferCharacters));
						this.dialogue.setText(this.dialogue.getText() + "\n");
						this.bufferCharacters ++;
					} else {
						this.dialogue.setText(this.dialogue.getText() + "-\n");
						this.bufferCharacters += 2;
					}
				}
			}
		}
	}

	
}