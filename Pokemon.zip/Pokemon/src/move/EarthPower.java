package move;

public class EarthPower extends Move {
	
	public EarthPower() {
		this.name = "EarthPower";
		this.description = "The user makes the ground under the target and itself erupt with power. ";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0.13;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}