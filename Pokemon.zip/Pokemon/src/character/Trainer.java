/**
 * Defines the basic structure of a human character in Pokemon.
 * @author
 * @version 1.00.00
 */

package character;

import main.*;
import pokemon.*;
import move.*;
import item.*;

import java.util.ArrayList;

import javafx.scene.image.*;
import javafx.scene.shape.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;

abstract public class Trainer extends Entity {
	protected String name;
	protected int id;

	protected ArrayList<Item> keyItems = new ArrayList<Item>();
	protected ArrayList<Item> medicines = new ArrayList<Item>();
	protected ArrayList<Item> pokeballs = new ArrayList<Item>();
	protected ArrayList<ArrayList<Item>> bag = new ArrayList<ArrayList<Item>>(); // defines a bag with different pockets

	protected ArrayList<Pokemons> party = new ArrayList<Pokemons>();

	protected Pane[] lookingUp = new Pane[4];
	protected Pane[] lookingDown = new Pane[4];
	protected Pane[] lookingRight = new Pane[4];
	protected Pane[] lookingLeft = new Pane[4];
	protected int animationCycle = 0;
	protected boolean lookLeft = false, lookRight = false, lookDown = false, lookUp = false;

	public Trainer() {
		super();
		this.bag.add(this.pokeballs);
		this.bag.add(this.medicines);
		// this.bag.add(this.keyItems);
	}

	public boolean getLookRight() {return this.lookRight;}
	public boolean getLookLeft() {return this.lookLeft;}
	public boolean getLookUp() {return this.lookUp;}
	public boolean getLookDown() {return this.lookDown;}
	
	public Pokemons getCurrentPokemon() {return this.party.get(0);}

	public int getId() {return this.id;}
	public ArrayList<Pokemons> getParty() {return this.party;}
	public ArrayList<ArrayList<Item>> getBag() {return this.bag;}
	public ArrayList<Item> getKeyItems() {return this.keyItems;}
	public ArrayList<Item> getMedicines() {return this.medicines;}
	public ArrayList<Item> getPokeballs() {return this.pokeballs;}

	public void setAnimationCycle(int n) {this.animationCycle = n % 4;}
	public int getAnimationCycle() {return this.animationCycle;}


	public void moveRight(double spd) {
		lookLeft = false; lookRight = true; lookDown = false; lookUp = false;
		this.body.getChildren().set(0, lookingRight[animationCycle]);
		this.body.setLayoutX(this.body.getLayoutX() + spd);
	}

	public void moveLeft(double spd) {
		lookLeft = true; lookRight = false; lookDown = false; lookUp = false;
		this.body.getChildren().set(0, lookingLeft[animationCycle]);
		this.body.setLayoutX(this.body.getLayoutX() - spd);
	}

	public void moveUp(double spd) {
		lookLeft = false; lookRight = false; lookDown = false; lookUp = true;
		this.body.getChildren().set(0, lookingUp[animationCycle]);
		this.body.setLayoutY(this.body.getLayoutY() - spd);
	}

	public void moveDown(double spd) {
		lookLeft = false; lookRight = false; lookDown = true; lookUp = false;
		this.body.getChildren().set(0, lookingDown[animationCycle]);
		this.body.setLayoutY(this.body.getLayoutY() + spd);
	}

	/**
	 * The player selects a move.
	 * @return returns the move used
	 */
	public Move takeTurn(Pokemons currentPokemon) {
		return currentPokemon.getMoveSet()[0]; // temporary
	}
} 