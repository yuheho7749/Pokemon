package move;

public class AcidSpray extends Move {
	
	public AcidSpray() {
		this.name = "AcidSpray";
		this.description = "The user spits fluid that works to melt the target. The target may flinched after getting hit.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Poison";
		this.statusEffect = "Flinched";
		this.statusChance = 0.25;
	}
}