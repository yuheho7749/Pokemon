/**
 * Defines the move struggle.
 * @author 
 * @version 1.00.00
 */

package move;


public class Struggle extends Move {
	
	public Struggle() {
		super();
		this.name = "Struggle";
		this.description = "The default move of a pokemon";

		this.power = 50;
		this.accuracy = 1;
		this.recoil = .25;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = Integer.MAX_VALUE;
		this.maxPP = Integer.MAX_VALUE; // test later

		this.type = "Normal";

	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}