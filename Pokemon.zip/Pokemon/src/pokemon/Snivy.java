package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Snivy extends Pokemons{
	
	public Snivy(){
		super();
		this.name = "Snivy";
		this.type[0] = "Grass";
		this.body = new Pane();
		pokeball = new PokeBall();
		
		this.moveSet[0] = new Struggle();
		//set base stats of Pokemon
		this.bHp = 45;this.bAtk = 45;this.bDef = 66;this.bSpDef = 55;this.bSpAtk = 45;this.bSpd = 63;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		
		
	}
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/snivy.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/snivy.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/snivy.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

