package move;

public class Flamethrower extends Move {
	
	public Flamethrower() {
        this.name = "Flamethrower";
		this.description = "The target is scorched with an intense blast of fire. This may also leave the target with a burn.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
} 