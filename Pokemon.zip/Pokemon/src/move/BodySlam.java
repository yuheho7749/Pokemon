package move;

public class BodySlam extends Move {
	
	public BodySlam() {
		super();
		this.name = "BodySlam";
		this.description = "The user drops onto the target with its full body weight. It may also leave the target with paralysis.";

		this.power = 85;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Normal";
		this.statusEffect = "Paralyzed";
		this.statusChance = .3;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}