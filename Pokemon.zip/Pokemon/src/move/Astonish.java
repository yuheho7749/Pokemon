package move;

public class Astonish extends Move {
	
	public Astonish() {
		this.name = "Astonish";
		this.description = "	The user attacks the target while shouting in a startling fashion. This may also make the target flinch.";

		this.power = 30;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Ghost";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}