package move;

public class HeatWave extends Move {
	
	public HeatWave() {
        this.name = "HeatWave";
		this.description = "The user attacks by exhaling hot breath on the opposing Pokemon. This may also leave those Pokemon with a burn.";

		this.power = 95;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.2;
	}
} 