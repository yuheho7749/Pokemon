package move;

public class SpacialRend extends Move {
	
	public SpacialRend() {
		this.name = "SpacialRend";
		this.description = "	The user tears the target along with the space around it.";

		this.power = 150;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Dragon";
		this.statusEffect = "Flinched";
		this.statusChance = 0.5;
	}
}