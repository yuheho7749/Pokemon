package move;

public class OminousWind extends Move {
	
	public OminousWind() {
		this.name = "OminousWind";
		this.description = "	The user blasts the target with a gust of repulsive wind. This may also burn the target.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Ghost";
		this.statusEffect = "Burned";
		this.statusChance = 0.5;
	}
}