
	package item;
	import javafx.scene.image.ImageView;
	import main.*;
	import pokemon.*;

public class HyperPotion extends Heal{
	

	

	
	public HyperPotion(){
		super();
		name = "Hyper Potion";
		this.description = "Restores 200 HP.";
		healHealth = 200;
		healStatus ="None";
		cost = 1200;
		sellPrice = 600;
	}
	public HyperPotion(int q) {
		super(q);
		name = "Hyper Potion";
		this.description = "Restores 200 HP.";
		healHealth = 200;
		healStatus ="None";
		cost = 1200;
		sellPrice = 600;
	}
	


}