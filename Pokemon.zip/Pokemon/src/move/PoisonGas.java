package move;

public class PoisonGas extends Move {
	
	public PoisonGas() {
		this.name = "PoisonGas";
		this.description = "A cloud of poison gas is sprayed in the face of opposing Pokémon, poisoning those hit.";

		this.power = 10;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 1;
	}
}