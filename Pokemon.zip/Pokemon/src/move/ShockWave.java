package move;

public class ShockWave extends Move {
	
	public ShockWave() {
		this.name = "ShockWave";
		this.description = "The user strikes the target with a quick jolt of electricity. This attack never misses.";

		this.power = 60;
		this.accuracy = Integer.MAX_VALUE;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Electric";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}