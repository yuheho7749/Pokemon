/**
 * Defines a fence barrier.
 * @author
 * @version 1.00.00
 */

package tile;

import main.*;
import character.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;
import javafx.scene.control.*;

public class FenceBarrier extends Barrier {

	public FenceBarrier() {
		super();
		this.name = "FenceBarrier";

		if (enableHitBox) {
			this.body.setStyle("-fx-border-color: Black; -fx-border-width: 1px;");
		}
		
		// ImageView image = new ImageView("file:res/tile/Fence.png");
		// image.setFitWidth(Entity.SCALEFACTOR);
		// image.setFitHeight(Entity.SCALEFACTOR);
		// image.setCache(true);

		// this.body.getChildren().addAll(image);
		
		Pane design = new Pane();
		design.setPrefSize(Entity.SCALEFACTOR, Entity.SCALEFACTOR);

		Rectangle rect1 = new Rectangle(Entity.SCALEFACTOR, Entity.SCALEFACTOR/4);
		rect1.setFill(Color.BROWN);
		rect1.setY(Entity.SCALEFACTOR/3);

		Rectangle rect2 = new Rectangle(Entity.SCALEFACTOR/4, Entity.SCALEFACTOR/3);
		rect2.setFill(Color.BROWN);
		// rect2.setX(Entity.SCALEFACTOR/8);
		// rect2.setY(Entity.SCALEFACTOR/2);

		// Rectangle rect3 = new Rectangle(Entity.SCALEFACTOR/4, Entity.SCALEFACTOR/2);
		// rect3.setFill(Color.BROWN);
		// rect3.setX(6*Entity.SCALEFACTOR/8);
		// rect3.setY(Entity.SCALEFACTOR/2);



		this.design.getChildren().addAll(rect1, rect2);

		this.body.getChildren().addAll(design);

		this.labelSelf(); // just for testing purposes
	}

	@Override
	public boolean tileEffect(Player p) {
		return true;
	}

}