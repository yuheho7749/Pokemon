package move;

public class DragonClaw extends Move {
	
	public DragonClaw() {
		this.name = "DragonClaw";
		this.description = "	The user slashes the target with huge sharp claws.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dragon";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}