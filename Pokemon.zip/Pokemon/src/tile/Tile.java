/**
 * Defines the structure for a tile.
 * @author
 * @version 1.00.00
 */

package tile;

import main.*;
import character.*;

import javafx.scene.control.*;


abstract public class Tile extends Entity {
	public boolean hasLabel = false;
	protected String name = "Tile";

	public Tile() {
		super();
	}

	public void labelSelf() {
		if (hasLabel) {
			this.body.getChildren().add(new Label(this.name));
		}
	}

	/**
	 * Activates the effects of the tile.
	 * @return true if the tile effect runs
	 */
	abstract public boolean tileEffect(Player p);
}