package move;

public class IcePunch extends Move {
	
	public IcePunch() {
		this.name = "IcePunch";
		this.description = "The target is punched with an icy fist. This may also leave the target frozen.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Ice";
		this.statusEffect = "Frozen";
		this.statusChance = 0.2;
	}
}