package move;

public class VineWhip extends Move {
	
	public VineWhip() {
		super();
		this.name = "VineWhip";
		this.description = "The target is struck with slender, whiplike vines to inflict damage.";

		this.power = 45;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 25;
		this.maxPP = 25;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}