package move;

public class HydroPump extends Move {
	
	public HydroPump() {
        this.name = "HydroPump";
		this.description = "The target is blasted by a huge volume of water launched under great pressure.";

		this.power = 110;
		this.accuracy = .8;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}