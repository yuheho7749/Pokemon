package move;

public class AquaTail extends Move {
	
	public AquaTail() {
        this.name = "AquaTail";
        this.description = "The user attacks by swinging its tail as if it were a vicious wave in a raging storm.";

		this.power = 90;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}