package move;

public class RollingKick extends Move {
	
	public RollingKick() {
		this.name = "RollingKick";
		this.description = "The user lashes out with a quick, spinning kick. This may also make the target flinch.";

		this.power = 60;
		this.accuracy = 0.85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fighting";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}