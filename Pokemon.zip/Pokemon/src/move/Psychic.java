package move;

public class Psychic extends Move {
	
	public Psychic() {
		this.name = "Psychic";
		this.description = "The target is hit by a strong telekinetic force. This may also lower confuse the target.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Psychic";
		this.statusEffect = "Confused";
		this.statusChance = 0.3;
	}
}