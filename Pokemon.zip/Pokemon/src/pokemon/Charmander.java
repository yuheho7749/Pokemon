package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Charmander extends Pokemons{
	
	public Charmander(){
		super();
		this.name = "Charmander";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Fire";
		this.type[1] = "Nope";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 39;this.bAtk = 52;this.bDef = 43;
        this.bSpAtk = 60;this.bSpDef = 50;this.bSpd = 65;
		//set ev stats= 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/charmander.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/charmandar.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/charmandar.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	public void update(){}
}

