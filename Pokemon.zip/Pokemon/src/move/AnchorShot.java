package move;

public class AnchorShot extends Move {
	
	public AnchorShot() {
		this.name = "AnchorShot";
		this.description = "The user entangles the target with its anchor chain while attacking, flinching the target in the process.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Steel";
		this.statusEffect = "Flinched";
		this.statusChance = 1;
	}
}