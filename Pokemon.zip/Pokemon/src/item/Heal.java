/**
 * Defines the basic structure of an item "stack".
 * @author
 * @version 1.00.00
 */
 
package item;

import main.*;
import java.util.ArrayList;
import pokemon.*;
 
 public abstract class Heal extends Item{
	protected int healHealth; 
	protected String healStatus; 
	
	
	public Heal(){
		super();
	}
	public Heal(int q) {
		super(q);
	}
	@Override
	public boolean takeEffect(Pokemons p) {
		p.addHealth(p.getHealth() + healHealth); 
		
		if(healStatus.equals("all")){//forloop through status as status will be an arraylist
			ArrayList<String> newStatus = new ArrayList<String>();
			p.setStatus(newStatus);
		}else if(!healStatus.equals("None")){
			
			ArrayList<String> newStatus = p.getStatus();
			for(int i = newStatus.size()-1; i >= 0 ; i--){
				if(healStatus.equals(newStatus.get(i))){
					newStatus.remove(i);
				}
				p.setStatus(newStatus);
			}
			
		}
		
		return true;
	
	
	}

 
 }