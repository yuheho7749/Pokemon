package move;

public class XScissor extends Move {
	
	public XScissor() {
		this.name = "XScissor";
		this.description = "The user slashes at the target by crossing its scythes or claws as if they were a pair of scissors.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Bug";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}