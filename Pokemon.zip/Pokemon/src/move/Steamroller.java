package move;

public class Steamroller extends Move {
	
	public Steamroller() {
		this.name = "Steamroller";
		this.description = "The user crushes its target by rolling over the target with its rolled-up body. This may also make the target flinch.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Bug";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}