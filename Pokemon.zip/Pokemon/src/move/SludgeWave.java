package move;

public class SludgeWave extends Move {
	
	public SludgeWave() {
		this.name = "SludgeWave";
		this.description = "The user strikes everything around it by swamping the area with a giant sludge wave. This may also poison those hit.";

		this.power = 95;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.175;
	}
}