package move;

public class Slam extends Move {
	
	public Slam() {
		super();
		this.name = "Slam";
		this.description = "The target is slammed with a long tail, vines, etc., to inflict damage.";

		this.power = 80;
		this.accuracy = 0.75;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}