package move;

public class ZenHeadbutt extends Move {
	
	public ZenHeadbutt() {
		this.name = "ZenHeadbutt";
		this.description = "The user focuses its willpower to its head and attacks the target. This may also make the target flinch.";

		this.power = 80;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Psychic";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}