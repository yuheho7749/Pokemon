package move;

public class WildCharge extends Move {
	
	public WildCharge() {
		this.name = "WildCharge";
		this.description = "The user shrouds itself in electricity and smashes into its target. This also damages the user a little.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0.25;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 35;
		this.maxPP = 35;

		this.type = "Electric";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}