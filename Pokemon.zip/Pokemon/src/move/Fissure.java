package move;

public class Fissure extends Move {
	
	public Fissure() {
		this.name = "Fissure";
		this.description = "The user opens up a fissure in the ground and drops the target in. The target faints instantly if this attack hits.";

		this.power = 999999;
		this.accuracy = .3;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}