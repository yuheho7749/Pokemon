package move;

public class Peck extends Move {
	
	public Peck() {
		this.name = "Peck";
		this.description = "The target is jabbed with a sharply pointed beak or horn.";

		this.power = 35;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 35;
		this.maxPP = 35;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}