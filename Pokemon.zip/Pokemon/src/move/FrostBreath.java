package move;

public class FrostBreath extends Move {
	
	public FrostBreath() {
		this.name = "FrostBreath";
		this.description = "The user blows its cold breath on the target.";

		this.power = 120;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ice";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}