package move;

public class BeatUp extends Move {
	
	public BeatUp() {
		this.name = "BeatUp";
		this.description = "The user calls its party and trainer to beat the living Magikarp out of the target.";

		this.power = 125;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Dark";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}