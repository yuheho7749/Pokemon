/**
 * Defines the tile that tells a map to transition to another map.
 * @author
 * @version 1.00.00
 */

package tile;

import character.*;
import main.*;
import map.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

public class WarpTile extends Tile {
	private String nextMapName;
	private int spawnToX, spawnToY;

	public WarpTile(String warpName, int x, int y) {
		super();

		this.name = "WarpTile";
		this.nextMapName = warpName;
		this.spawnToX = x;
		this.spawnToY = y;

		Pane design = new Pane();
		Rectangle portal = new Rectangle(Entity.SCALEFACTOR, Entity.SCALEFACTOR);
		// portal.setX(Entity.SCALEFACTOR * .05);
		// portal.setY(Entity.SCALEFACTOR * .05);
		portal.setFill(Color.rgb(50, 50, 50, .5));
		design.getChildren().addAll(portal);

		this.body.getChildren().addAll(design);


		this.labelSelf(); // just for testing purposes
	}

	public String getNextMapName() {return this.nextMapName;}
	public int getSpawnToX() {return this.spawnToX;}
	public int getSpawnToY() {return this.spawnToY;}

	@Override
	public boolean tileEffect(Player p) {
		return true;
	}

}