package move;

public class MegaDrain extends Move {
	
	public MegaDrain() {
		this.name = "MegaDrain";
		this.description = "A tough attack that drains nutrients and restores HP.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 1;
	}
}