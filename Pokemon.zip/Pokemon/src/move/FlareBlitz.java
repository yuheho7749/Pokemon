package move;

public class FlareBlitz extends Move {
	
	public FlareBlitz() {
        this.name = "FlareBlitz";
		this.description = "The user cloaks itself in fire and charges the target. This also damages the user quite a lot. This attack may leave the target with a burn.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.2;
	}
} 