package move;

public class Explosion extends Move {
	
	public Explosion() {
		super();
		this.name = "Explosion";
		this.description = "The user explodes to inflict damage on those around it. The user faints upon using this move.";

		this.power = 500;
		this.accuracy = 1;
		this.recoil = 1;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}