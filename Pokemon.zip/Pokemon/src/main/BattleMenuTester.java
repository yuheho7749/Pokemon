/**
 * Defines the starting application window for Pokemon.
 * @author 
 * @version 1.00.00
 */
package main;
import battlemap.*;
import pokemon.*;

import java.util.*;

import javafx.application.*;
import javafx.animation.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.*;

import javafx.scene.input.*;

import javafx.util.*;
import javafx.geometry.*;
import javafx.event.*;


public class BattleMenuTester extends Application {
	BattleMenu menu = new BattleMenu(900,600/4,new Pikachu());
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		// root.setStyle("-fx-background-color: Black;");




		root.setCenter(menu.getBody());

		Scene scene = new Scene(root);
		
		primaryStage.setScene(scene);
		primaryStage.setTitle("Pokemon: The Original Rip-Off Version");
		primaryStage.setResizable(false);
		primaryStage.sizeToScene();
		primaryStage.show();
	}
}