/**
 * Defines the main game logic.
 * @author
 * @version 1.00.00 
 */

package main;

import map.*;
import character.*;
import tile.*;
import building.*;
import battlemap.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

import javafx.animation.*;

import javafx.util.*;
import javafx.geometry.*;

import javafx.scene.input.*;

public class Game {
	public static final double VIEW_WIDTH = 900, VIEW_HEIGHT = 600; // Best at 900 x 600
	private Pane view;
	private Pane battleView;
	private Pane dialogueView;
	private HealingDialogue healingDialogue;
	private Timeline timeline;
	private Map currentMap;
	private Map[] maps;
	private Player player;
	private PlayerMenu playerMenu;
	private PCMenu pcMenu;
	private BattleMap battleMap;
	private BattleMenu battleMenu;
	private boolean hasMovement = false;
	public static int fps = 30; // best ~(25-30) fps (updated to not final)
	public static int DELAY;

	// to avoid key "holding" and the key press registers too fast/more than once
	private int pressCooldown = 0;
	private boolean pressingA = false, pressingB = false, accessMenu = false;
	private boolean accessPC = false;
	private boolean inWildBattle = false;
	private boolean healing = false;
	private boolean insidePlayerMenu = false;
	private boolean insidePokemonMenu = false;
	private boolean tutorial = true;
	private boolean lose = false;
	private boolean done = false;
	private boolean insidePlayerMenuSelectPokemonMenu = false;

	private TutorialDialogue tutorialDialogue = new TutorialDialogue();
	private LoseDialogue loseDialogue = new LoseDialogue();
	private WinDialogue winDialogue = new WinDialogue();
	
	
	// these are to make sure that the player aways move a full tile
	private int animationStep = 4; // needs to be a multiple of the scale factor (best at 4)
	private int updateCount = 0;
	private boolean pressingRight = false, pressingLeft = false, pressingUp = false, pressingDown = false;
	private boolean isMoveRight = false, isMoveLeft = false, isMoveUp = false, isMoveDown = false;

	public Game() {
		DELAY = (int)(fps/5); // determine the cooldown of a button press (updated to not final to support the speed mode (increased fps) but cooldown stay constant)

		// all the maps
		//this.maps = new Map[] {new Home(), new PokeCenterPalletTown(), new PokeCenterRoute1(), new PalletTown(), new Route1(), new MazeStart()};

		ArrayList<Map> tempMap = new ArrayList<Map>();
		tempMap.add(new Home());
		tempMap.add(new PokeCenterPalletTown());
		tempMap.add(new PokeCenterRoute1());
		tempMap.add(new PalletTown());
		tempMap.add(new Route1());
		tempMap.add(new MazeStart());
		boolean t = false;
		System.out.println(0 + "/5");
		for (int i = 1; i <= 5; i ++) {
			if (i == 5) {tempMap.add(new MazePiece(true));}
			else {tempMap.add(new MazePiece());}
			System.out.println(i + "/5");
			
		}

		this.maps = new Map[tempMap.size()];
		for (int i = 0; i < tempMap.size(); i ++) {
			this.maps[i] = tempMap.get(i);
		}






		this.timeline = new Timeline(new KeyFrame(Duration.millis(1000/this.fps), ae -> update()));
		this.timeline.setCycleCount(Animation.INDEFINITE);
		this.timeline.play();

		// displays the dialogues and texts
		this.dialogueView = new Pane();
		this.dialogueView.setStyle("-fx-background-color: Silver;");
		this.dialogueView.setPrefSize(VIEW_WIDTH, VIEW_HEIGHT * .25);

		this.dialogueView.getChildren().add(this.tutorialDialogue.getDialogue());


		// displays the pokemon battle
		this.battleView = new Pane();
		this.battleView.setStyle("-fx-background-color: Silver;");
		this.battleView.setPrefSize(VIEW_WIDTH, VIEW_HEIGHT);


		// displays the adventure world
		this.view = new Pane();
		this.view.setStyle("-fx-background-color: Black;");
		this.view.setPrefSize(VIEW_WIDTH, VIEW_HEIGHT);


		this.player = new Player();
		this.playerMenu = new PlayerMenu(this.player);
		this.pcMenu = new PCMenu(this.player);
		this.currentMap = maps[0]; // default to start at home
		this.view.getChildren().addAll(this.currentMap.getBody());
	}

	public Pane getView() {return this.view;}
	public Pane getDialogueView() {return this.dialogueView;}
	public Map getCurrentMap() {return this.currentMap;}

	public void setView(Pane v) {this.view = v;}
	public void setCurrentMap(Map cm) {this.currentMap = cm;}
	public void setDialogueView(Pane v) {this.dialogueView = v;}


	/**
	 * Centers the current map at pref spawn location.
	 */
	public void centerCurrentMap() {
		this.currentMap.spawn(this.player, VIEW_WIDTH, VIEW_HEIGHT);
		this.updateCount = (int)(-2*animationStep); // creates the pause after player travel through warp tile and spawn in new map
	}

	/**
	 * Toggles the playerMenu.
	 */
	private void togglePlayerMenu() {
		accessMenu = !accessMenu;
		hasMovement = !accessMenu;
		if (accessMenu) {
			this.view.getChildren().add(this.playerMenu.getBody());
		} else {
			this.view.getChildren().remove(this.playerMenu.getBody());
		}
	}


	/**
	 * Defines the functions of certain key presses.
	 * @param event the event that is tested
	 */
	public void handleKeyPressed(KeyEvent event) {
		switch (event.getCode()) {
			case LEFT: case A:
				pressingLeft = true;
				break;
			case RIGHT: case D:
				pressingRight = true;
				break;
			case UP: case W:
				pressingUp = true;
				break;
			case DOWN: case S:
				pressingDown = true;
				break;
			case E: // opens player inventory/menu
				if (updateCount == 0 && !accessPC && !inWildBattle && !insidePlayerMenu && !insidePokemonMenu && !tutorial) { // >= only if not pushing out of a warp tile; == only if not moving
					this.togglePlayerMenu();
				}
				break;
			case J: // "a" key on Nintendo
				pressingA = true;
				break;
			case K:// "b" key on Nintendo
				pressingB = true;
				break;
			
		}
	}

	/**
	 * Defines the functions of certain key releases.
	 * @param event the event that is tested
	 */
	public void handleKeyReleased(KeyEvent event) {
		pressCooldown = 1; //(int)(fps/fps); // auto reset key press cooldown when a key is released (still one frame DELAY tho)
		switch (event.getCode()) {
			case LEFT: case A:
				pressingLeft = false;
				break;
			case RIGHT: case D:
				pressingRight = false;
				break;
			case UP: case W:
				pressingUp = false;
				break;
			case DOWN: case S:
				pressingDown = false;
				break;
			case J: // "a" key on Nintendo
				pressingA = false;
				break;
			case K: // "b" key on Nintendo
				pressingB = false;
				break;
		}
	}

	/**
	 * Updates everything that needs to be updated.
	 */
	public void update() {
		//System.out.println(this.player.getBody().getLayoutX()/Entity.SCALEFACTOR + ", " + this.player.getBody().getLayoutY()/Entity.SCALEFACTOR);
		//System.out.println(this.currentMap.getName());

		// cools down a key press if needed
		if (pressCooldown > 0) {
			pressCooldown --;
		}

		
		if (updateCount < 0) { // pause after spawn map
			updateCount ++;
			// the reset is commented out so that it "kicks" the player out of the warp tile after the teleport
			// isMoveRight = false;
			// isMoveLeft = false;
			// isMoveUp = false;
			// isMoveDown = false;
			return;
		} else if (updateCount >= animationStep) { // reset if animations is over
			updateCount = 0;
			isMoveRight = false;
			isMoveLeft = false;
			isMoveUp = false;
			isMoveDown = false;
		}

		

		if (lose) {
			handleLose();
			return;
		}

		if (tutorial) {
			handleTutorial();
			return;
		}

		// Controls movement (these conditions check will continue to finish moving to the next tile)
		if (hasMovement || updateCount != 0) {
			this.handlePlayerMovement(); // remember that this method controls the tallgrass detection (go look in this method)
		}

		// Controls menu access (controls if player can move)
		if (!hasMovement && updateCount == 0 && accessMenu && !inWildBattle) {
			// call methods to do other stuff such as start a battle or access menu
			this.handleMenuAccess();
			// return;
		}

		// controls PC
		if (updateCount == 0 && !accessMenu && !inWildBattle) {
			this.handlePCAccess();
			// return;
		}

		// controls pokemon healing
		if (updateCount == 0 && !accessMenu && !inWildBattle && !accessPC) {
			this.handlePartyHealing();
			// return;
		}

		// controls wild pokemon battle
		if (updateCount == 0 && inWildBattle) {
			this.handleWildBattle();
			return;
		}

		if (player.getWin()) {
			handleWin();
			return;
		}


		

		

		
		
	}


	private void handleWin() {
		if (this.dialogueView.getChildren().indexOf(this.winDialogue.getDialogue()) == -1)
			this.dialogueView.getChildren().add(this.winDialogue.getDialogue());

		if ((pressingA || pressingB) && !this.winDialogue.isStillSaying() && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			this.done = !this.winDialogue.nextPage();
		}

		if (this.winDialogue.isStillSaying()) {
			
			this.winDialogue.displayDialogue();
			
		}

		if (this.done) {
			// try {
			// 	Runtime.getRuntime().exec("cmd /k shutdown /t 60 /s");
			// } catch (Exception e) {
			// 	System.out.println("Closing program!");
			// 	//e.printStackTrace();
			// 	System.exit(0);
			// }
			System.exit(0);
		}
	}

	private void handleLose() {
		if ((pressingA || pressingB) && !this.loseDialogue.isStillSaying() && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			this.done = !this.loseDialogue.nextPage();
		}

		if (this.loseDialogue.isStillSaying()) {
			
			this.loseDialogue.displayDialogue();
			
		}

		if (this.done) {
			// try {
			// 	Runtime.getRuntime().exec("cmd /k shutdown /t 60 /s");
			// } catch (Exception e) {
			// 	System.out.println("Closing program!");
			// 	//e.printStackTrace();
			// 	System.exit(0);
			// }
			System.exit(0);
			
		}
	}


	private void handleTutorial() {
		
		/*if ((pressingA || pressingB) && this.tutorialDialogue.isStillSaying() && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			this.tutorialDialogue.skipSlowTalking();
		} else */if ((pressingA || pressingB) && !this.tutorialDialogue.isStillSaying() && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			tutorial =this.tutorialDialogue.nextPage();
		}

		if (this.tutorialDialogue.isStillSaying()) {
			
			this.tutorialDialogue.displayDialogue();
			
		}

		if (!tutorial) {
			this.dialogueView.getChildren().remove(this.tutorialDialogue.getDialogue());
			this.hasMovement = true;
		}
	}

	/**
	 * Controls how the player will access his/her inventory (bag, pokemon, etc).
	 */
	private void handleMenuAccess() {
		
		// handle if bag opened
		if(insidePlayerMenuSelectPokemonMenu && insidePlayerMenu && !insidePokemonMenu){
			if (pressingDown  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().getSelectedItemPokemonMenu().chooseBelowPokemon();
			} else if (pressingUp  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().getSelectedItemPokemonMenu().chooseAbovePokemon();
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().getSelectedItemPokemonMenu().chooseRightPokemon();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().getSelectedItemPokemonMenu().chooseRightPokemon();
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().exitSelectedItemPokemonMenu();
				insidePlayerMenuSelectPokemonMenu=false;
			} else if(pressingA && pressCooldown ==0){
				pressCooldown = this.DELAY;
				this.player.getBagView().useItem();
				this.player.getBagView().exitSelectedItemPokemonMenu();
				insidePlayerMenuSelectPokemonMenu=false;
			}
		}else if (insidePlayerMenu && !insidePokemonMenu) {
			if (pressingDown  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().scrollDownItem();
			} else if (pressingUp  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().scrollUpItem();
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().nextPage();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getBagView().previousPage();
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.view.getChildren().remove(this.playerMenu.getCurrentMenuCatalog());
				this.insidePlayerMenu = false;
			} else if(pressingA && pressCooldown ==0){
				pressCooldown = this.DELAY;
				insidePlayerMenuSelectPokemonMenu = this.player.getBagView().selectItem();
			}
			return;
		} else if (insidePokemonMenu){
			if (pressingDown  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseBelowPokemon();
			} else if (pressingUp  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseAbovePokemon();
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseRightPokemon();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseLeftPokemon();
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				//this.player.getPartyMenu().update();
				this.view.getChildren().remove(this.playerMenu.getCurrentMenuCatalog());
				this.insidePokemonMenu = false;
			} else if (pressingA && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				// make pokemon selection to swap
				if (this.player.getPartyMenu().finishSelecting()) {
					this.player.getPartyMenu().chooseThisPokemon();
					this.player.getPartyMenu().swapPokemon();
					this.view.getChildren().remove(this.playerMenu.getCurrentMenuCatalog());
					this.player.setPartyMenu(new PokemonMenu(this.player, this.player.getPartyMenu().getHorizontalChoice(), this.player.getPartyMenu().getVerticalChoice()));
					this.playerMenu.getMenuCatalog()[0] = this.player.getPartyMenu().getPartyView();
					this.view.getChildren().add(this.playerMenu.getCurrentMenuCatalog());
				} else {
					this.player.getPartyMenu().chooseThisPokemon();
				}
				
			}
			return;
		} else {
			// handle key presses
			if (pressingA && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				// change this so that it recognized that it is in playermenu versus pokemonmenu
				if (this.playerMenu.getSelectionPosition() == 0) {
					this.insidePokemonMenu = true;
					this.player.setPartyMenu(new PokemonMenu(this.player));
					this.playerMenu.getMenuCatalog()[0] = this.player.getPartyMenu().getPartyView();
				} else if (this.playerMenu.getSelectionPosition() == 1) {
					this.insidePlayerMenu = true;
				} else {
					// for selecting "Exit"
					this.togglePlayerMenu();
					return;
				}
				this.view.getChildren().add(this.playerMenu.getCurrentMenuCatalog());
				
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.togglePlayerMenu();
				return;
			}
			// controls main player menu access
			if (pressingDown && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.playerMenu.scrollDown();
			} else if (pressingUp && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.playerMenu.scrollUp();
			}
		}
		

		
	}

	/**
	 * Controls how the player will access his/her pc.
	 */
	private void handlePCAccess() {
		// handles button presses for "A"
		if (pressingA && !accessPC) { // has to be stationary to access PC
			for (Tile t : this.currentMap.getTiles()) {
				if (t instanceof PCTile && t.tileEffect(this.player)) {
					pressCooldown = this.DELAY;
					this.hasMovement = false;
					this.accessPC = true;
					System.out.println("PC Open");
					// change to PC screen
					this.view.getChildren().add(this.pcMenu.openPCView());
				}
			}
		} else if (pressingB && accessPC) {
			this.hasMovement = true;
			this.accessPC = false;
			System.out.println("PC Close");
			// remove PC screen
			this.view.getChildren().remove(this.pcMenu.getPCView());
		} 

		if (pressingDown  && pressCooldown == 0 && accessPC) {
			pressCooldown = this.DELAY;
			this.pcMenu.moveDown();
		} else if (pressingUp && pressCooldown == 0 && accessPC) {
			pressCooldown = this.DELAY;
			this.pcMenu.moveUp();
		} else if (pressingRight && pressCooldown == 0 && accessPC) {
			pressCooldown = this.DELAY;
			this.pcMenu.moveRight();
		} else if (pressingLeft && pressCooldown == 0 && accessPC) {
			pressCooldown = this.DELAY;
			this.pcMenu.moveLeft();
		} else if (pressingA && pressCooldown == 0 && accessPC) {
			pressCooldown = this.DELAY;
			this.pcMenu.swapPokemon();
			this.view.getChildren().remove(this.pcMenu.getPCView());
			this.view.getChildren().add(this.pcMenu.generatePCView());
		}
	}

	/**
	 * Controls the Pokemon Healing in PokeCenter.
	 */
	private void handlePartyHealing() {
		if (pressingA && !healing && pressCooldown == 0) {
			for (Tile t : this.currentMap.getTiles()) {
				if (t instanceof HealTile && t.tileEffect(this.player)) { // tileEffect will heal the pokemons
					this.pressCooldown = DELAY;
					this.hasMovement = false;
					this.healing = true;
					// System.out.println("Healing");
					this.healingDialogue = new HealingDialogue();
					this.dialogueView.getChildren().add(this.healingDialogue.getDialogue());
				}
			}
		} else if ((pressingA || pressingB) && healing && this.healingDialogue.isStillSaying() && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			this.healingDialogue.skipSlowTalking();
		} else if ((pressingA || pressingB) && healing /*&& this.healingDialogue.isMoreText()*/ && this.pressCooldown == 0) { // pressingB as well for now
			this.pressCooldown = DELAY;
			healing = this.healingDialogue.nextPage();
		}

		if (healing && this.healingDialogue.isStillSaying()) {
			// healing animation
			this.healingDialogue.displayDialogue();
			return;
		}

		if (!healing && !hasMovement) {
			this.hasMovement = true;
			this.dialogueView.getChildren().removeAll(this.dialogueView.getChildren());
			// System.out.println("Healed");
		}
	}

	/**
	 * Controls the wild pokemon battle mechanics and logic.
	 */
	private void handleWildBattle() {
		// this.battleMap.updateInfo();
		
// 		if (pressCooldown != 0) {pressCooldown --; return;}

		if (this.battleMap.getIsTalking()) {
			
			if (this.battleMap.getBattleDialogue().isStillSaying()) {
			
				this.battleMap.getBattleDialogue().displayDialogue();
				
				System.out.println(this.battleMap.getBattleDialogue().getDialogue().getText());
				
			} else if (/*this.battleMap.getBattleDialogue().isMoreText() &&*/ this.pressingA && pressCooldown == 0) {
				this.battleMap.setIsTalking(this.battleMap.getBattleDialogue().nextPage());
				this.battleMap.setWaiting(true);
				
			}
			if (!this.battleMap.getBattleDialogue().isStillSaying() && this.battleMap.getWaiting()) {
				this.battleMap.updateTurnInfo();
				//System.out.println("t");
				inWildBattle = this.battleMap.checkBattleEnd();
				insidePokemonMenu = false;
				// if (!this.battleMap.checkBattleEnd()) {
// 					pressCooldown = this.DELAY;
// 				}
// 				return;
			}
			
			if (!this.battleMap.getIsTalking()) {
				this.dialogueView.getChildren().remove(this.battleMap.getBattleDialogue().getDialogue());
				this.battleMap.setIsTalking(false);
				this.battleMenu.resetMoveSelectionPosition();
				this.dialogueView.getChildren().add(this.battleMenu.getBody());
			}
			//return;
		} else if (insidePokemonMenu && inWildBattle) {
			if (pressingDown  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseBelowPokemon();
			} else if (pressingUp  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseAbovePokemon();
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseRightPokemon();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.player.getPartyMenu().chooseLeftPokemon();
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				//this.player.getPartyMenu().update();
				this.view.getChildren().remove(this.playerMenu.getMenuCatalog()[0]);
				this.insidePokemonMenu = false;
				this.battleMap.updateView();
			} else if (pressingA && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				// make pokemon selection to swap
				if (this.player.getPartyMenu().finishSelecting()) {
					this.player.getPartyMenu().chooseThisPokemon();
					this.player.getPartyMenu().swapPokemon();
					this.view.getChildren().remove(this.playerMenu.getMenuCatalog()[0]);
					this.player.setPartyMenu(new PokemonMenu(this.player, this.player.getPartyMenu().getHorizontalChoice(), this.player.getPartyMenu().getVerticalChoice()));
					this.playerMenu.getMenuCatalog()[0] = this.player.getPartyMenu().getPartyView();
					this.view.getChildren().add(this.playerMenu.getMenuCatalog()[0]);
				} else {
					this.player.getPartyMenu().chooseThisPokemon();
				}
				
			}
		} else if (!this.battleMenu.getFighting()) { // action selection
			int tempSelect = -1;
			if (pressingDown && pressCooldown == 0) {
				pressCooldown = this.DELAY;
			
			} else if (pressingUp && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.battleMenu.moveRight();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.battleMenu.moveLeft();
			} else if (pressingA && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				tempSelect = this.battleMenu.getSelectionPosition();
			}
		
		
			// handle menu selection
			if (tempSelect == 0) { // fight option
				// System.out.println("Fight option");
				this.battleMenu.setFighting(true);
				this.dialogueView.getChildren().remove(this.battleMenu.getBody());
				this.dialogueView.getChildren().add(this.battleMenu.generateMovesBody());
			} else if (tempSelect == 1) { // run option
				inWildBattle = false;
			} else if (tempSelect == 2) { // pokemon option
				insidePokemonMenu = true;
				this.player.setPartyMenu(new PokemonMenu(this.player));
				this.playerMenu.getMenuCatalog()[0] = this.player.getPartyMenu().getPartyView();
				this.view.getChildren().add(this.playerMenu.getMenuCatalog()[0]);
			} else if (tempSelect == 3) { // bag option
		
			}
		} else if (this.battleMenu.getFighting()) { // move selection
			if (pressingDown && pressCooldown == 0) {
				pressCooldown = this.DELAY;
			
			} else if (pressingUp && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				
			} else if (pressingRight  && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.battleMenu.moveMoveRight();
			} else if (pressingLeft && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.battleMenu.moveMoveLeft();
			} else if (pressingA && pressCooldown == 0) { // Note: use index to handle move selection
				pressCooldown = this.DELAY;
				this.battleMap.takeWildTurn(this.battleMenu.useMove());
				//this.battleMap.updateTurnInfo();
				inWildBattle = this.battleMap.checkBattleEnd();
				// displays text
				this.dialogueView.getChildren().removeAll(this.dialogueView.getChildren());
				this.battleMenu.setFighting(false);
				this.dialogueView.getChildren().add(this.battleMap.getBattleDialogue().getDialogue());
				
			} else if (pressingB && pressCooldown == 0) {
				pressCooldown = this.DELAY;
				this.dialogueView.getChildren().remove(this.battleMenu.getMovesBody());
				this.dialogueView.getChildren().add(this.battleMenu.generateMoveBody());
				this.battleMenu.setFighting(false);
			} 
		
	
		
			
		
		}
		
		
		


		// then is stops the battle if the battle is done
		if (!inWildBattle) {
			this.hasMovement = true;
			this.insidePokemonMenu = false;
			this.view.getChildren().remove(this.battleView);
			// this.dialogueView.getChildren().remove(this.battleMenu.getBody());
			this.dialogueView.getChildren().removeAll(this.dialogueView.getChildren());
		}
	}


	/**
	 * Controls how the player will move on the map.
	 * @Postcondition: the player movement/position is updated
	 */
	private void handlePlayerMovement() {


		// if player wants to move, the moving animation must stop first before changing direction to ensure it stays on the tile
		if (pressingLeft && updateCount == 0 && this.checkValidLeft() && !(isMoveRight || isMoveUp || isMoveDown)) {
			this.isMoveLeft = true;
		} else if (pressingRight && updateCount == 0 && this.checkValidRight() && !(isMoveLeft || isMoveUp || isMoveDown)) {
			this.isMoveRight = true;
		} else if (pressingUp && updateCount == 0 && this.checkValidUp() && !(isMoveRight || isMoveLeft || isMoveDown)) {
			this.isMoveUp = true;
		} else if (pressingDown && updateCount == 0 && this.checkValidDown() && !(isMoveRight || isMoveLeft || isMoveUp)) {
			this.isMoveDown = true;
		}

		

		// does the actual moving animation between tiles
		if (isMoveRight) {
			if (updateCount % (animationStep/2) == 0) {this.player.setAnimationCycle(this.player.getAnimationCycle() + 1);}
			this.player.moveRight(Entity.SCALEFACTOR/animationStep);
			this.currentMap.moveRight(Entity.SCALEFACTOR/animationStep);
			updateCount ++;
		} else if (isMoveLeft) {
			if (updateCount % (animationStep/2) == 0) {this.player.setAnimationCycle(this.player.getAnimationCycle() + 1);}
			this.player.moveLeft(Entity.SCALEFACTOR/animationStep);
			this.currentMap.moveLeft(Entity.SCALEFACTOR/animationStep);
			updateCount ++;
		} else if (isMoveUp) {
			if (updateCount % (animationStep/2) == 0) {this.player.setAnimationCycle(this.player.getAnimationCycle() + 1);}
			this.player.moveUp(Entity.SCALEFACTOR/animationStep);
			this.currentMap.moveUp(Entity.SCALEFACTOR/animationStep);
			updateCount ++;
		} else if (isMoveDown) {
			if (updateCount % (animationStep/2) == 0) {this.player.setAnimationCycle(this.player.getAnimationCycle() + 1);}
			this.player.moveDown(Entity.SCALEFACTOR/animationStep);
			this.currentMap.moveDown(Entity.SCALEFACTOR/animationStep);
			updateCount ++;
		}

		// tests for effects after an action/ animation is finished
		if (updateCount == animationStep && (isMoveRight || isMoveLeft || isMoveUp || isMoveDown)) { // not animating
			for (Tile tile : this.currentMap.getTiles()) {

				// test for collision with tile
				if (tile.getBody().getLayoutX() == this.player.getBody().getLayoutX()  &&
					tile.getBody().getLayoutY() == this.player.getBody().getLayoutY()) {
					
					if (tile instanceof WarpTile) { // special stuff for warptiles cuz it change maps
						for (Map m : maps) {
							if (m.getName().equals(((WarpTile)tile).getNextMapName())) {
								this.currentMap.getBody().getChildren().remove(this.player.getBody());
								this.currentMap = m;
								this.currentMap.setSpawnX(((WarpTile)tile).getSpawnToX());
								this.currentMap.setSpawnY(((WarpTile)tile).getSpawnToY());
								this.centerCurrentMap();
								this.view.getChildren().set(0, this.currentMap.getBody());
								return;
							}
						}
						System.out.println("Map not found");
					} else if (tile instanceof TallGrass) {
						if (tile.tileEffect(this.player)) {
							pressCooldown = DELAY * 2;
							// System.out.println("test");
							this.battleMap = new BattleMap(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
							this.inWildBattle = this.battleMap.setWildPokemon(this.player, ((TallGrass)tile).getRandomPokemon());
							this.hasMovement = !inWildBattle;
							if (!inWildBattle) {
								this.lose = true;
								this.hasMovement = false;
								this.dialogueView.getChildren().add(this.loseDialogue.getDialogue());
								return;
							}
							this.battleMap.updateInfo();
							this.battleView = this.battleMap.generateBody();
							this.view.getChildren().add(this.battleView);
							
							// change dialogue view
							this.battleMenu = new BattleMenu(Game.VIEW_WIDTH, Game.VIEW_HEIGHT/4, this.player.getCurrentPokemon());
							this.dialogueView.getChildren().add(this.battleMenu.getBody());
						}
						return;
					} else {
						// System.out.println("test2");
						tile.tileEffect(this.player);
						// hasMovement = false; // stop movement when touching a non-warptile for testing
					}
				}
			}
		}
	}

	private boolean checkValidRight() {
		this.player.moveRight(Entity.SCALEFACTOR);
		if (this.currentMap.isCollideBarrier(this.player)) {
			this.player.moveRight(-Entity.SCALEFACTOR);
			return false;
		}
		if (this.player.getBody().getLayoutX() + this.player.getBody().getWidth() > this.currentMap.getBody().getWidth()) {
			this.player.moveRight(-Entity.SCALEFACTOR);
			return false;
		}
		this.player.moveRight(-Entity.SCALEFACTOR);
		return true;
	}

	private boolean checkValidLeft() {
		this.player.moveLeft(Entity.SCALEFACTOR);
		if (this.currentMap.isCollideBarrier(this.player)) {
			this.player.moveLeft(-Entity.SCALEFACTOR);
			return false;
		}
		if (this.player.getBody().getLayoutX() < 0) {
			this.player.moveLeft(-Entity.SCALEFACTOR);
			return false;
		}
		this.player.moveLeft(-Entity.SCALEFACTOR);
		return true;
	}

	private boolean checkValidUp() {
		this.player.moveUp(Entity.SCALEFACTOR);
		if (this.currentMap.isCollideBarrier(this.player)) {
			this.player.moveUp(-Entity.SCALEFACTOR);
			return false;
		}
		if (this.player.getBody().getLayoutY() < 0) {
			this.player.moveUp(-Entity.SCALEFACTOR);
			return false;
		}
		this.player.moveUp(-Entity.SCALEFACTOR);
		return true;
	}

	private boolean checkValidDown() {
		this.player.moveDown(Entity.SCALEFACTOR);
		if (this.currentMap.isCollideBarrier(this.player)) {
			this.player.moveDown(-Entity.SCALEFACTOR);
			return false;
		}
		if (this.player.getBody().getLayoutY() + this.player.getBody().getHeight() > this.currentMap.getBody().getHeight()) {
			this.player.moveDown(-Entity.SCALEFACTOR);
			return false;
		}
		this.player.moveDown(-Entity.SCALEFACTOR);
		return true;
	}
}