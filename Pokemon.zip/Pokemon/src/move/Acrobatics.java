package move;

public class Acrobatics extends Move {
	
	public Acrobatics() {
		this.name = "Acrobatics";
		this.description = "The user nimbly strikes the target. This move always goes first.";

		this.power = 55;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}