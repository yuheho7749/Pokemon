/**
 * Defines the basic structure of a pokemon move.
 * @author
 * @version 1.00.00
 */

package move;

abstract public class Move {
	protected 	String name;
	protected 	String 	description;
	protected  int 	power;
	protected  double 	accuracy;
	protected  double 	recoil;
	protected  boolean isAttack;
	protected  boolean isPhysical;
	protected  int 	pp;
	protected  int 	maxPP = 10;
	protected  String 	type;
	protected  boolean	priority = false; 

// ------ WIP -----
	protected String statusEffect;
	protected double statusChance;
	protected String recoilStatusEffect;
	protected double recoilStatusChance;

//------------------
	
	public String getName(){return name;}
	public String getDescription(){return description;}
	public int getPower(){return power;}
	public double getAccuracy(){return accuracy;}
	public double getRecoil(){return recoil;}
	public boolean getIsAttack(){return isAttack;}
	public boolean getIsPhysical(){return isPhysical;}
	public int getPP(){return pp;}
	public String getType(){return type;}
	public int getMaxPP(){return maxPP;}
	public double getStatusChance(){return statusChance;}
	public String getStatusEffect(){return statusEffect;}
	
	
	public void setPP(int p){pp =p;}
	public void addPP(int value){
		pp += value;
		if(pp<0){
			pp = 0;
		}else if(pp>maxPP){
			pp = maxPP;
		}
	}


	public Move() {

	}

	/**
	 * Keep this
	 */
	public void moveEffect() {

	}

	
}