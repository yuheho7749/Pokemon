package move;

public class DoubleEdge extends Move {
	
	public DoubleEdge() {
		super();
		this.name = "DoubleEdge";
		this.description = "A reckless, life-risking tackle. It also damage the user by a fairly large amount, however.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}