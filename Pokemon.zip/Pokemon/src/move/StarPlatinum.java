package move;

public class StarPlatinum extends Move {
	
	public StarPlatinum() {
		this.name = "StarPlatinum";
		this.description = "Star Platinum! It's not only 'him' that can stop time. OraOraOraOraOraOraOraOraOraOraOraOraOraOraOraOra! Yare yare daze.";
		this.priority = true;

		this.power = Integer.MAX_VALUE;
		this.accuracy = Integer.MAX_VALUE;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = Integer.MAX_VALUE;
		this.maxPP = Integer.MAX_VALUE;

		this.type = "Steel";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}