/**
 * Defines the mazePiece map of pokemon.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

import java.util.ArrayList;

public class MazePiece extends Maze {
	
	public MazePiece() {
		super();

		//creates warp tiles to go to other maps
		//int nextMaze = (int)(Math.random() * mazeCount) + 1;
		ArrayList<Integer> randomStuff = new ArrayList<Integer>();
		randomStuff.add(new Integer(mazeCount + (int)(Math.random() * 3) - 1));
		randomStuff.add(new Integer(mazeCount));
		randomStuff.add(new Integer(mazeCount + 1));
		randomStuff.add(new Integer(mazeCount - 1));

		int nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 0), 10, 21);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 0), 11, 21);
		
		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 21), 10, 0);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 21), 11, 0);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 21, 10), 0, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 21, 11), 0, 11);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 0, 10), 21, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 0, 11), 21, 11);
	}

	public MazePiece(boolean t) {
		super();

		//creates warp tiles to go to other maps
		//int nextMaze = (int)(Math.random() * mazeCount) + 1;
		ArrayList<Integer> randomStuff = new ArrayList<Integer>();
		randomStuff.add(new Integer(mazeCount + (int)(Math.random() * 3) - 1));
		randomStuff.add(new Integer(mazeCount));
		randomStuff.add(new Integer(mazeCount + 1));
		randomStuff.add(new Integer(mazeCount - 1));

		int nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 0), 10, 21);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 0), 11, 21);
		
		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 21), 10, 0);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 21), 11, 0);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 21, 10), 0, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 21, 11), 0, 11);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = randomStuff.remove((int)(Math.random() * randomStuff.size())).intValue();

		this.setTile(new WarpTile("Maze" + nextMaze, 0, 10), 21, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 0, 11), 21, 11);

		if (t) {
			this.setTile(new TallGrass(true), 10, 10);
		}
	}

}