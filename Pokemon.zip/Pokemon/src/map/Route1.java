/**
 * Defines the route1 map of pokemon.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class Route1 extends Map {
	public Route1() {
		super();
		this.name = "Route1";
		this.width = 26;
		this.height = 40;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);
		this.body.setStyle("-fx-background-color: Lightgreen;");

		this.pokemonLevel = 3;

		//note: locations are defined for the grid location not pixel location

		//creates warp tiles to go to other maps
		this.setTile(new WarpTile("PalletTown", 20, 0), 12, 39);
		this.setTile(new WarpTile("PalletTown", 21, 0), 13, 39);

		this.setTile(new WarpTile("Maze0", 10, 21), 12, 0);
		this.setTile(new WarpTile("Maze0", 11, 21), 13, 0);


		// creates the grass tiles
		for (int x = 2; x < 9; x ++) {
			for (int y = 28; y < 38; y ++) {
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		for (int x = 15; x < 24; x ++) {
			for (int y = 34; y < 38; y ++) {
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		for (int x = 14; x < 24; x ++) {
			for (int y = 26; y < 28; y ++) {
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		for (int x = 16; x < 24; x ++) {
			for (int y = 24; y < 26; y ++) {
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		for (int x = 14; x < 24; x ++) {
			for (int y = 21; y < 24; y ++) {
				if (x == 14 && y == 21) {continue;}
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		for (int x = 16; x < 24; x ++) {
			for (int y = 19; y < 21; y ++) {
				if ((x == 16 && y == 19) || (x == 17 && y == 19)) {continue;}
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}
		this.setTile(new TallGrass(this.pokemonLevel), 22, 19);
		this.setTile(new TallGrass(this.pokemonLevel), 23, 19);

		for (int x = 2; x < 10; x ++) {
			for (int y = 4; y < 15; y ++) {
				if ((x == 6 && y == 4) || (x == 7 && y == 4) || (x == 8 && y == 4) || (x == 9 && y == 4) || (x == 7 && y == 5) || (x == 8 && y == 5) || (x == 9 && y == 5) || (x == 9 && y == 6)) {continue;}
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}

		// creates the fences
		for (int x = 9; x < 24; x ++) {
			for (int y = 33; y < 34; y ++) {
				this.setTile(new FenceBarrier(), x, y);
			}
		}

		// creates other trees
		BigTree tree = new BigTree();
		this.setBuilding(tree, 2, 20);
		tree = new BigTree();
		this.setBuilding(tree, 4, 20);
		for (int x = 2; x < 15; x += 2) {
			for (int y = 22; y < 27; y += 2) {
				if ((x == 10 && y == 22) || (x == 12 && y == 22) || (x == 14 && y == 22) || (x == 14 && y == 26)) {continue;}
				tree = new BigTree();
				this.setBuilding(tree, x, y);
			}
		}
		tree = new BigTree();
		this.setBuilding(tree, 20, 8);
		tree = new BigTree();
		this.setBuilding(tree, 22, 8);
		for (int x = 10; x < 23; x += 2) {
			for (int y = 10; y < 15; y += 2) {
				if ((x == 10 && y == 14) || (x == 12 && y == 14)) {continue;}
				tree = new BigTree();
				this.setBuilding(tree, x, y);
			}
		}
		tree = new BigTree();
		this.setBuilding(tree, 2, 2);


		// creates the border of trees
		for (int i = 0; i < width; i += 2) {
			if (i == 12) {i += 2;}
			tree = new BigTree();
			this.setBuilding(tree, i, 0);
			tree = new BigTree();
			this.setBuilding(tree, i, height -2);
		}
		for (int i = 2; i < height - 2; i += 2) {
			tree = new BigTree();
			this.setBuilding(tree, 0, i);
			tree = new BigTree();
			this.setBuilding(tree, width -2, i);
		}


		
		// testing PokeCenter
		PokeCenterBuilding pokeCenterBuilding = new PokeCenterBuilding();
		pokeCenterBuilding.setTile(new WarpTile("PokeCenterRoute1", 5, 8), 3, 4);
		this.setBuilding(pokeCenterBuilding, 17, 2);

		
	}
}