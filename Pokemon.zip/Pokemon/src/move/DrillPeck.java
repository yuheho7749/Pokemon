package move;

public class DrillPeck extends Move {
	
	public DrillPeck() {
		this.name = "DrillPeck";
		this.description = "A corkscrewing attack with a sharp beak acting as a drill.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}