package move;

public class QuickAttack extends Move {
	
	public QuickAttack() {
		super();
		this.name = "QuickAttack";
		this.description = "The user lunges at the target at a speed that makes it almost invisible. It is sure to strike first.";
		
		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;
		
		this.pp = 30;
		this.maxPP = 30;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}