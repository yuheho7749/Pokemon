/**
 * Defines a black barrier.
 * @author
 * @version 1.00.00
 */

package tile;

import main.*;
import character.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

public class VoidBarrier extends Barrier {

	public VoidBarrier() {
		super();
		this.name = "VoidBarrier";
		
		design.setStyle("-fx-background-color: Black;");


		this.labelSelf(); // just for testing purposes
	}

	@Override
	public boolean tileEffect(Player p) {
		return true;
	}
}