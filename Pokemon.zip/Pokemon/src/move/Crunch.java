package move;

public class Crunch extends Move {
	
	public Crunch() {
		this.name = "Crunch";
		this.description = "The user crunches up the target with sharp fangs. This may also flinch the target.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dark";
		this.statusEffect = "Flinched";
		this.statusChance = 0.22;
	}
}