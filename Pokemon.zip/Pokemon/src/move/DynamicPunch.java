package move;

public class DynamicPunch extends Move {
	
	public DynamicPunch() {
		this.name = "DynamicPunch";
		this.description = "The user punches the target with full, concentrated power. This confuses the target if it hits.";

		this.power = 100;
		this.accuracy = .5;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fighting";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}
}