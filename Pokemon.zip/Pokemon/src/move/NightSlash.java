package move;

public class NightSlash extends Move {
	
	public NightSlash() {
		this.name = "NightSlash";
		this.description = "The user slashes the target the instant an opportunity arises.";

		this.power = 70;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dark";
		this.statusEffect = "Flinched";
		this.statusChance = 0.05;
	}
}