package move;

public class RockSlide extends Move {
	
	public RockSlide() {
		this.name = "RockSlide";
		this.description = "Large boulders are hurled at the opposing Pokémon to inflict damage. This may also make the opposing Pokémon flinch.";

		this.power = 75;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Rock";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}