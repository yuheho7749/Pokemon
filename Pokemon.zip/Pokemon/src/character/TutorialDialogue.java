/**
 * Defines the dialogue for tutorial.
 * @author
 * @version 1.00.00
 */

package character;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class TutorialDialogue extends Dialogue{
	

	public TutorialDialogue() {
		super();
		this.textSpeed = Dialogue.SLOW_TEXT_SPEED;


		this.message.add("Welcome to the world of Pokemon. (Press 'J')");
		// this.message.add("I assume you know the basics of Pokemon [the game] so lets go over the controls. (Press 'J')");
		// this.message.add("Listen carefully as you can never access this page again. (Press 'J')");
		// this.message.add("Use 'WASD' to move, 'J' for select, and 'K' to deselect/back.");
		// this.message.add("I will REPEAT this one more time! Use 'WASD' to move, 'J' for select, and 'k' to deselect/back.");
		// this.message.add("Unlike the original Pokemon games, this game does not restrict you to stupid story lines.");
		// this.message.add("You have also been given a free pikachu to start.");
		// this.message.add("However, if you insist, there is an objective in the game.");
		// this.message.add("Your life will depend on what I am about to tell you.");
		// this.message.add("There is a treasure/boss at the end of the Maze of Death.");
		// this.message.add("Unfortunately, you WILL get lost once you wander in the maze TOO much.");
		// this.message.add("It's your choice to go in or not.");
		// this.message.add("Now off you go into the world of Pokemon!!!");
		// this.message.add("Good luck! You're going to need it...");

		
		

	}

}