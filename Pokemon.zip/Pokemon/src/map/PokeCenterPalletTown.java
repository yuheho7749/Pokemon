/**
 * Defines the Pokemon Center in Pallet Town.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class PokeCenterPalletTown extends PokeCenter {
	public PokeCenterPalletTown() {
		super();
		this.name = "PokeCenterPalletTown";

		this.setTile(new WarpTile("PalletTown", 25+3, 4+4), 5, 8);
	}

}