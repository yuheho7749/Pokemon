package move;

public class Bonemerang extends Move {
	
	public Bonemerang() {
		this.name = "Bonemerang";
		this.description = "The user throws the bone it holds. The bone loops around to hit the target twice—coming and going.";

		this.power = 100;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}