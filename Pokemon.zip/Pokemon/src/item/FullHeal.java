	package item;
	import javafx.scene.image.ImageView;
	import main.*;
	import pokemon.*;

public class FullHeal extends Heal{
	
	

	
	public FullHeal(){
		super();
		name = "Full Heal";
		this.description = "Heals the pokemon of all status problems.";
		healHealth = 0;
		healStatus ="all";
		 
	}
	public FullHeal(int q) {
		super(q);
		name = "Full Heal";
		this.description = "Heals the pokemon of all status problems.";
		healHealth = 0;
		healStatus ="all";
		cost = 3000;
		sellPrice = 1500;
	}
	




}