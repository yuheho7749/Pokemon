package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Magnezone extends Pokemons{
	
	public Magnezone(){
		super();
		this.name = "Magnezone";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Electric";
		this.type[1] = "Steel";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 70;this.bAtk = 70;this.bDef = 115;
        this.bSpAtk = 130;this.bSpDef = 90;this.bSpd = 60;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/magnezone.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/magnezone.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/magnezone.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}

	public void update(){}
}

