package move;

public class ThunderWave extends Move {
	
	public ThunderWave() {
		super();
		this.name = "ThunderWave";
		this.description = "A weak electric charge is launched at the foe. It causes paralysis if it hits.";

		this.power = 0;
		this.accuracy = 0.9;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}