package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class Snivy extends Pokemons{
	
	public Snivy(){
		super();
		this.name = "Snivy";
		this.type[0] = "Grass";
		this.body = new Pane();
		pokeball = new PokeBall();
		body.getChildren().add(new Circle(100,Color.GREEN));
		
		this.moveSet[0] = new Struggle();
		//set base stats of Pokemon
		this.bHp = 45;this.bAtk = 45;this.bDef = 66;this.bSpDef = 55;this.bSpAtk = 45;this.bSpd = 63;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		
		this.moveSet[1] = new Tackle();
		this.moveSet[2] = new TailWhip();
		this.moveSet[3] = new QuickAttack();
		this.moveSet[4] = new VineWhip();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

