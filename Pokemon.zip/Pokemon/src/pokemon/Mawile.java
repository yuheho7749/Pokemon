package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class Mawile extends Pokemons{
	
	public Mawile(){
		this.name = "Mawile";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Steel";
		body.getChildren().add(new Circle(100,Color.YELLOW));
		
		this.moveSet[0] = new Struggle();
		//set base stats
		this.bHp = 50;this.bAtk = 100;this.bDef = 125;this.bSpAtk = 55;this.bSpDef = 95;this.bSpd = 50;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpDef = 0;this.evSpAtk = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		
		this.moveSet[1] = new QuickAttack();
		this.moveSet[2] = new Tackle();
		this.moveSet[3] = new Swift();
		this.moveSet[4] = new TailWhip();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

