package move;

public class SkyUppercut extends Move {
	
	public SkyUppercut() {
		this.name = "SkyUppercut";
		this.description = "The user attacks the target with an uppercut thrown skyward with force.";

		this.power = 85;
		this.accuracy = 0.9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}