package move;

public class FirePunch extends Move {
	
	public FirePunch() {
        this.name = "FirePunch";
		this.description = "The target is punched with a fiery fist. This may also leave the target with a burn.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.2;
	}
} 