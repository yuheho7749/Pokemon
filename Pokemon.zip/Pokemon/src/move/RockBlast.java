package move;

public class RockBlast extends Move {
	
	public RockBlast() {
		this.name = "RockBlast";
		this.description = "The user hurls rock-hard rocks at the target.";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Rock";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}