/**
 * Displays the pokemon that the trainer has in the PC.
 * @author
 * @version 1.00.00
 */
package character;


import main.*;
import character.*;
import item.*;
import pokemon.*;

import java.util.ArrayList;

import javafx.stage.*;
import javafx.scene.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.control.*;

import javafx.util.*;
import javafx.geometry.*;

public class PCMenu {
	private Pane pcView = new Pane();
	private Player player;
	private FlowPane layoutFormat = new FlowPane();
	// private FlowPane partyFormat = new FlowPane();
	private int positionSelection = 0;
	private final int pageSize = 36;

	private ArrayList<Pokemons> pcPokemon = new ArrayList<Pokemons>();

	public PCMenu(Player p) {
		this.player = p;
		this.pcView.setStyle("-fx-background-color: Gray;");
		this.pcView.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);

		this.layoutFormat.setPrefSize(Game.VIEW_WIDTH, 5*Game.VIEW_HEIGHT/6);
		// this.layoutFormat.setStyle("-fx-background-color: Blue; -fx-border-width: 1; -fx-border-color: black");
		
		// this.partyFormat.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT/6);
		// this.partyFormat.setLayoutY(5*Game.VIEW_HEIGHT/6);

		this.pcView.getChildren().addAll(this.layoutFormat);

		/*for (int i = 0; i < pageSize - 6; i ++) {

			Pane temp = new Pane();
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1; -fx-border-color: black;");

			layoutFormat.getChildren().add(temp);
		}
		for (int i = pageSize - 6; i < pageSize; i ++) {
			Pane temp = new Pane(); 
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1; -fx-border-color: Red;");

			this.layoutFormat.getChildren().add(temp);
		}

		((Pane)this.layoutFormat.getChildren().get(0)).setStyle("-fx-border-width: 1; -fx-border-color: black; -fx-background-color: Salmon;");
		*/
		
		
		// test
		for (int i = 0; i < 30; i ++) {
			this.pcPokemon.add(new Pikachu());
		}

	}

	public Pane getPCView() {return this.pcView;}
	
	public Pane openPCView() {
		this.positionSelection = 0;
		return this.generatePCView();
	}
	
	public Pane generatePCView() {
		this.pcView.getChildren().remove(this.layoutFormat);
		this.layoutFormat = new FlowPane();
		this.layoutFormat.setPrefSize(Game.VIEW_WIDTH, 5*Game.VIEW_HEIGHT/6);
		this.pcView.getChildren().addAll(this.layoutFormat);
		
		
		for (int i = 0; i < this.pcPokemon.size(); i ++) { // assume the pcPokemon size is less than pageSize - 6

			Pane temp = new Pane();
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1;-fx-border-color: Black;");
			
			this.pcPokemon.get(i).getBattleSprite().setLayoutX(30);
			this.pcPokemon.get(i).getBattleSprite().setLayoutY(15);
			
			temp.getChildren().addAll(this.pcPokemon.get(i).getBattleSprite(), new Label(this.pcPokemon.get(i).getName()));

			layoutFormat.getChildren().add(temp);
		}
		for (int i = this.pcPokemon.size(); i < pageSize - 6; i ++) {

			Pane temp = new Pane();
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1;-fx-border-color: Black;");
			
			layoutFormat.getChildren().add(temp);
		}
		
		for (int i = pageSize - 6; i < pageSize - (6 - this.player.getParty().size()); i ++) {
			Pane temp = new Pane(); 
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1;-fx-border-color: Red;");
			
			this.player.getParty().get(i - 30).getBattleSprite().setLayoutX(30);
			this.player.getParty().get(i - 30).getBattleSprite().setLayoutY(15);
			
			temp.getChildren().addAll(this.player.getParty().get(i - 30).getBattleSprite(), new Label(this.player.getParty().get(i - 30).getName()));
			
			
			this.layoutFormat.getChildren().add(temp);
		}
		for (int i = pageSize - (6 - this.player.getParty().size()); i < pageSize; i ++) {
			Pane temp = new Pane(); 
			temp.setPrefSize(Game.VIEW_WIDTH/6 , Game.VIEW_HEIGHT/6);
			temp.setStyle("-fx-border-width: 1;-fx-border-color: Red;");
			
			
			this.layoutFormat.getChildren().add(temp);
		}

		// BUG: after selection the border will become black even for the party pokemon
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle("-fx-border-width: 1;-fx-border-color: Black;");
		return this.pcView;
	
	}
	
	
	
	
	public void setSelectionPosition(int p) { // maybe used for reseting position to 0 every pc open
		this.positionSelection = p % pageSize;
	}

	// public void updatePlayerPartySprite() {
	// 	for (int i = pageSize - 6; i < pageSize - 6; i ++) { // remove all party pokemon
	// 		((Pane)this.layoutFormat.getChildren().get(i)).getChildren().removeAll(((Pane)this.layoutFormat.getChildren().get(i)).getChildren());
	// 	}
	// 	for (int i = pageSize - 6; i < pageSize - 6 + player.getParty().size(); i ++) {
	// 		// ((Pane)this.layoutFormat.getChildren().get(i)).getChildren().add(player.getParty().get(i - pageSize + 6).getInboxSprite()); // need to ask for inbox sprite
	// 	}
	// }

	/**
	 * Swaps the "selected" Pokemon to the pc or to the party.
	 */
	public void swapPokemon() {
		try {
			if (this.positionSelection < pageSize - 6) {
				this.moveToParty(this.pcPokemon.get(positionSelection)); // pass in pokemon
			} else {
				this.moveToPC(player.getParty().get(6 - (pageSize - positionSelection)));
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.println("Invalid Swap");
		}
	}

	/**
	 * Adds the given pokemon to the pc if pokemon is in party.
	 * @param p pokemon added to pc
	 */
	public void moveToPC(Pokemons p) {
		if (player.getParty().indexOf(p) != -1 && player.getParty().size() > 1) { // shallow check
			player.getParty().remove(p);
			this.pcPokemon.add(p);
			// add sprite to layout format later (ask Mathew for the inboxsprite getter?)
		}

	}

	/**
	 * Adds the given pokemon to the player party if pokemon is in pc and has space in party.
	 * @param p pokemon added to party
	 */
	public void moveToParty(Pokemons p) {
		if (this.pcPokemon.indexOf(p) != -1 && this.player.getParty().size() < 6) { // shallow check
			pcPokemon.remove(p);
			this.player.getParty().add(p);
			// remove sprite from layout format later
		}

	}


	public Pokemons getCurrentTilePokemon() {
		if (positionSelection < pageSize - 6) {
			return pcPokemon.get(positionSelection);
		} else {
			return player.getParty().get(positionSelection - pageSize + 6);
		}
	}



	public void moveRight() {
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Gray;");
		this.positionSelection ++;
		if (this.positionSelection > pageSize - 1) {
			this.positionSelection = 0;
		}
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Salmon;");
	}

	public void moveLeft() {
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Transparent;");
			this.positionSelection --;
		if (this.positionSelection < 0) {
			this.positionSelection = pageSize - 1;
		}
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Salmon;");
	}

	public void moveUp() {
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Transparent;");
		this.positionSelection -= 6;
		if (this.positionSelection < 0) {
			this.positionSelection = pageSize + positionSelection;
		}
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Salmon;");

	}

	public void moveDown() {
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Transparent;");
		this.positionSelection += 6;
		if (this.positionSelection > pageSize - 1) {
			this.positionSelection = positionSelection - pageSize;
		}
		((Pane)this.layoutFormat.getChildren().get(positionSelection)).setStyle(((Pane)this.layoutFormat.getChildren().get(positionSelection)).getStyle() + "-fx-background-color: Salmon;");

	}

}

