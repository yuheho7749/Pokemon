package move;

public class ThousandArrows extends Move {
	
	public ThousandArrows() {
		this.name = "ThousandArrows";
		this.description = "The user attacks with an arrow barrage that flinches the target.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "Flinched";
		this.statusChance = 1;
	}
}