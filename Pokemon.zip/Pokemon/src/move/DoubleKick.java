package move;

public class DoubleKick extends Move {
	
	public DoubleKick() {
		this.name = "DoubleKick";
		this.description = "The target is quickly kicked twice in succession using both feet.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}