package move;

public class WoodHammer extends Move {
	
	public WoodHammer() {
		this.name = "WoodHammer";
		this.description = "	The user slams its rugged body into the target to attack. This also damages the user quite a lot.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}