/**
 * Defines the house of the player.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class Home extends Map {
	public Home() {
		super();
		this.name = "Home";
		this.width = 9;
		this.height = 8;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);
		this.body.setStyle("-fx-background-color: Tan;");


		// defaults spawn location in terms of grid location not pixel location (coordinates count from 0 - 10 and 0 - 6)
		this.spawnX = 4;
		this.spawnY = 3;


		// creates the tiles
		this.setTile(new WarpTile("PalletTown", 29, 20), 4, 7);

		for (int i = 0; i < width; i ++) {
			if (i == 4) {continue;}
			this.setTile(new VoidBarrier(), i , 7);
		}
	}
}