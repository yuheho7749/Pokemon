/**
 * Defines the basic structure for the battle map layouts.
 * @author
 * @version 1.00.00
 */

package battlemap;

import main.*;
import pokemon.*;
import item.*;
import character.*;
import move.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.paint.*;

public class BattleMap {
	protected Pane body;
	protected int turnCount = 0;
	protected Trainer[] trainers = new Trainer[2]; // the two trainers battling
	protected Pokemons[] activePokemons = new Pokemons[2]; // the two pokemon in battle
	protected PokemonSummary[] battleSummary = new PokemonSummary[2]; // health etc of the active pokemon
	
	Pane p1;
	Pane p2;
	Pane s1;
	Pane s2;
	
	protected BattleDialogue battleDialogue;
	// protected BattleDialogue battleDialogue1;
	private boolean isTalking = false;
	private int updateCount = 0;
	
	private Move playerMove;
	private Move wildMove;
	private boolean waiting;

	public BattleMap(double viewWidth, double viewHeight) {
		this.body = new Pane();
		this.body.setPrefSize(viewWidth, viewHeight);

		
		
		
		// for testing
		body.setStyle("-fx-background-color: pink;");
		//body.setOpacity(.5);
		
	}

	public Pane getBody() {return this.body;}
	public boolean getIsTalking() {return this.isTalking;}
	public void setIsTalking(boolean b) {this.isTalking = b;}
	public BattleDialogue getBattleDialogue() {return this.battleDialogue;}
	//public BattleDialogue getBattleDialogue1() {return this.battleDialgoue1;}
	public boolean getWaiting() {return this.waiting;}
	
	public void setWaiting(boolean w) {this.waiting = w;}
	
	
	/**
	 * Sets the two trainers in battle.
	 * @param p1 the first trainer (the player)
	 * @param p2 the second trainer (computer)
	 */
	public void setTrainers(Trainer p1, Trainer p2) {
		this.trainers[0] = p1;
		this.trainers[1] = p2;
		this.activePokemons[0] = this.trainers[0].getParty().get(0);
		this.activePokemons[1] = this.trainers[1].getParty().get(1);
		battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
		battleSummary[1] = new PokemonSummary(this.activePokemons[1]);
		
	}

	/**
	 * Sets the trainer and wild pokemon battle.
	 * @param p1 the player
	 * @param pokemon the wild pokemon
	 * @return true if a wild battle is valid, false otherwise
	 */
	public boolean setWildPokemon(Trainer p1, Pokemons pokemon) {
		this.trainers[0] = p1;
		for (int i = 0; i < this.trainers[0].getParty().size(); i ++) {
			if (this.trainers[0].getParty().get(i).getHealth() > 0) {
				this.activePokemons[0] = this.trainers[0].getParty().get(i);
				break;
			}
			
		}
		// if no player pokemon availble: loses
		if (this.activePokemons[0] == null) {
			//System.out.println("You have no Pokemon! You lose!\nNote: implement losing screen.");
			return false;
		}
		
		this.activePokemons[1] = pokemon;
		battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
		battleSummary[1] = new PokemonSummary(this.activePokemons[1]);
		return true;
	}

	/**
	 * Switches the trainer's active pokemon if the trainer owns the pokemon.
	 * @param p the trainer
	 * @param ps the pokemon
	 * @return true if the swap is successful
	 *
	 
	 CURRENTLY ERRORS 
	 
	public boolean swapActivePokemon(Trainer p, Pokemon ps) {
		for (int i = 0; i < this.trainers.length; i ++) {
			if (p.getId() == t[i].getId()) {
				for (Pokemon pokemon : p.getParty()) {
					if (pokemon.getId() == ps.getId()) {
						activePokemons[i] = p;
						// don't forget to switch body.getChildren()...
					}
				}
			}
		}
	}
	*/

	/**
	 * Takes a wild pokemon battle turn.
	 * @param move the user's move
	 */
	public void takeWildTurn(Move move) {
		this.playerMove = move;
		this.waiting = true;
		//BattleRule.updatePokemonHealth(this.activePokemons[0], this.activePokemons[1], move); // right now defaulted to player goes first
		
		
		
		
		
		// testing text generation
		this.battleDialogue = new BattleDialogue();
		this.battleDialogue.setTextSpeed(Dialogue.SLOW_TEXT_SPEED);
		this.isTalking = true;
		
		this.battleDialogue.addBattleText(this.activePokemons[0], this.activePokemons[1], move);
		
		
		//this.battleDialogue0.skipSlowTalking();
		//System.out.println(this.battleDialogue0.getDialogue().getText());
		
		if (this.activePokemons[1].getHealth() > 0) {
			wildMove = this.activePokemons[1].useRandomMove();
			//BattleRule.updatePokemonHealth(this.activePokemons[1], this.activePokemons[0], wildMove); // then 
			
			// testing text generation
			// this.battleDialogue1 = new BattleDialogue(this.activePokemons[1], this.activePokemons[0], wildMove);
			this.battleDialogue.addBattleText(this.activePokemons[1], this.activePokemons[0], wildMove);
		
			//this.battleDialogue1.skipSlowTalking();
			//System.out.println(this.battleDialogue1.getDialogue().getText());
		} 
		
		updateCount = 0;
		this.updateInfo(); // update health display
		
		
		// if (this.activePokemons[1].getHealth() <= 0) {
// 			return false;
// 		}
// 		
// 		for (int i = 0; i < this.trainers[0].getParty().size(); i ++) {
// 			if (this.trainers[0].getParty().get(i).getHealth() <= 0) {
// 				continue;
// 			}
// 			
// 			// TODO: do correct swapping of pokemon (calls the method instead of the "cheap way" right now) and make new pokemon summary
// 			this.activePokemons[0] = this.trainers[0].getParty().get(i);
// 			battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
// 			this.generateBody();
// 			//this.updateInfo(); // update health display
// 			return true;
// 		}
// 		System.out.println("Your last pokemon fainted. You were forced to flee...");
// 		return false;
	}
	
	public void updatePlayerTurn() {
// 		this.isTalking = true;
		BattleRule.updatePokemonHealth(this.activePokemons[0], this.activePokemons[1], playerMove);
		//this.battleDialogue.addBattleText(this.activePokemons[0], this.activePokemons[1], playerMove);
		if (this.activePokemons[1].getHealth() <= 0) {
			if (activePokemons[1] instanceof TypeNull) {
				((Player)trainers[0]).win();
			}
			this.battleDialogue.errorFix();
			this.battleDialogue.addLevelUpText(this.activePokemons[0]);
			this.battleDialogue.addEndBattleText(this.activePokemons[0], this.activePokemons[1]);
			
			this.activePokemons[0].levelUp();
			this.updateInfo();
		}
	
	}
	
	public void updateWildTurn() {
		if (this.activePokemons[1].getHealth() > 0) {
			//wildMove = this.activePokemons[1].useRandomMove();
			BattleRule.updatePokemonHealth(this.activePokemons[1], this.activePokemons[0], wildMove); // then 
			
			// testing text generation
			// this.battleDialogue1 = new BattleDialogue(this.activePokemons[1], this.activePokemons[0], wildMove);
			//this.battleDialogue.addBattleText(this.activePokemons[1], this.activePokemons[0], wildMove);
		
			//this.battleDialogue1.skipSlowTalking();
			//System.out.println(this.battleDialogue1.getDialogue().getText());
			
			if (this.activePokemons[0].getHealth() <= 0) {
				//this.battleDialogue.errorFix();
				this.battleDialogue.addFaintBattleText(this.activePokemons[1], this.activePokemons[0]);
			}
		} 
	
	
	
	}
	
	public boolean checkBattleEnd() {
		if (!this.battleDialogue.isMoreText() && !this.battleDialogue.isStillSaying() && this.activePokemons[1].getHealth() <= 0) {
			return false;
		}
		
		for (int i = 0; i < this.trainers[0].getParty().size(); i ++) {
			if (this.trainers[0].getParty().get(i).getHealth() <= 0) {
				continue;
			}
			
			// TODO: do correct swapping of pokemon (calls the method instead of the "cheap way" right now) and make new pokemon summary
			this.activePokemons[0] = this.trainers[0].getParty().get(i);
			battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
			this.generateBody();
			this.updateInfo(); // update health display
			return true;
		}
		//System.out.println("Your last pokemon fainted. You were forced to flee...");
		return false;
	
	}

	public void updateView() {
		this.activePokemons[0] = this.trainers[0].getParty().get(0);
		battleSummary[0] = new PokemonSummary(this.activePokemons[0]);
		this.generateBody();
		this.updateInfo(); // update health display
	}
	
	
	public Pane generateBody() {
		this.body.getChildren().removeAll(this.body.getChildren());
		p1 = activePokemons[0].getBattleSprite();
		p2 = activePokemons[1].getBattleSprite();
		s1 = battleSummary[0].getSummary();
		s2 = battleSummary[1].getSummary();
		body.getChildren().addAll(p1,p2,s1,s2);
		activePokemons[0].getBattleSprite().setLayoutX(200);
		activePokemons[0].getBattleSprite().setLayoutY(450);
		activePokemons[1].getBattleSprite().setLayoutX(600);
		activePokemons[1].getBattleSprite().setLayoutY(150);
		s1.setLayoutX(530);
		s1.setLayoutY(390);
		s2.setLayoutX(10);
		s2.setLayoutY(10);
		return body;
	}
	
	public void updateTurnInfo() {
		if (updateCount ==0) {
			updatePlayerTurn();
			//System.out.println("Player");
		}else {
			updateWildTurn();
			//System.out.println("Wild");
		}
		updateInfo();
		updateCount ++;
		waiting = false;
	}
	
	public void updateInfo(){
		battleSummary[0].updateHealth(); 
		battleSummary[1].updateHealth();
	}

}