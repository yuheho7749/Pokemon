package move;

public class NeedleArm extends Move {
	
	public NeedleArm() {
		this.name = "NeedleArm";
		this.description = "The user attacks by wildly swinging its thorny arms. This may also make the target flinch.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}