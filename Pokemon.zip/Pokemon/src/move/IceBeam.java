package move;

public class IceBeam extends Move {
	
	public IceBeam() {
		this.name = "IceBeam";
		this.description = "The target is struck with an icy-cold beam of energy. This may also leave the target frozen.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ice";
		this.statusEffect = "Frozen";
		this.statusChance = 0.3;
	}
}