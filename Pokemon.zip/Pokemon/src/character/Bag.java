/**
 * Displays items that the trainer has, trainer knows what items he has but the bag will display it.
 * @author
 * @version 1.00.00
 */
package character;


import main.*;
import character.*;
import item.*;
import pokemon.*;

import javafx.scene.layout.Pane;
import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.scene.text.Font;




public class Bag {

	private Pane inBag;
	private Player player;
	private VBox[] itemCategories;
	private Pane bagPane;
	private Pane description;
	private Pane infoPane;
	private Text desc;
	private PokemonMenu pMenu;
	private Heal healItem;
	
	private int horizontalSelection = 0;
	private int verticalSelection = 0;

	public Bag(Player p){
		this.player = p;
		bagPane = new Pane();
		this.bagPane.setStyle("-fx-background-color: Green;");
		this.bagPane.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		
		inBag = new Pane();
		
		this.inBag.setStyle("-fx-background-color: Pink;");
		this.inBag.setPrefSize(Game.VIEW_WIDTH/3, Game.VIEW_HEIGHT);
		this.inBag.setLayoutX(Game.VIEW_WIDTH/1.5);
		this.inBag.setLayoutY(100);
		
		
		description = new Pane();
		description.setLayoutX(100);
		description.setLayoutY(100);
		description.setPrefSize(400,300);
		description.setStyle("-fx-background-color: Yellow;");
		
		desc = new Text();
		desc.setX(0);
		desc.setY(100);
		desc.setFont(new Font(20));
		
		
		description.getChildren().add(desc);
		
		this.itemCategories = new VBox[player.getBag().size()];
		for(int i = 0; i < player.getBag().size(); i++){
			this.itemCategories[i] = new VBox();
			this.itemCategories[i].setPrefWidth(Game.VIEW_WIDTH/2);
			this.itemCategories[i].setSpacing(10);
			this.itemCategories[i].setStyle("-fx-background-color: Red;");
			
			for(int j = 0; j < player.getBag().get(i).size(); j++){
				HBox itemRow = new HBox();
				itemRow.setPrefWidth(Game.VIEW_WIDTH/4);
				itemRow.setSpacing(10);
				itemRow.setMaxWidth(Game.VIEW_WIDTH/4);
				Label name = new Label(player.getBag().get(i).get(j).getName());
				name.setStyle("-fx-font-size: 20;");
				name.setMaxWidth(Game.VIEW_WIDTH/4);
			//	Label description = new Label(player.getBag().get(i).get(j).getDescription());
				
				itemRow.getChildren().addAll(name/*, description*/);
				this.itemCategories[i].getChildren().addAll(itemRow);
			}
		}
		if (itemCategories.length != 0) {
			// displays the initial positions/page of the bag
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
			this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		}
		
		
		bagPane.getChildren().addAll(inBag,description);
		updateDesc();
	}

	
	public Pane displayBag(){
		//inBag.getChildren().removeAll(itemCategories);
		// inBag.getChildren().add(itemCategories[horizontalSelection]);
		return bagPane;
	}
	
		
	public void pressA() {
		selectItem();
	
	}
	
	public void nextPage(){
		// remove highlighting of previous stuff
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		}
		this.inBag.getChildren().remove(itemCategories[horizontalSelection]);
		horizontalSelection++;
		if (horizontalSelection >= this.itemCategories.length) { // does page looping
			horizontalSelection = 0;
		}
		// if (this.itemCategories[horizontalSelection].getChildren().size() - 1 < verticalSelection) { // fix for scrolling to shorter page
		// 	verticalSelection = 0;
		// }
		verticalSelection = 0; // resets vertical selection when changing page regardless
		this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		}
		updateDesc();
	}
	public void previousPage(){
		// remove highlighting of previous stuff
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		}
		this.inBag.getChildren().remove(itemCategories[horizontalSelection]);
		horizontalSelection--;
		if (horizontalSelection < 0) {
			horizontalSelection = this.itemCategories.length - 1;
		}
		// if (this.itemCategories[horizontalSelection].getChildren().size() - 1 < verticalSelection) { // fix for scrolling to shorter page
		// 	verticalSelection = 0;
		// }
		verticalSelection = 0; // resets vertical selection when changing page regardless
		this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		}
		updateDesc();
	}
	
	public void scrollUpItem(){
		if (this.itemCategories[horizontalSelection].getChildren().size() == 0) {return;}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		verticalSelection--;
		if (verticalSelection < 0) {
			verticalSelection = this.itemCategories[horizontalSelection].getChildren().size() - 1;
		}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		updateDesc();
	}

	public void scrollDownItem(){
		if (this.itemCategories[horizontalSelection].getChildren().size() == 0) {return;}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		verticalSelection++;
		if (verticalSelection >= this.itemCategories[horizontalSelection].getChildren().size()) {
			verticalSelection = 0;
		}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		updateDesc();
	}
	
	private void updateDesc(){
		desc.setText(player.getBag().get(horizontalSelection).get(verticalSelection).getDescription());
	}
	
	public boolean selectItem(){
		pMenu = new PokemonMenu(player);
		Item selectedItem = player.getBag().get(horizontalSelection).get(verticalSelection);
		if(selectedItem instanceof Heal){
			healItem =(Heal) (selectedItem);
			bagPane.getChildren().add(pMenu.getPartyView());
			return true;
		}else return false;
	}
	
	public void exitSelectedItemPokemonMenu(){
		bagPane.getChildren().remove(pMenu.getPartyView());
	}
	
	public PokemonMenu getSelectedItemPokemonMenu(){
		return pMenu;
	}
	
	public void useItem(){
		
		Pokemons p = pMenu.getSelectedPokemon();
		if(p != null){
			healItem.takeEffect(p);
		}
	}
	
	public Item checkSelectedItem(){
		return player.getBag().get(horizontalSelection).get(verticalSelection);
	}
	
	
	
	


}