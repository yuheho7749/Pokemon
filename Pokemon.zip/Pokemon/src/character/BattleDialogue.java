/**
 * Defines the dialogue for battle info of wild battle.
 * @author
 * @version 1.00.00
 */

package character;

import pokemon.*;
import move.*;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class BattleDialogue extends Dialogue {
	

	public BattleDialogue() {
		super();
		//this.message.add(atk.getName() + " used " + move.getName() +" on " + def.getName() + ".");
		

	}
	
	public void addBattleText(Pokemons atk, Pokemons def, Move move) {
		this.message.add(atk.getName() + " used " + move.getName() +" on " + def.getName() + ".");
	
	
	}
	
	public void addEndBattleText(Pokemons atk, Pokemons def) {
		this.message.add(atk.getName() + " knocked out " + def.getName() + "!                                                             ");
	}
	
	public void addFaintBattleText(Pokemons atk, Pokemons def) {
		this.message.set(this.message.size() -1, this.message.get(this.message.size()-1) + (" "+ atk.getName() + " knocked out " + def.getName() + "!                                                             "));
	}
	
	public void errorFix() {
		this.message.remove(this.message.size() - 1);
	}

	public void addLevelUpText(Pokemons atk) {
		this.message.set(this.message.size() -1, this.message.get(this.message.size()-1) + (" "+ atk.getName() + " leveled up!"));
	}
}