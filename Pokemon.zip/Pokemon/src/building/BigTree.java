/**
 * Defines a big tree.
 * @author
 * @version 1.00.00
 */

package building;

import main.*;
import character.*;
import tile.*;

import java.util.ArrayList;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

public class BigTree extends Building {
	public BigTree() {
		super();
		this.name = "BigTree";
		this.width = 2;
		this.height = 2;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);


		//this can be replaced with actual picture later instead of background color only
		ImageView image = new ImageView("file:res/building/BigTree.png");
		image.setFitWidth(2*Entity.SCALEFACTOR);
		image.setFitHeight(2*Entity.SCALEFACTOR);
		image.setCache(true);
		// image.setLayoutX(Entity.SCALEFACTOR * .1);
		// image.setLayoutY(Entity.SCALEFACTOR * .1);
		this.body.getChildren().add(image);
		

		// create barriers
		for (int i = 0; i < width; i ++) {
			for (int j = 0; j < height; j ++) {
				this.setTile(new Barrier(), i, j);
			}
		}
	}

}