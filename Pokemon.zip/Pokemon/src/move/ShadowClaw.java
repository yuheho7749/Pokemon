package move;

public class ShadowClaw extends Move {
	
	public ShadowClaw() {
		this.name = "ShadowClaw";
		this.description = "The user slashes with a sharp claw made from shadows. ";

		this.power = 70;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Ghost";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}