/**
 * Defines the dialogue for winning the game.
 * @author
 * @version 1.00.00
 */

package character;

import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;

public class WinDialogue extends Dialogue{
	

	public WinDialogue() {
		super();
		this.textSpeed = Dialogue.SLOW_TEXT_SPEED;

		this.message.add("You beat the game!");
		this.message.add("You chose to follow the story line so accept that end result regardless of what it is.");
		this.message.add("The game is completed and the file will be deleted.");
		this.message.add("Good bye!");
		

		
		

	}

}