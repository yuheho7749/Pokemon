package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.image.*;

public class Pikachu extends Pokemons{
	
	public Pikachu(){
		this.name = "Pikachu";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Electric";
		body.getChildren().add(new Circle(100,Color.YELLOW));
		
		this.moveSet[0] = new Struggle();
		//set base stats of Pikachu
		this.bHp = 35;this.bAtk = 55;this.bDef = 30;this.bSpDef = 40;this.bSpAtk = 50;this.bSpd = 90;
		//set ev stats = 0
		this.evHp = 85;this.evAtk = 85;this.evDef = 85;this.evSpDef = 85;this.evSpAtk = 85;this.evSpd = 85;
		this.health = hp;
		finalStatCalc();
		createInboxSprite();
		
		this.moveSet[1] = new QuickAttack();
		this.moveSet[2] = new ThunderBolt();
		this.moveSet[3] = new ThunderWave();
		this.moveSet[4] = new TailWhip();
		//for(int i=0;i<50;i++){levelUp();System.out.println(atk);System.out.println("level:"+level);}
	}
	
	
		
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/pixelchu.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/pixelchu.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/pixelchu.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void update(){}
}

