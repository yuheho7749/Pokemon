package move;

public class FinalGambit extends Move {
	
	public FinalGambit() {
		this.name = "FinalGambit";
		this.description = "The user risks everything to attack its target. This will heavily damage the user.";

		this.power = 500;
		this.accuracy = 1;
		this.recoil = 1;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}