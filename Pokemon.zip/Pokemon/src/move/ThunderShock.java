package move;

public class ThunderShock extends Move {
	
	public ThunderShock() {
		this.name = "ThunderShock";
		this.description = "A jolt of electricity crashes down on the target to inflict damage. This may also leave the target with paralysis.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 30;
		this.maxPP = 30;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.1;
	}
}