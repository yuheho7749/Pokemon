package move;

public class LastResort extends Move {
	
	public LastResort() {
        this.name = "LastResort";
		this.description = "The user strikes with all its might as a last resort.";

		this.power = 1000;
		this.accuracy = 1;
		this.recoil = 0.99;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;
		
		this.pp = 1;
		this.maxPP = 1;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
} 