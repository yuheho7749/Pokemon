package move;

public class BoneClub extends Move {
	
	public BoneClub() {
		this.name = "BoneClub";
		this.description = "The user clubs the target with a bone. This may also make the target flinch";

		this.power = 65;
		this.accuracy = .85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Ground";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}