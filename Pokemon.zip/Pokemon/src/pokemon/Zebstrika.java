package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Zebstrika extends Pokemons{
	
	public Zebstrika(){
		super();
		this.name = "Zebstrika";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Electric";
		this.type[1] = "Nope";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 75;this.bAtk = 100;this.bDef = 63;
        this.bSpAtk = 80;this.bSpDef = 63;this.bSpd = 116;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/zebstrika.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/zebstrika.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/zebstrike.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}

	public void update(){}
}

