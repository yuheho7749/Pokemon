package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Scrafty extends Pokemons{
	
	public Scrafty(){
		super();
		this.name = "Scrafty";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Dark";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 90;this.bAtk = 132;this.bDef = 105;
        this.bSpAtk = 132;this.bSpDef = 105;this.bSpd = 30;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/scraftly.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/scraftly.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/scraftly.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}

	public void update(){}
}