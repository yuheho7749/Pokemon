package move;

public class FeintAttack extends Move {
	
	public FeintAttack() {
		this.name = "FeintAttack";
		this.description = "	The user approaches the target disarmingly, then throws a sucker punch. This move always go first.";

		this.power = 55;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Dark";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}