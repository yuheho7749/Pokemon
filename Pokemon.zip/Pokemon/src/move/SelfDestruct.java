package move;

public class SelfDestruct extends Move {
	
	public SelfDestruct() {
		super();
		this.name = "SelfDestruct";
		this.description = "The user blows up to inflict severe damage, even making itself faint.";

		this.power = 400;
		this.accuracy = 1;
		this.recoil = 1;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}