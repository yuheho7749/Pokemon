/**
 * Defines an invisible barrier.
 * @author
 * @version 1.00.00
 */

package tile;

import main.*;
import character.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

public class Barrier extends Tile {
	public static boolean visible = false; // useless if have image on top
	public static boolean hasCollision = true; // for map making and debugging
	protected StackPane design;

	public Barrier() {
		super();
		this.name = "Barrier";
		
		design = new StackPane();
		design.setPrefSize(Entity.SCALEFACTOR, Entity.SCALEFACTOR);
		design.setStyle("-fx-background-color: Transparent;");

		Rectangle r1 = new Rectangle(Entity.SCALEFACTOR * .2, Entity.SCALEFACTOR);
		Rectangle r2 = new Rectangle(Entity.SCALEFACTOR * .2, Entity.SCALEFACTOR);
		this.body.setStyle("");
		if (visible) {
			// this.body.setStyle("-fx-border-color: Black; -fx-border-width: 1px;");
			r1.setFill(Color.RED);
			r2.setFill(Color.RED);
		} else {
			r1.setFill(Color.TRANSPARENT);
			r2.setFill(Color.TRANSPARENT);
		}
		
		r1.getTransforms().add(new Rotate(45, Entity.SCALEFACTOR * .1, Entity.SCALEFACTOR * .5));
		r2.getTransforms().add(new Rotate(-45, Entity.SCALEFACTOR * .1, Entity.SCALEFACTOR * .5));

		design.getChildren().addAll(r1, r2);
		
		this.body.getChildren().addAll(design);

		
		this.labelSelf(); // just for testing purposes

	}

	public boolean getHasCollision() {return hasCollision;}

	@Override
	public boolean tileEffect(Player p) {
		return true;
	}

}