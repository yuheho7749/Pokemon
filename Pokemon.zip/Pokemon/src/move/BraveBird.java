package move;

public class BraveBird extends Move {
	
	public BraveBird() {
		this.name = "BraveBird";
		this.description = "The user tucks in its wings and charges from a low altitude. This also damages the user quite a lot.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}