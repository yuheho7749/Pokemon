package battlemap;

import main.*;
import pokemon.*;
import character.*;
import move.*;
import item.*;
import java.util.ArrayList;

abstract public class BattleRule{
    
	public static String[] typeList = new String[] {"Normal","Fire","Water","Electric","Grass","Ice","Fighting","Poison","Ground","Flying","Psychic","Bug","Rock","Ghost","Dragon","Dark","Steel","Fairy","Nope"};
	
	public static double[][] superEffectiveChart = new double[][]{
	{1,1,1,1,1,1,1,1,1,1,1,1,.5,0,1,1,.5,1,1},		//Normal
	{1,.5,.5,1,2,2,1,1,1,1,1,2,.5,1,.5,1,2,1,1},		//Fire
	{1,2,.5,1,.5,1,1,1,2,1,1,1,2,1,.5,1,1,1,1},		//Water
	{1,1,2,.5,.5,1,1,1,0,2,1,1,1,1,.5,1,1,1,1},		//Electric
	{1,.5,2,1,.5,1,1,.5,2,.5,1,.5,2,1,.5,1,.5,1,1},	//Grass
	{1,.5,.5,1,2,.5,1,1,2,2,1,1,1,1,2,1,.5,1,1},		//Ice
	{2,1,1,1,1,2,1,.5,1,.5,.5,.5,2,0,1,2,2,.5,1},		//Fighting
	{1,1,1,1,2,1,1,.5,.5,1,1,1,.5,.5,1,1,0,2,1},		//Poison
	{1,2,1,2,.5,1,1,2,1,0,1,.5,2,1,1,1,2,1,1},		//Ground
	{1,1,1,.5,2,1,2,1,1,1,1,2,0.5,1,1,1,0.5,1,1},		//Flying
	{1,1,1,1,1,1,2,2,1,1,.5,1,1,1,1,0,.5,1,1},		//Psychic
	{1,.5,1,1,2,1,.5,.5,1,.5,2,1,1,.5,1,2,.5,.5,1},	//Bug
	{1,2,1,1,1,2,.5,1,.5,2,1,2,1,1,1,1,.5,1,1},		//Rock
	{0,1,1,1,1,1,1,1,1,1,2,1,1,2,1,.5,1,1,1},			//Ghost
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,.5,0,1},			//Dragon
	{1,1,1,1,1,1,.5,1,1,1,2,1,1,2,1,.5,1,.5,1},		//Dark
	{1,.5,.5,.5,1,2,1,1,1,1,1,1,2,1,1,1,.5,2,1},		//Steel
	{1,.5,1,1,1,1,2,.5,1,1,1,1,1,1,2,2,.5,1},			//Fairy
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}				//Nope aka Normalizer for a mono-type Pokemon
	};





    public static int damageCalc(Pokemons attacker, Pokemons defender, Move pm1){
        String atkT1 = attacker.getType1();
        String atkT2 = attacker.getType2();
        String defT1 = defender.getType1();
        String defT2 = defender.getType2();

        double targets = 1; //'0.75 if moves hit more than ONE target || 1 otherwise'
        double weather = 1; //Weather = ' 1.5 if a WATER-TYPE MOVE is being used during RAIN \ a FIRE-TYPE MOVE during HARSH SUNLIGHT 
                            //|| 0.5 if a WATER-TYPE MOVE is used during HARSH SUNLIGHT \ a FIRE-TYPE MOVE during RAIN || 1 otherwise'
        double badge = 1;   //Badge = 'To be Balanced'//Default to 1
        double critz = 1;   //Critz = '2 if Crit || 1 otherwise'
        if(((int)(Math.random()*100)+1)>95){
            critz = 2;
        }

        double rand = Math.random()*((1-0.85)+1)+0.85;    //Random = 'Random number between 0.85 and 1.00 (inclusive) CHECK THIS PLEASE'
        double STAB = 1;    //STAB = '1.5 if the move type matches any of the user types 
                            // 2 if the user of the move additionally has Adaptability ability
                            // 1 otherwise'
                            
        if(pm1.getType().equalsIgnoreCase(atkT1)||pm1.getType().equalsIgnoreCase(atkT2)){
             STAB = 1.5;
        }
        double effective = 1; //Type = '0 (INEFFECTIVE) || 0.25 \ 0.5 (NOT VERY EFFECTIVE) || 1 (NORMALLY EFFECTIVE) || 2 \ 4 (SUPER EFFECTIVE)'
        
        
        // DOUBLE CHECK THE TYPE AND MOVE GETTERS
        int typeListNum1 = searchType(pm1.getType());
        int typeListNum2 = searchType(defT1);
        int typeListNum3 = searchType(defT2);
		

        effective *= superEffectiveChart[typeListNum1][typeListNum2];
        effective *= superEffectiveChart[typeListNum1][typeListNum3];
        

        
        double burn = 1;    //Burn =  '0.5 if the attacker is BURNED,  and the used move is a PHYSICAL move || 1 otherwise'
        for(String bad:attacker.getStatus()){
            if(pm1.getIsPhysical()&&bad.equalsIgnoreCase("Burned")){
                burn = 0.5;
            }
        }

        double other = 1;   //Other = 'Literally other factors, like items, ability, and such'//Default to 1
        double modifier = targets * weather * badge * critz * rand * STAB * effective * burn * other;

        //Set 'a' and 'd' to move's attack&defense type
        int a = attacker.getAtk();int d = defender.getDef();if(!pm1.getIsPhysical()){a = attacker.getSpAtk();d = defender.getSpDef();}
        
        double damage = ( ( ( ( ( 2*attacker.getLevel() ) / 5 ) * pm1.getPower() * (a/d) ) /50 ) + 2 ) * modifier;
        double buff = 1; //To be implemented
        /*-6 levels: 25%
        -5 levels: 29%
        -4 levels: 33%
        -3 levels: 40%
        -2 levels: 50%
        -1 level: 66%
        0 levels: 100%
        1 level: 150%
        2 levels: 200%
        3 levels: 250%
        4 levels: 300%
        5 levels: 350%
        6 levels: 400%*/
        return (int)(damage * buff);
    }
	
	//Update the health of the pokemon after damage calculation. USE THIS METHOD
	public static void updatePokemonHealth(Pokemons atk, Pokemons def, Move m){
        ArrayList<String> bad = atk.getStatus();
        boolean skip = false;
        if(Math.random()<=m.getAccuracy()){

            int damage = damageCalc(atk,def,m);
            if(atk.getIceMult()){damage*=1.5;atk.setIceMult(false);}


            if(Math.random()<m.getStatusChance()){
                def.addStatus(m.getStatusEffect());
            }

		    for(int i=0;i<bad.size();i++){
			    if(bad.get(i).equals("Confused")){
				    if((int)(Math.random()*50)<50){
                        atk.addHealth( (int)(atk.getHealth() * 0.35) );
                        skip = true;
				    }
			    }else if(bad.get(i).equals("Healed")){
                    def.addHealth((int)(damage*.5)+1);
                }else if(bad.get(i).equals("Burned")){
                    //damage*=.9;
                    atk.addHealth((int)(atk.getHp()*0.2));
                }else if(bad.get(i).equals("Flinched")){
                    skip = true;
                }else if(bad.get(i).equals("Poisoned")){
                    damage*=.75;
                    atk.addHealth((int)(atk.getHp()*.05)+(int)(atk.getHealth()*0.05)+1);
                }else if(bad.get(i).equals("Frozen")){
                    skip = true;
                    def.setIceMult(true);
                }
            }
            
            atk.resetStatus();

            if(!skip){
                atk.addHealth( -1*(int)(damage * m.getRecoil()) );
		        def.addHealth( -1*damage );;
            }
        }
		
		
		// fixed so that pokemon does not have negative health
		
		if (atk.getHealth() < 0) {
			atk.setHealth(0);
        }
        // Level up after you win because WE DONT HAVE TIME AHHHHHHHHHHHHHHHHHHHHHHH
		if (def.getHealth() < 0) {
            def.setHealth(0);
            atk.levelUp();
		}
    }

	//Calculate the EXP that the enemy pokemon "Drop"
    public static int expGain(Pokemons p1, Pokemons p2){
        double a = 1;//a = '1 if opponent is wild' || '1.5 if opponent is owned'
        if(p2.getPokeBallType().equals(null)){a=1.5;}
        double b = p2.getBaseExp(); //b = 'Base EXP Yield'
        double L = p2.getLevel();   //L = 'Level of the opponent'
        double V = p1.getLevel();   //V = 'Level of friendly'
        double e = 1;               //e = '1.5 if hold/gain exp boost' //Default to 1
        double p = 1;               //p = 'exp multiplier for certain action' //Default to 1
        double s = 1;               //s = '1 if the winning Pokémon current owner is its Original Trainer||1.5 if the Pokémon was gained in a domestic trade' //Default to 1
        double other = 1;           //other = literally other possible stuff
        double exp = ( ( ((a*b*L) / 5) * ( ( Math.pow((2*L+10),2.5)) / ( Math.pow((L+V+10),2.5) ) ) ) + 1 ) * e * p * s * other;
        return (int)(exp);
    }
    
    //Update the exp of the pokemon after the battle is done. USE THIS METHOD
    public static void updateExp(Pokemons user, Pokemons f){
    	//int xp = expGain(user,f);
    	//user.addExp(xp);
    }
    
    private static int searchType(String type){
    	for(int i=0;i<typeList.length;i++){
    		if(type.equals( typeList[i])){
    			return i;
    		}
    	}
    	return -1;
    }
}



