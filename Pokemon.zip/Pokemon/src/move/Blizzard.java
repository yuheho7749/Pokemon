package move;

public class Blizzard extends Move {
	
	public Blizzard() {
		this.name = "Blizzard";
		this.description = "A howling blizzard is summoned to strike opposing Pokémon. This may also leave the opposing Pokémon frozen.";

		this.power = 110;
		this.accuracy = .7;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Ice";
		this.statusEffect = "Frozen";
		this.statusChance = 0.45;
	}
}