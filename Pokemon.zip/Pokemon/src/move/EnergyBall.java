package move;

public class EnergyBall extends Move {
	
	public EnergyBall() {
		this.name = "EnergyBall";
		this.description = "The user draws power from nature and fires it at the target while healing itself. ";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 1;
	}
}