package move;

public class CloseCombat extends Move {
	
	public CloseCombat() {
		this.name = "CloseCombat";
		this.description = "The user fights the target up close without guarding itself. This also hurts the user a lot.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.33;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}