package move;

public class Waterfall extends Move {
	
	public Waterfall() {
        this.name = "Waterfall";
		this.description = "The user charges at the target and may make it flinch.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Water";
		this.statusEffect = "Flinched";
		this.statusChance = 0.2;
	}
}