package move;

public class Incenerate extends Move {
	
	public Incenerate() {
        this.name = "Incenerate";
		this.description = "The user attacks opposing Pokemon with scorching fire. It will leave the target with a burn.";

		this.power = 25;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 1;
	}
} 