package move;

public class AirCutter extends Move {
	
	public AirCutter() {
		this.name = "AirCutter";
		this.description = "The user launches razor-like wind to slash the opposing Pokémon. ";

		this.power = 70;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}