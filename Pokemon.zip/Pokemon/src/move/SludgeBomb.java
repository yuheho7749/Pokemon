package move;

public class SludgeBomb extends Move {
	
	public SludgeBomb() {
		this.name = "SludgeBomb";
		this.description = "Unsanitary explosive sludge is hurled at the target. This may also poison the target.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.2;
	}
}