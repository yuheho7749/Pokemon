package move;

public class Gust extends Move {
	
	public Gust() {
		this.name = "Gust";
		this.description = "A gust of wind is whipped up by wings and launched at the target to inflict damage.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 35;
		this.maxPP = 35;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}