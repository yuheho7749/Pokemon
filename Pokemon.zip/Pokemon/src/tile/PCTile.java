/**
 * Defines the PC tile used to store pokemon.
 * @author
 * @version 1.00.00
 */

package tile;

import character.*;
import main.*;
import pokemon.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

public class PCTile extends Barrier {

	public PCTile() {
		super();
		this.name = "PCTile";
		

		Rectangle image = new Rectangle(Entity.SCALEFACTOR, Entity.SCALEFACTOR);
		image.setFill(Color.BLUE);

		this.body.getChildren().addAll(image);

		
		this.labelSelf(); // just for testing purposes
	}


	@Override
	public boolean tileEffect(Player p) {
		boolean temp = false;
		if (p.getLookUp()) {
			p.moveUp(Entity.SCALEFACTOR);
			if (this.getBody().getLayoutX() == p.getBody().getLayoutX() &&
				this.getBody().getLayoutY() == p.getBody().getLayoutY()) {
				temp = true;
			}
			p.moveUp(-Entity.SCALEFACTOR);
		}
		// uncomment if they can access from any direction
		// if (p.getLookRight()) {
		// 	p.moveRight(Entity.SCALEFACTOR);
		// 	if (this.getBody().getLayoutX() == p.getBody().getLayoutX() &&
		// 		this.getBody().getLayoutY() == p.getBody().getLayoutY()) {
		// 		temp = true;
		// 	}
		// 	p.moveRight(-Entity.SCALEFACTOR);
		// }
		// if (p.getLookLeft()) {
		// 	p.moveLeft(Entity.SCALEFACTOR);
		// 	if (this.getBody().getLayoutX() == p.getBody().getLayoutX() &&
		// 		this.getBody().getLayoutY() == p.getBody().getLayoutY()) {
		// 		temp = true;
		// 	}
		// 	p.moveLeft(-Entity.SCALEFACTOR);
		// }
		// if (p.getLookDown()) {
		// 	p.moveDown(Entity.SCALEFACTOR);
		// 	if (this.getBody().getLayoutX() == p.getBody().getLayoutX() &&
		// 		this.getBody().getLayoutY() == p.getBody().getLayoutY()) {
		// 		temp = true;
		// 	}
		// 	p.moveDown(-Entity.SCALEFACTOR);
		// }

		return temp;
	}

}