package move;

public class ArmThrust extends Move {
	
	public ArmThrust() {
		this.name = "ArmThrust";
		this.description = "The user lets loose a flurry of open-palmed arm thrusts";

		this.power = 45;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}