package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Ludicolo extends Pokemons{
	
	public Ludicolo(){
		super();
		this.name = "Ludicolo";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Water";
		this.type[1] = "Grass";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 80;this.bAtk = 70;this.bDef = 70;
        this.bSpAtk = 90;this.bSpDef = 100;this.bSpd = 70;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	
	public void update(){}
}

