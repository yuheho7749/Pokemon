package move;

public class RoarOfTime extends Move {
	
	public RoarOfTime() {
		this.name = "RoarOfTime";
		this.description = "The user blasts the target with power that distorts even time.";

		this.power = 150;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Dragon";
		this.statusEffect = "Flinched";
		this.statusChance = 0.5;
	}
}