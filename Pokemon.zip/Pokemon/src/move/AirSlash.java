package move;

public class AirSlash extends Move {
	
	public AirSlash() {
		this.name = "AirSlash";
		this.description = "The user attacks with a blade of air that slices even the sky. This may also make the target flinch.";

		this.power = 75;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Flying";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}