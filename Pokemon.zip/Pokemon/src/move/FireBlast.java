package move;

public class FireBlast extends Move {
	
	public FireBlast() {
        this.name = "FireBlast";
		this.description = "The target is attacked with an intense blast of all-consuming fire. This may also leave the target with a burn.";

		this.power = 110;
		this.accuracy = .85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
} 