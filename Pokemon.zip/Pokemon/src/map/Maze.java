/**
 * Defines the maze map of pokemon.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class Maze extends Map {
	public static int mazeCount = -1;
	public Maze() {
		super();
		mazeCount ++;
		//System.out.println(mazeCount);
		this.name = "Maze" + mazeCount;
		this.width = 22;
		this.height = 22;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);
		this.body.setStyle("-fx-background-color: Lightgreen;");

		this.pokemonLevel = (mazeCount + 1) * 3;

		


		// creates the grass blocks
		for (int x = 2; x < width - 2; x ++) {
			for (int y = 2; y < height - 2; y ++) {
				if ((x == 10 && y == 10) || (x == 11 && y == 11) || (x == 11 && y == 10) || (x == 10 && y == 11)) {continue;}
				this.setTile(new TallGrass(this.pokemonLevel), x, y);
			}
		}


		BigTree tree;

		// creates the border of trees
		for (int i = 0; i < width; i += 2) {
			if (i == 10) {i += 2;}
			tree = new BigTree();
			this.setBuilding(tree, i, 0);
			tree = new BigTree();
			this.setBuilding(tree, i, height -2);
		}
		for (int i = 2; i < height - 2; i += 2) {
			if (i == 10) {i += 2;}
			tree = new BigTree();
			this.setBuilding(tree, 0, i);
			tree = new BigTree();
			this.setBuilding(tree, width -2, i);
		}
	}

}