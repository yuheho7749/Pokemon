package move;

public class LavaPlume extends Move {
	
	public LavaPlume() {
        this.name = "LavaPlume";
		this.description = "The user torches everything around it in an inferno of scarlet flames. This may also leave those it hits with a burn.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
} 