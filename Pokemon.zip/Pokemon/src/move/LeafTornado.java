package move;

public class LeafTornado extends Move {
	
	public LeafTornado() {
		this.name = "LeafTornado";
		this.description = "The user attacks its target by encircling it in sharp leaves and flinching the target.";

		this.power = 65;
		this.accuracy = .9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Flinched";
		this.statusChance = 1;
	}
}