package move;

public class AerialAce extends Move {
	
	public AerialAce() {
		this.name = "AerialAce";
		this.description = "The user confounds the target with speed, then slashes. This move always goes first.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Flying";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}