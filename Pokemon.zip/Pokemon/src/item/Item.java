/**
 * Defines the basic structure of an item "stack".
 * @author
 * @version 1.00.00
 */

package item;
import main.*;
import pokemon.*;


abstract public class Item extends Entity{
	protected String description;
	protected int quanity; // number of items this "stack" has
	protected int cost; 
	protected int sellPrice;
	protected String name;

	public String getDescription(){return description;}
	public String getName(){return name;}
	public int getQuanity(){return quanity;}
	public int getCost(){return cost;} 
	public int getSellPrice(){return sellPrice;}

	public void setDescription(String s){description = s;}
	public void setQuanity(int q){quanity = q;}


	public Item() {
		this.quanity = 1;
	}
	public Item(int q) {
		this.quanity = q;
	}
	
	abstract public boolean takeEffect(Pokemons p);
	

}