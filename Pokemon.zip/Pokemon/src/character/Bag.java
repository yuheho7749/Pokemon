/**
 * Displays items that the trainer has, trainer knows what items he has but the bag will display it.
 * @author
 * @version 1.00.00
 */
package character;


import main.*;
import character.*;
import item.*;

import javafx.scene.layout.Pane;
import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;





public class Bag {

	private Pane inBag = new Pane();
	private Player player;
	private VBox[] itemCategories;
	
	private int horizontalSelection = 0;
	private int verticalSelection = 0;

	public Bag(Player p){
		this.player = p;

		this.inBag.setStyle("-fx-background-color: Green;");
		//this.inBag.setOpacity(.5);
		this.inBag.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);

		this.itemCategories = new VBox[player.getBag().size()];
		for(int i = 0; i < player.getBag().size(); i++){
			this.itemCategories[i] = new VBox();
			this.itemCategories[i].setPrefWidth(Game.VIEW_WIDTH/2);
			this.itemCategories[i].setSpacing(10);
			this.itemCategories[i].setStyle("-fx-background-color: Red;");
			
			for(int j = 0; j < player.getBag().get(i).size(); j++){
				HBox itemRow = new HBox();
				itemRow.setSpacing(10);
				Label name = new Label(player.getBag().get(i).get(j).getName());
				name.setStyle("-fx-font-size: 20;");
				Label description = new Label(player.getBag().get(i).get(j).getDescription());
				
				itemRow.getChildren().addAll(name, description);
				this.itemCategories[i].getChildren().addAll(itemRow);
			}
		}
		if (itemCategories.length != 0) {
			// displays the initial positions/page of the bag
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
			this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		}
		
	}

	
	public Pane displayBag(){
		//inBag.getChildren().removeAll(itemCategories);
		// inBag.getChildren().add(itemCategories[horizontalSelection]);
		return inBag;
	}
	
		
	public void pressA() {
		
	
	}
	
	public void nextPage(){
		// remove highlighting of previous stuff
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		}
		this.inBag.getChildren().remove(itemCategories[horizontalSelection]);
		horizontalSelection++;
		if (horizontalSelection >= this.itemCategories.length) { // does page looping
			horizontalSelection = 0;
		}
		// if (this.itemCategories[horizontalSelection].getChildren().size() - 1 < verticalSelection) { // fix for scrolling to shorter page
		// 	verticalSelection = 0;
		// }
		verticalSelection = 0; // resets vertical selection when changing page regardless
		this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		}
	}
	public void previousPage(){
		// remove highlighting of previous stuff
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		}
		this.inBag.getChildren().remove(itemCategories[horizontalSelection]);
		horizontalSelection--;
		if (horizontalSelection < 0) {
			horizontalSelection = this.itemCategories.length - 1;
		}
		// if (this.itemCategories[horizontalSelection].getChildren().size() - 1 < verticalSelection) { // fix for scrolling to shorter page
		// 	verticalSelection = 0;
		// }
		verticalSelection = 0; // resets vertical selection when changing page regardless
		this.inBag.getChildren().add(itemCategories[horizontalSelection]);
		if (this.itemCategories[horizontalSelection].getChildren().size() != 0) {
			((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
		}
	}
	
	public void scrollUpItem(){
		if (this.itemCategories[horizontalSelection].getChildren().size() == 0) {return;}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		verticalSelection--;
		if (verticalSelection < 0) {
			verticalSelection = this.itemCategories[horizontalSelection].getChildren().size() - 1;
		}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
	}

	public void scrollDownItem(){
		if (this.itemCategories[horizontalSelection].getChildren().size() == 0) {return;}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: Transparent");
		verticalSelection++;
		if (verticalSelection >= this.itemCategories[horizontalSelection].getChildren().size()) {
			verticalSelection = 0;
		}
		((HBox)itemCategories[horizontalSelection].getChildren().get(verticalSelection)).setStyle("-fx-background-color: LightBlue");
	}


}