package move;

public class WaterSpout extends Move {
	
	public WaterSpout() {
        this.name = "WaterSpout";
		this.description = "The user spouts water to damage opposing Pokemon.";

		this.power = 150;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}