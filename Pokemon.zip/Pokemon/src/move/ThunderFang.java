package move;

public class ThunderFang extends Move {
	
	public ThunderFang() {
		this.name = "ThunderFang";
		this.description = "The user bites with electrified fangs. This may also leave the target with paralysis.";

		this.power = 65;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = .1;
	}
}