/**
 * Defines the outside images of the player's house.
 * @author
 * @version 1.00.00
 */

package building;

import main.*;
import character.*;
import tile.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

public class HomeBuilding extends Building {
	public HomeBuilding() {
		super();
		this.name = "HomeBuilding";
		this.width = 5;
		this.height = 3;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);


		//this can be replaced with actual picture later instead of background color only
		this.body.setStyle(this.body.getStyle() + "-fx-background-color: Brown;");
		

		// create tile and barriers
		for (int i = 0; i < width; i ++) {
			for (int j = 0; j < height; j ++) {
				if (!(i == 2 && j == 2)) {
					this.setTile(new Barrier(), i, j);
				}
			}
		}

		this.setTile(new WarpTile("Home", 4, 7), 2, 2);
	}

}