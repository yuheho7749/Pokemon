package move;

public class SeedBomb extends Move {
	
	public SeedBomb() {
		this.name = "SeedBomb";
		this.description = "The user slams a barrage of hard-shelled seeds down on the target from above that might sets fire.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "Burned";
		this.statusChance = 0.2;
	}
}