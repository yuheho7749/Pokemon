package move;

public class AuroraBeam extends Move {
	
	public AuroraBeam() {
		this.name = "AuroraBeam";
		this.description = "The target is hit with a rainbow-colored beam.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Ice";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}