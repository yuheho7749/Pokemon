package move;

public class ShadowSneak extends Move {
	
	public ShadowSneak() {
		this.name = "ShadowSneak";
		this.description = "The user extends its shadow and attacks the target from behind. This move always goes first.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Ghost";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}