/**
 * Defines the starting application window for Pokemon.
 * @author 
 * @version 1.00.00
 */

package main;

import java.util.*;

import javafx.application.*;
import javafx.animation.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.*;

import javafx.scene.input.*;

import javafx.util.*;
import javafx.geometry.*;
import javafx.event.*;

import tile.*;


public class Pokemon extends Application {
	private Game game;

	public static void main(String[] args) {
		// for quick dev mode startup
		try {
			if (args.length == 0) {
				System.out.println("Default Mode:");
			} else {
				for (String s:args) {
					int colon = s.indexOf(":");
					String tag = s.toLowerCase().substring(0, colon);
					if (tag.equals("pre") || tag.equals("preset")) {
						if (s.toLowerCase().substring(colon + 1).equals("true-")){
							System.out.print("Preset- Developer ");
							Game.fps = 50;
							Entity.SCALEFACTOR = 32;
							// Entity.enableHitBox = true;
							// Barrier.visible = true;
							// Barrier.hasCollision = false;
							// break; // for when dft override other options
						} else if (s.toLowerCase().substring(colon + 1).equals("true")){
							System.out.print("Preset Developer ");
							Game.fps = 50;
							Entity.SCALEFACTOR = 32;
							Entity.enableHitBox = true;
							// Barrier.visible = true;
							// Barrier.hasCollision = false;
							// break; // for when dft override other options
						} else if (s.toLowerCase().substring(colon + 1).equals("true+v")){
							System.out.print("Preset+ Developer ");
							Game.fps = 50;
							Entity.SCALEFACTOR = 32;
							Entity.enableHitBox = true;
							Barrier.visible = true;
							// Barrier.hasCollision = false;
							// break; // for when dft override other options
						} else if (s.toLowerCase().substring(colon + 1).equals("true+c")){
							System.out.print("Preset+ Developer ");
							Game.fps = 50;
							Entity.SCALEFACTOR = 32;
							Entity.enableHitBox = true;
							// Barrier.visible = true;
							Barrier.hasCollision = false;
							// break; // for when dft override other options
						} else if (s.toLowerCase().substring(colon + 1).equals("true++")){
							System.out.print("Preset+ Developer ");
							Game.fps = 50;
							Entity.SCALEFACTOR = 32;
							Entity.enableHitBox = true;
							Barrier.visible = true;
							Barrier.hasCollision = false;
							// break; // for when dft override other options
						} else {
							throw new Exception(); // go to catch statement
						}
					} else if (tag.equals("hbx") || tag.equals("hitbox")) {
						if (s.toLowerCase().substring(colon + 1).equals("true")){
							Entity.enableHitBox = true;
						} else if (s.toLowerCase().substring(colon + 1).equals("false")) {
							Entity.enableHitBox = false;
						} else {
							throw new Exception(); // go to catch statement
						}
					} else if (tag.equals("col") || tag.equals("collision")) {
						if (s.toLowerCase().substring(colon + 1).equals("true")){
							Barrier.hasCollision = true;
						} else if (s.toLowerCase().substring(colon + 1).equals("false")) {
							Barrier.hasCollision = false;
						} else {
							throw new Exception(); // go to catch statement
						}
					} else if (tag.equals("vis") || tag.equals("visible")) {
						if (s.toLowerCase().substring(colon + 1).equals("true")){
							Barrier.visible = true;
						} else if (s.toLowerCase().substring(colon + 1).equals("false")) {
							Barrier.visible = false;
						} else {
							throw new Exception(); // go to catch statement
						}
					} else if (tag.equals("fps")) {
						Game.fps = Math.abs(Integer.parseInt(s.substring(colon + 1)));
						if (Game.fps == 0) {
							System.out.println("Fps cannot be 0");
							throw new Exception();
						}
					} else if (tag.equals("scl") || tag.equals("scale") || tag.equals("scalefactor")) {
						Entity.SCALEFACTOR = Math.abs(Integer.parseInt(s.substring(colon + 1)));
						if (Entity.SCALEFACTOR % 4 != 0 || Entity.SCALEFACTOR == 0) {
							System.out.println("Scalefactor must be multiple of 4 (cannot be 0)");
							throw new Exception();
						}
					} else {
						throw new Exception(); // go to catch statement
					}
				}
				System.out.println("Custom Mode:");
			}
			System.out.println("Fps: " + Game.fps);
			System.out.println("Scalefactor: " + Entity.SCALEFACTOR);
			System.out.println("HitBox: " + Entity.enableHitBox);
			System.out.println("Barrier Visible: " + Barrier.visible);
			System.out.println("Barrier Collision: " + Barrier.hasCollision);
		} catch (Exception e) {
			System.out.println("Application failed to open due to incorrect usage...\n\nCorrect Usages (only input/change the options you wish to modify):");
			System.out.println("Default: java -cp bin main.Pokemon");
			System.out.println("Custom: java -cp bin main.Pokemon pre:[boolean] fps:[int] scl:[int] hbx:[boolean] vis:[boolean] col:[boolean]");
			System.exit(0); // stopping the program before application launch
		}

		// If everything ok, launch application
		System.out.println("\nApplication starting...");
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		// root.setStyle("-fx-background-color: Black;");


		this.game = new Game();


		root.setCenter(this.game.getView());
		root.setBottom(this.game.getDialogueView());

		Scene scene = new Scene(root);
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode().equals(KeyCode.ESCAPE)) {Platform.exit();} // hard kills the program
				game.handleKeyPressed(event);
			}
		});

		scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				game.handleKeyReleased(event);
			}
		});
		
		primaryStage.setScene(scene);
		primaryStage.setTitle("Pokemon: The Original Rip-Off Version");
		primaryStage.setResizable(false);
		primaryStage.sizeToScene();
		primaryStage.show();
		
		this.game.centerCurrentMap(); // must center after the show() cuz that is when the pane and everything has a width, height, etc
	}
}