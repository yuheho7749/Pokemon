/**
 * Displays items that the trainer has, trainer knows what items he has but the bag will display it.
 * @author
 * @version 1.00.00
 */
package character;


import main.*;
import character.*;
import pokemon.*;
import item.*;
import battlemap.*;

import java.util.ArrayList;

import javafx.stage.*;
import javafx.scene.*;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.control.*;

import javafx.util.*;
import javafx.geometry.*;
public class PokemonMenu {
	
	private Pane partyView;
	private Player player;
	private FlowPane layoutFormat;
	private int[] firstPk = new int[] {-1,-1}; 
	private int[] secondPk = new int[] {-1,-1};
	
	private Pane[][] pokemonOrder = new Pane[3][2];
	private int verticalChoice; 
	private int horizontalChoice;
	
	
	

	public PokemonMenu(Player p) {
		this.player = p;
		this.partyView = new Pane();
		this.layoutFormat = new FlowPane();
		this.verticalChoice = 0;
		this.horizontalChoice = 0;
		this.partyView.setStyle("-fx-background-color: Salmon;");
		this.partyView.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		this.layoutFormat.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		
	
		int i = 0; 
		for(int k = 0; k < pokemonOrder.length; k++){
			for(int l = 0; l < pokemonOrder[k].length; l++){
			
				
				//note to self: change this part, currently it will fill all of the pokemon menu with panes even if there is no pokemon
				
				
				Pane pokemonSummary = new Pane();
				pokemonSummary.setPrefSize(Game.VIEW_WIDTH/2, Game.VIEW_HEIGHT/3);
				pokemonSummary.setStyle("-fx-background-color: Blue");
				BorderStroke border = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(5));
				pokemonSummary.setBorder(new Border(border));
				
			
				
				//puts all pokemon in player's party into the menu
				if(i < player.getParty().size()){
				
					Pane pokemonBody = player.getParty().get(i).getInboxSprite();
					pokemonBody.setLayoutX(5);
					pokemonBody.setLayoutY(5);

					
					
					PokemonSummary pokemonInfo = new PokemonSummary(player.getParty().get(i),0.9);
					pokemonInfo.updateHealth(); // Alex, y u no update health, bro. Fixed it for u - Joseph Ng
					pokemonInfo.summary.setStyle("-fx-background-color: transparent");
					pokemonInfo.hpNum.setX(10);
					pokemonInfo.hpNum.setY(120);
					Pane info = new Pane();
					info.getChildren().add(pokemonInfo.getSummary());
					info.setLayoutX(Game.VIEW_WIDTH/10);
					info.setLayoutY(5);
					
			
			
					pokemonSummary.getChildren().add(pokemonBody);
					pokemonSummary.getChildren().add(info);
					
					
					i++;
				}
				
				
				
				pokemonOrder[k][l] = pokemonSummary;
			}
		}	
		for(int m = 0; m < pokemonOrder.length; m++){
			for(int n = 0; n < pokemonOrder[m].length; n++){
				layoutFormat.getChildren().add(pokemonOrder[m][n]);
			}
		}
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
		partyView.getChildren().add(layoutFormat);
		
	
	}

	public PokemonMenu(Player p, int x, int y) {
		this.player = p;
		this.partyView = new Pane();
		this.layoutFormat = new FlowPane();
		this.verticalChoice = y;
		this.horizontalChoice = x;
		this.partyView.setStyle("-fx-background-color: Salmon;");
		this.partyView.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		this.layoutFormat.setPrefSize(Game.VIEW_WIDTH, Game.VIEW_HEIGHT);
		
	
		int i = 0; 
		for(int k = 0; k < pokemonOrder.length; k++){
			for(int l = 0; l < pokemonOrder[k].length; l++){
			
				
				//note to self: change this part, currently it will fill all of the pokemon menu with panes even if there is no pokemon
				
				
				Pane pokemonSummary = new Pane();
				pokemonSummary.setPrefSize(Game.VIEW_WIDTH/2, Game.VIEW_HEIGHT/3);
				pokemonSummary.setStyle("-fx-background-color: Blue");
				BorderStroke border = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(5));
				pokemonSummary.setBorder(new Border(border));
				
			
				
				//puts all pokemon in player's party into the menu
				if(i < player.getParty().size()){
				
					Pane pokemonBody = player.getParty().get(i).getInboxSprite();
					pokemonBody.setLayoutX(5);
					pokemonBody.setLayoutY(5);

					
					
					PokemonSummary pokemonInfo = new PokemonSummary(player.getParty().get(i),0.9);
					pokemonInfo.updateHealth(); // Alex, y u no update health, bro. Fixed it for u - Joseph Ng
					pokemonInfo.summary.setStyle("-fx-background-color: transparent");
					pokemonInfo.hpNum.setX(10);
					pokemonInfo.hpNum.setY(120);
					Pane info = new Pane();
					info.getChildren().add(pokemonInfo.getSummary());
					info.setLayoutX(Game.VIEW_WIDTH/10);
					info.setLayoutY(5);
					
			
			
					pokemonSummary.getChildren().add(pokemonBody);
					pokemonSummary.getChildren().add(info);
					
					
					i++;
				}
				
				
				
				pokemonOrder[k][l] = pokemonSummary;
			}
		}	
		for(int m = 0; m < pokemonOrder.length; m++){
			for(int n = 0; n < pokemonOrder[m].length; n++){
				layoutFormat.getChildren().add(pokemonOrder[m][n]);
			}
		}
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
		partyView.getChildren().add(layoutFormat);
		
	
	}
	
	public Pane getPartyView() {return partyView;}
	public int getVerticalChoice() {return this.verticalChoice;}
	public int getHorizontalChoice() {return this.horizontalChoice;}

	public boolean finishSelecting() {
		return firstPk[0] != -1;

	}
	
	
	//note to self: prevent player from moving the selection bar pass the pokemon they have; ie only 1 pokemon yet can move in the menu for other slots
	//also need to implement in game to see if works
	
	
	//navigation of the pokemon menu
	public void chooseRightPokemon(){
		//resets old selection back to original color
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		
		if((verticalChoice == firstPk[0] && horizontalChoice == firstPk[1]) || (verticalChoice == secondPk[0] && horizontalChoice == secondPk[1])){
			pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Yellow");
		}
		
		horizontalChoice++;
		 
		if(horizontalChoice > 1){
			horizontalChoice = 0;
		}
		//selected box will be highlighted
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseLeftPokemon(){
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		
		if((verticalChoice == firstPk[0] && horizontalChoice == firstPk[1]) || (verticalChoice == secondPk[0] && horizontalChoice == secondPk[1])){
			pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Yellow");
		}
		horizontalChoice--;
		 
		if(horizontalChoice < 0){
			horizontalChoice = 1;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseAbovePokemon(){
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		
		if((verticalChoice == firstPk[0] && horizontalChoice == firstPk[1]) || (verticalChoice == secondPk[0] && horizontalChoice == secondPk[1])){
			pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Yellow");
		}
		verticalChoice--;
		 
		if(verticalChoice < 0){
			verticalChoice = 2;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	public void chooseBelowPokemon(){
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Blue");
		
		if((verticalChoice == firstPk[0] && horizontalChoice == firstPk[1]) || (verticalChoice == secondPk[0] && horizontalChoice == secondPk[1])){
			pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Yellow");
		}
		verticalChoice++;
		
		if(verticalChoice > 2){
			verticalChoice = 0;
		}
		
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: White");
	}
	
	/*
		Selects the pokemon that is currently being highlighted. Saves only the location of two pokemons
		Also I know i have bad variable names ;(  plz dont roast me
	*/
	
	public void chooseThisPokemon(){
		if ((this.player.getParty().size() - 1) / 2 < verticalChoice || ((this.player.getParty().size() - 1) / 2 == verticalChoice && (this.player.getParty().size() - 1) % 2 < horizontalChoice)) {
			// System.out.println("test");
			return;
		}
		pokemonOrder[verticalChoice][horizontalChoice].setStyle("-fx-background-color: Yellow");
		if(firstPk[0] == -1){
			firstPk[0] = verticalChoice;		//first pokemon position (x and y) on the menu(pane[][])
			firstPk[1] = horizontalChoice;
		}else if (secondPk[0] == -1){			//second pokemon position
			secondPk[0] = verticalChoice;
			secondPk[1] = horizontalChoice;
		}
	}
	
	public void swapPokemon(){
		int pkPos = -1; 
		int secPkPos = -1;
		int counter = 0;
		for(int k = 0; k < pokemonOrder.length; k++){
			for(int l = 0; l < pokemonOrder[k].length; l++){
				if(k == firstPk[0] && l == firstPk[1]){		//Finds the position of the pokemons in the players party (arrayList)
					pkPos = counter;
				}
				if(k == secondPk[0] && l == secondPk[1]){
					secPkPos = counter; 
				}
				counter++;
			}
		}
		
		
		if(pkPos != -1 && secPkPos  != -1){
			
			Pokemons firstSwitch = player.getParty().get(pkPos); //Switches the two pokemon in the player's party 
			player.getParty().set(pkPos, player.getParty().get(secPkPos));
			player.getParty().set(secPkPos, firstSwitch);
			
			
			Pane secondSwitch = pokemonOrder[firstPk[0]][firstPk[1]];		//Switches the panes belonging to the pokemons in the menu
			pokemonOrder[firstPk[0]][firstPk[1]] = pokemonOrder[secondPk[0]][secondPk[1]];
			pokemonOrder[secondPk[0]][secondPk[1]] = secondSwitch;
			
			firstPk = new int[] {-1, -1};	//resets the positions for the next swap
			secondPk = new int[] {-1,-1};
		}
		
	}
	
	public Pokemons getSelectedPokemon(){
		if((pokemonOrder.length*verticalChoice)+(pokemonOrder[verticalChoice].length*verticalChoice)>=player.getParty().size()){
			return null;
		}else return player.getParty().get((pokemonOrder.length*verticalChoice)+(pokemonOrder[verticalChoice].length*verticalChoice));
	}
	
}