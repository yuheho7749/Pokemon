	package item;
	import javafx.scene.image.ImageView;
	import main.*;
	import pokemon.*;

public class MaxPotion extends Heal{
	

	
	

	
	public MaxPotion(){
		super();
		name = "Max Potion";
		this.description = "Completely restores the max HP.";
		healHealth = 999;
		healStatus ="None";
		cost = 2500;
		sellPrice = 1250;
	}
	public MaxPotion(int q) {
		super(q);
		name = "Max Potion";
		this.description = "Completely restores the max HP.";
		healHealth = 999;
		healStatus ="None";
		cost = 2500;
		sellPrice = 1250;
	}
	



}