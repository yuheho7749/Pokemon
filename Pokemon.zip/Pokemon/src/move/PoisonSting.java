package move;

public class PoisonSting extends Move {
	
	public PoisonSting() {
		this.name = "PoisonSting";
		this.description = "";

		this.power = 15;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 35;
		this.maxPP = 35;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.2;
	}
}