package move;

public class ShadowBall extends Move {
	
	public ShadowBall() {
		this.name = "ShadowBall";
		this.description = "	The user hurls a shadowy blob at the target.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Ghost";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}