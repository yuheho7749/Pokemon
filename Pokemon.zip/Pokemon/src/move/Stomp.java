package move;

public class Stomp extends Move {
	
	public Stomp() {
		super();
		this.name = "Stomp";
		this.description = "The target is stomped with a big foot. It may also make the target flinch.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Normal";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}