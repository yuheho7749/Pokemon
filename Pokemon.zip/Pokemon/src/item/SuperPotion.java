	package item;
	import javafx.scene.image.ImageView;
	import main.*; 
	import pokemon.*;

public class SuperPotion extends Heal{
	
	
	
	public SuperPotion(){
		super();
		name = "Super Potion";
		this.description = "Restores 50 HP.";
		healHealth = 50;
		healStatus ="None";
		cost = 700;
		sellPrice = 350;
	}
	public SuperPotion(int q) {
		super(q);
		name = "Super Potion";
		this.description = "Restores 50 HP.";
		healHealth = 50;
		healStatus ="None";
		cost = 700;
		sellPrice = 350;
	}


}