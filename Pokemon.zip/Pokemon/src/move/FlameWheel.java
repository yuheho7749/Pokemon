package move;

public class FlameWheel extends Move {
	
	public FlameWheel() {
        this.name = "FlameWheel";
		this.description = "The user cloaks itself in fire and charges at the target. This may also leave the target with a burn.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 25;
		this.maxPP = 25;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
} 