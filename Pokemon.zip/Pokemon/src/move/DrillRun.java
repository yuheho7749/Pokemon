package move;

public class DrillRun extends Move {
	
	public DrillRun() {
		this.name = "DrillRun";
		this.description = "	The user crashes into its target while rotating its body like a drill. ";

		this.power = 80;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}