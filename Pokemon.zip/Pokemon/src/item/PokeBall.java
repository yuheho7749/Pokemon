/**
 * Defines a pokeball.
 * @author
 * @version 1.00.00
 */

package item;

import main.*;
import pokemon.*;


public class PokeBall extends Item {
	protected double successRate = .25;

	public PokeBall() {
		super();
		name = "Pokeball";
		this.description = "A normal pokeball.";
		cost = 200;
		sellPrice = 100;
	}

	public PokeBall(int q) {
		super(q);
		name = "Pokeball";
		this.description = "A normal pokeball.";
		cost = 200;
		sellPrice = 100;
	}
	
	public double getSuccessRate() {return this.successRate;}

	@Override
	public boolean takeEffect(Pokemons p) {
		this.quanity -= 1;
		if (Math.random() < this.successRate) {
			System.out.println("Captured Pokemon"); // testing only
			return true;
		} else {
			System.out.println("Capture failed"); // testing only
			return false;
		}
		
	}


}