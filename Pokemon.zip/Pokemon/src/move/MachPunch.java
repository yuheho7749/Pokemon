package move;

public class MachPunch extends Move {
	
	public MachPunch() {
		this.name = "MachPunch";
		this.description = "The user throws a punch at blinding speed. This move always goes first.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}