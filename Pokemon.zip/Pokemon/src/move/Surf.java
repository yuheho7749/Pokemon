package move;

public class Surf extends Move {
	
	public Surf() {
        this.name = "Surf";
		this.description = "The user attacks everything around it by swamping its surroundings with a giant wave.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Water";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}