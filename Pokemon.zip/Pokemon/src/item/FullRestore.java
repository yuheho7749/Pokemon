	package item;
	import javafx.scene.image.ImageView;
	import main.*;
	import pokemon.*;
	

public class FullRestore extends Heal{
	
	
	
	
	
	public FullRestore(){
		super();
		name = "Full Restore";
		this.description = "Fully restores HP & status.";
		healHealth = 999;
		healStatus ="all";
		cost = 3000;
		sellPrice = 1500;
	}
	public FullRestore(int q) {
		super(q);
		name = "Full Restore";
		this.description = "Fully restores HP & status.";
		healHealth = 999;
		healStatus ="all";
		cost = 3000;
		sellPrice = 1500;
	}
	


}