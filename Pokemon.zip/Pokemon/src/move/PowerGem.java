package move;

public class PowerGem extends Move {
	
	public PowerGem() {
		this.name = "PowerGem";
		this.description = "The user attacks with a ray of light that sparkles as if it were made of gemstones.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Rock";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}