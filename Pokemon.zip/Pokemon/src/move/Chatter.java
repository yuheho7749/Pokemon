package move;

public class Chatter extends Move {
	
	public Chatter() {
		this.name = "Chatter";
		this.description = "The user attacks the target with sound waves of deafening chatter. This confuses the target.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Flying";
		this.statusEffect = "Confused";
		this.statusChance = 0.2;
	}
}