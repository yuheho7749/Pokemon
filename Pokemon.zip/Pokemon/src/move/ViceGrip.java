package move;

public class ViceGrip extends Move {
	
	public ViceGrip() {
		super();
		this.name = "ViceGrip";
		this.description = "The target is gripped and squeeed from both sides to inflict damage";

		this.power = 55;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 30;
		this.maxPP = 30;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}