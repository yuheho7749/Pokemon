package move;

public class LeafBlade extends Move {
	
	public LeafBlade() {
		this.name = "LeafBlade";
		this.description = "The user handles a sharp leaf like a sword and attacks by cutting its target. ";

		this.power = 111;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}