package move;

public class Acid extends Move {
	
	public Acid() {
		this.name = "Acid";
		this.description = "The opposing Pokémon are attacked with a spray of harsh acid. This may also flinch them.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Poison";
		this.statusEffect = "Flinched";
		this.statusChance = 0.15;
	}
}