package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Jumpluff extends Pokemons{
	
	public Jumpluff(){
		super();
		this.name = "Jumpluff";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Grass";
		this.type[1] = "Flying";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 75;this.bAtk = 55;this.bDef = 70;
        this.bSpAtk = 55;this.bSpDef = 85;this.bSpd = 110;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/jumpluff.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/jumpluff.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/jumpluff.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	public void update(){}
}

