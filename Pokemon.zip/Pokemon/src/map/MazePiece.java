/**
 * Defines the mazePiece map of pokemon.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class MazePiece extends Maze {
	
	public MazePiece() {
		super();

		//creates warp tiles to go to other maps
		//int nextMaze = (int)(Math.random() * mazeCount) + 1;
		int nextMaze = mazeCount + (int)(Math.random() * 3) - 1;

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 0), 10, 21);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 0), 11, 21);
		
		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = mazeCount;

		this.setTile(new WarpTile("Maze" + nextMaze, 10, 21), 10, 0);
		this.setTile(new WarpTile("Maze" + nextMaze, 11, 21), 11, 0);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = mazeCount + 1;

		this.setTile(new WarpTile("Maze" + nextMaze, 21, 10), 0, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 21, 11), 0, 11);

		//nextMaze = (int)(Math.random() * mazeCount) + 1;
		nextMaze = mazeCount - 1;

		this.setTile(new WarpTile("Maze" + nextMaze, 0, 10), 21, 10);
		this.setTile(new WarpTile("Maze" + nextMaze, 0, 11), 21, 11);
	}

	// public MazePiece(boolean t) {
	// 	super();

	// 	//creates warp tiles to go to other maps
	// 	//int nextMaze = (int)(Math.random() * mazeCount) + 1;
	// 	int nextMaze = mazeCount + 1;

	// 	this.setTile(new WarpTile("Maze0", 12, 0), 10, 21);
	// 	this.setTile(new WarpTile("Maze0", 13, 0), 11, 21);
		
	// 	//nextMaze = (int)(Math.random() * mazeCount) + 1;
	// 	nextMaze = mazeCount + 1;

	// 	this.setTile(new WarpTile("Maze" + nextMaze, 10, 21), 10, 0);
	// 	this.setTile(new WarpTile("Maze" + nextMaze, 11, 21), 11, 0);

	// 	//nextMaze = (int)(Math.random() * mazeCount) + 1;
	// 	nextMaze = mazeCount + 1;

	// 	this.setTile(new WarpTile("Maze" + nextMaze, 21, 10), 0, 10);
	// 	this.setTile(new WarpTile("Maze" + nextMaze, 21, 11), 0, 11);

	// 	//nextMaze = (int)(Math.random() * mazeCount) + 1;
	// 	nextMaze = mazeCount + 1;

	// 	this.setTile(new WarpTile("Maze" + nextMaze, 0, 10), 21, 10);
	// 	this.setTile(new WarpTile("Maze" + nextMaze, 0, 11), 21, 11);
	// }

}