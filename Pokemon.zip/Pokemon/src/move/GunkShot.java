package move;

public class GunkShot extends Move {
	
	public GunkShot() {
		this.name = "GunkShot";
		this.description = "The user shoots filthy garbage at the target to attack. This may also poison the target.";

		this.power = 120;
		this.accuracy = .8;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.3;
	}
}