/**
 * Ultra ball.
 * @author
 * @version 1.00.00
 */

package item;

import main.*;
import pokemon.*;


public class UltraBall extends PokeBall {
	

	public UltraBall() {
		super();
		this.name = "Ultra Ball";
		this.description = "An even better Pokeball.";
		successRate = 0.75;
	}

	public UltraBall(int q) {
		super(q);
		this.name = "Ultra Ball";
		this.description = "An even better Pokeball.";
		successRate = 0.75;
	}




}