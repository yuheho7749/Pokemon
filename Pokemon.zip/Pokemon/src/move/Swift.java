package move;

public class Swift extends Move {
	
	public Swift() {
		super();
		this.name = "Swift";
		this.description = "Star-shaped rays are shot at the opposing team. This attack never misses.";

		this.power = 60;
		this.accuracy = Integer.MAX_VALUE;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
	
	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}