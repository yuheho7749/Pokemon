package move;

public class Nuzzle extends Move {
	
	public Nuzzle() {
		this.name = "Nuzzle";
		this.description = "The user attacks by nizzling its electrified cheeks against the target. This also leaves the target with paralysis.";

		this.power = 20;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}