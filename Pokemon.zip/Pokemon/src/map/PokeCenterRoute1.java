/**
 * Defines the Pokemon Center in Route 1.
 * @author
 * @version 1.00.00
 */

package map;

import main.*;
import tile.*;
import building.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class PokeCenterRoute1 extends PokeCenter {
	public PokeCenterRoute1() {
		super();
		this.name = "PokeCenterRoute1";

		this.setTile(new WarpTile("Route1", 17+3, 2+4), 5, 8);
	}

}