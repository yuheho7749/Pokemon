package move;

public class Spark extends Move {
	
	public Spark() {
		this.name = "Spark";
		this.description = "The user throws an electrically charged tackle at the target. This may also leave the target with paralysis.";

		this.power = 65;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = .3;
	}
}