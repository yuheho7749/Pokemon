package move;

public class BulletPunch extends Move {
	
	public BulletPunch() {
		this.name = "BulletPunch";
		this.description = "The user strikes the target with tough punches as fast as bullets. This move always goes first.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Steel";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}