/**
 * Defines the tall grass.
 * @author
 * @version 1.00.00
 */

package tile;

import character.*;
import main.*;
import pokemon.*;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

public class TallGrass extends Tile {
	private double encounterChance = 0.1;
	private Pokemons[] availablePokemon = new Pokemons[] {new Pikachu(), new Abomasnow(), new Absol(), new Accelgor(), new Aerodactyl(), new Aggron(), new Alakazam(), new Altaria(), new Arbok(), new Bannet(), new Beedrill(), new Bewear(), new Braviary(), new Bonsly()};
	private boolean bossTile = false;

	public TallGrass() {
		super();
		this.name = "TallGrass";

		
		
		
		for (Pokemons temp:this.availablePokemon) {
			for (int i = 0; i < (int)(Math.random() * 3); i ++) {
				temp.levelUp();
			}
		}
		

		// Pane design = new Pane();
		// Rectangle grass = new Rectangle(Entity.SCALEFACTOR * .9, Entity.SCALEFACTOR * .9);
		// grass.setX(Entity.SCALEFACTOR * .05);
		// grass.setY(Entity.SCALEFACTOR * .05);
		// grass.setFill(Color.rgb(0, 175, 0));
		// design.getChildren().addAll(grass);

		ImageView image = new ImageView("file:res/tile/TallGrass.png");
		image.setFitWidth(Entity.SCALEFACTOR);
		image.setFitHeight(Entity.SCALEFACTOR);
		image.setCache(true);

		this.body.getChildren().addAll(image);

		this.labelSelf(); // just for testing purposes


	}
	public TallGrass(int level) {
		super();
		this.name = "TallGrass";

		
		

		
		for (Pokemons temp:this.availablePokemon) {
			for (int i = 0; i < level; i ++) {
				temp.levelUp();
			}
			for (int i = 0; i < (int)(Math.random() * 3); i ++) {
				temp.levelUp();
			}
		}

		// Pane design = new Pane();
		// Rectangle grass = new Rectangle(Entity.SCALEFACTOR * .9, Entity.SCALEFACTOR * .9);
		// grass.setX(Entity.SCALEFACTOR * .05);
		// grass.setY(Entity.SCALEFACTOR * .05);
		// grass.setFill(Color.rgb(0, 175, 0));
		// design.getChildren().addAll(grass);

		ImageView image = new ImageView("file:res/tile/TallGrass.png");
		image.setFitWidth(Entity.SCALEFACTOR);
		image.setFitHeight(Entity.SCALEFACTOR);
		image.setCache(true);

		this.body.getChildren().addAll(image);

		this.labelSelf(); // just for testing purposes


	}


	public TallGrass(boolean boss) {
		super();
		this.name = "TallGrass";

		
		this.bossTile = true;
		this.encounterChance = 1;

		this.availablePokemon = new Pokemons[] {new TypeNull()};
		for (Pokemons temp:this.availablePokemon) {
			for (int i = 0; i < 1; i ++) {
				temp.levelUp();
			}
			for (int i = 0; i < (int)(Math.random() * 3); i ++) {
				temp.levelUp();
			}
		}

		// Pane design = new Pane();
		// Rectangle grass = new Rectangle(Entity.SCALEFACTOR * .9, Entity.SCALEFACTOR * .9);
		// grass.setX(Entity.SCALEFACTOR * .05);
		// grass.setY(Entity.SCALEFACTOR * .05);
		// grass.setFill(Color.rgb(0, 175, 0));
		// design.getChildren().addAll(grass);

		ImageView image = new ImageView("file:res/tile/TallGrass.png");
		image.setFitWidth(Entity.SCALEFACTOR);
		image.setFitHeight(Entity.SCALEFACTOR);
		image.setCache(true);

		this.body.getChildren().addAll(image);

		this.labelSelf(); // just for testing purposes


	}

	public double getEncounterChance() {return this.encounterChance;}
	public boolean isBossTile() {return this.bossTile;}

	public Pokemons getRandomPokemon() {
		Pokemons wildPokemon = this.availablePokemon[(int)(Math.random() * this.availablePokemon.length)];
		wildPokemon.setHealth(wildPokemon.getHp()); // TODO: restore all the pokemon's stats
		return wildPokemon;
	}

	public void setEncounterChance(double ec) {this.encounterChance = ec;}

	public void setAvailablePokemon(Pokemons[] p) {this.availablePokemon = p;} 

	@Override
	public boolean tileEffect(Player p) {
		if (Math.random() < this.encounterChance && (!p.getWin() || this.bossTile)) {
			// System.out.println("Wild Pokemon encountered"); 
			return true;
		}
		return false;
	}

}