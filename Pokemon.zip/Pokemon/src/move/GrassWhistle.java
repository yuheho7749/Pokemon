package move;

public class GrassWhistle extends Move {
	
	public GrassWhistle() {
		this.name = "GrassWhistle";
		this.description = "The user plays a pleasant melody that lulls the target into a deep sleep.";

		this.power = 0;
		this.accuracy = .55;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Grass";
		this.statusEffect = "Slept";
		this.statusChance = 1;
	}
}