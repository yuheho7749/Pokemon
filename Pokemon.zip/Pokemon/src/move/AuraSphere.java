package move;

public class AuraSphere extends Move {
	
	public AuraSphere() {
		this.name = "AuraSphere";
		this.description = "The user lets loose a blast of aura power from deep within its body at the target.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = true;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}