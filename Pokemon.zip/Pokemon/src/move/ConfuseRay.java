package move;

public class ConfuseRay extends Move {
	
	public ConfuseRay() {
		this.name = "ConfuseRay";
		this.description = "	The target is exposed to a sinister ray that triggers confusion.";

		this.power = 0;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = false;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ghost";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}
}