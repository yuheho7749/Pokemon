package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;
public class Toucannon extends Pokemons{
	
	public Toucannon(){
		super();
		this.name = "Toucannon";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Flying";
		this.type[1] = "Fire";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 80;this.bAtk = 120;this.bDef = 75;
        this.bSpAtk = 75;this.bSpDef = 75;this.bSpd = 60;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/toucannon.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/toucannon.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/toucannon.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}
	
	public void update(){}
}

