/**
 * Defines the Heal tile used to heal your party of pokemon.
 * @author
 * @version 1.00.00
 */

package tile;

import character.*;
import main.*;
import pokemon.*;

import java.util.ArrayList;

import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;

public class HealTile extends Barrier {

	public HealTile() {
		super();
		this.name = "HealTile";
		

		Rectangle image = new Rectangle(Entity.SCALEFACTOR, Entity.SCALEFACTOR);
		image.setFill(Color.GREEN);

		this.body.getChildren().addAll(image);

		
		this.labelSelf(); // just for testing purposes
	}


	@Override
	public boolean tileEffect(Player p) {
		boolean temp = false;
		if (p.getLookUp()) {
			p.moveUp(Entity.SCALEFACTOR);
			if (this.getBody().getLayoutX() == p.getBody().getLayoutX() &&
				this.getBody().getLayoutY() == p.getBody().getLayoutY()) {
				temp = true;
			}
			p.moveUp(-Entity.SCALEFACTOR);
		}

		if (temp) {
			for (int i = 0; i < p.getParty().size(); i ++) {
				// restore health
				p.getParty().get(i).setHealth(p.getParty().get(i).getHp());
				//System.out.println(p.getParty().get(i).getHealth());
				//System.out.println(p.getParty().get(i).getHp());
				// restore pp
				for (int j = 0; j < p.getParty().get(i).getMoveSet().length; j ++) {
					p.getParty().get(i).getMoveSet()[j].setPP(p.getParty().get(i).getMoveSet()[j].getMaxPP()); 
				}
				// restore status
				p.getParty().get(i).setStatus(new ArrayList<String>());
			}
		}
		return temp;
	}

}