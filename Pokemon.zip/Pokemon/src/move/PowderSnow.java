package move;

public class PowderSnow extends Move {
	
	public PowderSnow() {
		this.name = "PowderSnow";
		this.description = "The user attacks with a chilling gust of powdery snow. This may also freeze the opposing Pokémon.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Ice";
		this.statusEffect = "Frozen";
		this.statusChance = 0.3;
	}
}