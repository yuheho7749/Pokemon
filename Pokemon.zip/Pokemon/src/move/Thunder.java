package move;

public class Thunder extends Move {
	
	public Thunder() {
		this.name = "Thunder";
		this.description = "A wicked thunderbolt is dropped on the target to inflict damage. This may also leave the target with paralysis.";

		this.power = 120;
		this.accuracy = .7;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = .3;
	}
}