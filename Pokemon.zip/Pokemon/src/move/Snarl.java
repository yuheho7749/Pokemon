package move;

public class Snarl extends Move {
	
	public Snarl() {
		this.name = "Snarl";
		this.description = "The user yells as if it's ranting about something, which confuses the target.";

		this.power = 55;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Dark";
		this.statusEffect = "Confused";
		this.statusChance = 1;
	}
}