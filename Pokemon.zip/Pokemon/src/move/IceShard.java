package move;

public class IceShard extends Move {
	
	public IceShard() {
		this.name = "IceShard";
		this.description = "The user flash-freezes chunks of ice and hurls them at the target. This move always goes first.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = true;

		this.pp = 30;
		this.maxPP = 30;

		this.type = "Ice";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}