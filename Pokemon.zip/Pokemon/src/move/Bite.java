package move;

public class Bite extends Move {
	
	public Bite() {
		this.name = "Bite";
		this.description = "The target is bitten with viciously sharp fangs. This may also make the target flinch.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Dark";
		this.statusEffect = "Flinched";
		this.statusChance = 0.33;
	}
}