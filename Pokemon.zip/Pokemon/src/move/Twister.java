package move;

public class Twister extends Move {
	
	public Twister() {
		this.name = "Twister";
		this.description = "The user whips up a vicious tornado to tear at the opposing Pokémon. This may also make them flinch.";

		this.power = 40;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Dragon";
		this.statusEffect = "Flinched";
		this.statusChance = 0.25;
	}
}