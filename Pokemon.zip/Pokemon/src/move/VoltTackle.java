package move;

public class VoltTackle extends Move {
	
	public VoltTackle() {
		this.name = "VoltTackle";
		this.description = "The user electrifies itself and charges the target. This also damages the user quite a lot. This attack may leave the target with paralysis.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = .33;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 35;
		this.maxPP = 35;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.1;
	}
}