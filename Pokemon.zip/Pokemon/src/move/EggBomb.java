package move;

public class EggBomb extends Move {
	
	public EggBomb() {
		super();
		this.name = "EggBomb";
		this.description = "A large egg is hurled at the target with maximum force to inflict damage.";

		this.power = 100;
		this.accuracy = 0.75;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 10;
		this.maxPP = 10;

		this.type = "Normal";
		this.statusEffect = "None";
		this.statusChance = 0;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}