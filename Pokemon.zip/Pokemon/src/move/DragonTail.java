package move;

public class DragonTail extends Move {
	
	public DragonTail() {
		this.name = "DragonTail";
		this.description = "The target is knocked away with a strong, elongated tail. This may leave the target burned.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Dragon";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
}