/**
 * Its a great ball.
 * @author
 * @version 1.00.00
 */

package item;

import main.*;
import pokemon.*;


public class GreatBall extends PokeBall {
	

	public GreatBall() {
		super();
		this.name = "Great Ball";
		this.description = "A better Pokeball.";
		successRate = 0.5;
	}

	public GreatBall(int q) {
		super(q);
		this.name = "Great Ball";
		this.description = "A better Pokeball.";
		successRate = 0.5;
	}




}