/**
 * Defines the starting application window for Pokemon.
 * @author 
 * @version 1.00.00
 */
package main;
import battlemap.*;
import pokemon.*;
import character.*;

import java.util.*;

import javafx.application.*;
import javafx.animation.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.*;

import javafx.scene.input.*;

import javafx.util.*;
import javafx.geometry.*;
import javafx.event.*;


public class BattleMapTester extends Application {
	

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		BattleMap bm = new BattleMap(900,600);
		// root.setStyle("-fx-background-color: Black;");
		Pikachu p = new Pikachu();
		bm.setWildPokemon(new Player(),p);
		p.setHealth(1);
		bm.updateInfo();

		root.setCenter(bm.generateBody());

		Scene scene = new Scene(root);
		
		primaryStage.setScene(scene);
		primaryStage.setTitle("Pokemon: The Original Rip-Off Version");
		primaryStage.setResizable(false);
		primaryStage.sizeToScene();
		primaryStage.show();
	}
}