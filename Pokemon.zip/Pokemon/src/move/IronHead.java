package move;

public class IronHead extends Move {
	
	public IronHead() {
		this.name = "IronHead";
		this.description = "The user slams the target with its steel-hard head. This may also make the target flinch.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Steel";
		this.statusEffect = "Flinched";
		this.statusChance = 0.3;
	}
}