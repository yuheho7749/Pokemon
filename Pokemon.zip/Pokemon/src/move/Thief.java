package move;

public class Thief extends Move {
	
	public Thief() {
		this.name = "Thief";
		this.description = "The user attacks and steals the target's dignity item simultaneously. ";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 25;
		this.maxPP = 25;

		this.type = "Dark";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}