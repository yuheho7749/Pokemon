package pokemon;

import move.*;
import item.*;
import javafx.scene.layout.*;
import javafx.scene.image.*;

public class Spiritomb extends Pokemons{
	
	public Spiritomb(){
		super();
		this.name = "Spiritomb";
		this.body = new Pane();
		pokeball = new PokeBall();
		this.type[0] = "Ghost";
		this.type[1] = "Dark";
		
		this.moveSet[0] = new Struggle();
		
		//set base stats
        this.bHp = 50;this.bAtk = 92;this.bDef = 108;
        this.bSpAtk = 92;this.bSpDef = 108;this.bSpd = 35;
		//set ev stats = 0
		this.evHp = 0;this.evAtk = 0;this.evDef = 0;this.evSpAtk = 0;this.evSpDef = 0;this.evSpd = 0;
		this.health = hp;
		finalStatCalc();
		assignRandomMove();
		createInboxSprite();
		
		
	}
	
	@Override
	public void createInboxSprite(){
		ImageView i = new ImageView("file:res/pokemon/spiritomb.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		inboxSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/spiritomb.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		battleSprite.getChildren().add(i);
		
		i = new ImageView("file:res/pokemon/spiritomb.png");
		i.setFitWidth(80);
		i.setFitHeight(80);
		body.getChildren().add(i);
		
	}

	public void update(){}
}

