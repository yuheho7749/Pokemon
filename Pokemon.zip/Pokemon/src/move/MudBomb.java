package move;

public class MudBomb extends Move {
	
	public MudBomb() {
		this.name = "MudBomb";
		this.description = "The user launches a hard-packed mud ball to attack. This may also confuse the target.";

		this.power = 65;
		this.accuracy = .85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "Confused";
		this.statusChance = 0.2;
	}
}