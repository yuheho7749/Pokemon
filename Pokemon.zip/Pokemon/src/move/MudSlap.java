package move;

public class MudSlap extends Move {
	
	public MudSlap() {
		this.name = "MudSlap";
		this.description = "The user hurls mud in the target's face to inflict damage";

		this.power = 20;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Ground";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}