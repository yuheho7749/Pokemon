package move;

public class HornLeech extends Move {
	
	public HornLeech() {
		this.name = "HornLeech";
		this.description = "The user drains the target's energy with its horns. ";

		this.power = 75;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Healed";
		this.statusChance = 1;
	}
}