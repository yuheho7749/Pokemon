package move;

public class Inferno extends Move {
	
	public Inferno() {
        this.name = "Inferno";
		this.description = "The user attacks by engulfing the target in an intense fire. This leaves the target with a burn.";

		this.power = 100;
		this.accuracy = .5;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 5;
		this.maxPP = 5;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 1;
	}
} 