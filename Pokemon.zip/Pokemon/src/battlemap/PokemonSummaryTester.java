/**
 * Defines the starting application window for Pokemon.
 * @author 
 * @version 1.00.00
 */
package main;
import battlemap.*;
import pokemon.*;
import character.*;

import java.util.*;

import javafx.application.*;
import javafx.animation.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.*;

import javafx.scene.input.*;

import javafx.util.*;
import javafx.geometry.*;
import javafx.event.*;


public class PokemonSummaryTester extends Application {
	public static void main(String[] args) {
		launch(args);
		
	}

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		// root.setStyle("-fx-background-color: Black;");
		Trainer t = new Player();
		Pikachu p = new Pikachu();
		PokemonSummary sum = new PokemonSummary(p);
		p.setHealth(1);
		Pane body = sum.getSummary();
		sum.updateHealth();
		
		root.setCenter(body);
		
		Scene scene = new Scene(root);
		
		primaryStage.setScene(scene);
		primaryStage.setTitle("Pokemon: The Original Rip-Off Version");
		primaryStage.setResizable(false);
		primaryStage.sizeToScene();
		primaryStage.show();
	}
}