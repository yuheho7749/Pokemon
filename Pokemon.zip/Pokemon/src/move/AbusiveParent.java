package move;

public class AbusiveParent extends Move {
	
	public AbusiveParent() {
		this.name = "AbusiveParent";
		this.description = "Why aren't you a doctor yet?";
		this.priority = true;

		this.power = Integer.MAX_VALUE;
		this.accuracy = Integer.MAX_VALUE;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = Integer.MAX_VALUE;
		this.maxPP = Integer.MAX_VALUE;

		this.type = "Nope";
		this.statusEffect = "Abused";
		this.statusChance = 1;
	}
}