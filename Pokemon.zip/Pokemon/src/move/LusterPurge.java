package move;

public class LusterPurge extends Move {
	
	public LusterPurge() {
		this.name = "LusterPurge";
		this.description = "The user lets loose a damaging burst of light. This may also confuse the target.";

		this.power = 70;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Psychic";
		this.statusEffect = "Confused";
		this.statusChance = 0.3;
	}
}