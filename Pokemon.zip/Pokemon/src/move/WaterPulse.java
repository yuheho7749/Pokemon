package move;

public class WaterPulse extends Move {
	
	public WaterPulse() {
        this.name = "WaterPulse";
		this.description = "The user attacks the target with a pulsing blast of water. This may also confuse the target.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 20;
		this.maxPP = 20;

		this.type = "Water";
		this.statusEffect = "Confused";
		this.statusChance = 0.2;
	}
}