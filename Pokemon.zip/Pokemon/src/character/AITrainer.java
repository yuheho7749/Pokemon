package character;

import pokemon.*;
import move.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class AITrainer extends Trainer{
	protected Pane body = new Pane();
	public AITrainer(){
		this.name = "Bob";
		party.add(new Snivy());
		party.add(new Charmander());
		party.add(new Froakie());
		body.getChildren().add(new Rectangle(200,100,Color.BLACK));
	}
	
	public Pane getBody(){return body;}
	
	public Pokemons sendPokemon(){
		for(int i=0;i<party.size();i++){
			if(party.get(i).getHealth()!=0){
				return party.get(i);
			}
		}
		return null;
	}
	
	public Move takeTurn(Pokemons currentPokemon) {
		return currentPokemon.getMoveSet()[(int)(Math.random()*((4-1)+1)+1)]; // temporary
	}
}