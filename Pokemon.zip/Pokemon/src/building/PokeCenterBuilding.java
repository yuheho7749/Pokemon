/**
 * Defines the outside images of the Pokemon Center.
 * @author
 * @version 1.00.00
 */

package building;

import main.*;
import character.*;
import tile.*;

import java.util.ArrayList;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.transform.*;

public class PokeCenterBuilding extends Building {
	public PokeCenterBuilding() {
		super();
		this.name = "PokeCenterBuilding";
		this.width = 7;
		this.height = 5;
		this.body.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR);


		// this can be replaced with actual picture later instead of background color only
		// temp design
		StackPane pokeballDesign = new StackPane();
		pokeballDesign.setPrefSize(width * Entity.SCALEFACTOR, height * Entity.SCALEFACTOR * .8);
		Circle ball = new Circle(Entity.SCALEFACTOR * 1.5);
		ball.setFill(Color.RED);
		Rectangle strip = new Rectangle(Entity.SCALEFACTOR * 3, Entity.SCALEFACTOR);
		strip.setFill(Color.WHITE);
		Circle button = new Circle(Entity.SCALEFACTOR * .5);
		button.setFill(Color.GRAY);
		pokeballDesign.getChildren().addAll(ball, strip, button);
		this.body.getChildren().add(pokeballDesign);



		this.body.setStyle(this.body.getStyle() + "-fx-background-color: Brown;");
		

		// create tile and barriers
		for (int i = 0; i < width; i ++) {
			for (int j = 0; j < height; j ++) {
				if (!(i == 3 && j == 4)) {
					this.setTile(new Barrier(), i, j);
				}
			}
		}
		
		
		// this.setTile(new WarpTile("PokeCenter", 5, 8), 3, 4);
		// this.setTile(wt, x, y);

	}
}