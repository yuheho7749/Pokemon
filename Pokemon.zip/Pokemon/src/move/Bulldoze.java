package move;

public class Bulldoze extends Move {
	
	public Bulldoze() {
		this.name = "Bulldoze";
		this.description = "The user strikes everything around it by stomping down on the ground. This may flinch the target.";

		this.power = 60;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Ground";
		this.statusEffect = "Flinched";
		this.statusChance = 0.2;
	}
}