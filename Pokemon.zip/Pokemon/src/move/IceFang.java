package move;

public class IceFang extends Move {
	
	public IceFang() {
		this.name = "IceFang";
		this.description = "	The user bites with cold-infused fangs. This may also make the target flinch or leave it frozen.";

		this.power = 65;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 15;
		this.maxPP = 15;

		this.type = "Ice";
		this.statusEffect = "Frozen";
		this.statusChance = 0.3;
	}
}