package move;

public class Twineedle extends Move {
	
	public Twineedle() {
		this.name = "Twineedle";
		this.description = "The user damages the target twice in succession by jabbing it with two spikes. This may also poison the target.";

		this.power = 25;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Bug";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.5;
	}
}