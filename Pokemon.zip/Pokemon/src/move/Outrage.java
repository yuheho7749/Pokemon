package move;

public class Outrage extends Move {
	
	public Outrage() {
		this.name = "Outrage";
		this.description = "The user rampages and attacks with all its might.";

		this.power = 120;
		this.accuracy = 1;
		this.recoil = 0.25;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Dragon";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}