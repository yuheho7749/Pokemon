package move;

public class Megahorn extends Move {
	
	public Megahorn() {
		this.name = "Megahorn";
		this.description = "Using its tough and impressive horn, the user rams into the target with no letup.";

		this.power = 120;
		this.accuracy = .85;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Bug";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}