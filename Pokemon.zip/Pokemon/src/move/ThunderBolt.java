package move;

public class ThunderBolt extends Move {
	
	public ThunderBolt() {
		super();
		this.name = "ThunderBolt";
		this.description = "A strong electric blast is loosed at the foe. It may also leave the foe paralyzed.";

		this.power = 90;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Electric";
		this.statusEffect = "Paralyzed";
		this.statusChance = 0.1;
	}

	@Override
	public void moveEffect() {
		super.moveEffect();
	}
}