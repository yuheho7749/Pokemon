package move;

public class DracoMeteor extends Move {
	
	public DracoMeteor() {
		this.name = "DracoMeteor";
		this.description = "	Comets are summoned down from the sky onto the target. ";

		this.power = 200;
		this.accuracy = 1.9;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = false;
		this.priority = false;

		this.pp = 5;
		this.maxPP = 5;

		this.type = "Dragon";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}