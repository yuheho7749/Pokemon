package move;

public class FireFang extends Move {
	
	public FireFang() {
        this.name = "FireFang";
		this.description = "The user bites with flame-cloaked fangs. This may also leave the target with a burn.";

		this.power = 65;
		this.accuracy = .95;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		
		this.pp = 15;
		this.maxPP = 15;

		this.type = "Fire";
		this.statusEffect = "Burned";
		this.statusChance = 0.3;
	}
} 