package move;

public class Submission extends Move {
	
	public Submission() {
		this.name = "Submission";
		this.description = "The user grabs the target and recklessly dives for the ground. This also damages the user a little.";

		this.power = 80;
		this.accuracy = 0.8;
		this.recoil = 0.1;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Fighting";
		this.statusEffect = "None";
		this.statusChance = 0;
	}
}