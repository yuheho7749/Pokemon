package move;

public class SolarBlade extends Move {
	
	public SolarBlade() {
		this.name = "SolarBlade";
		this.description = "The user gathers light and fills a blade with the light's energy, attacking and burning the target.";

		this.power = 175;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 10;
		this.maxPP = 10;

		this.type = "Grass";
		this.statusEffect = "Burned";
		this.statusChance = 1;
	}
}