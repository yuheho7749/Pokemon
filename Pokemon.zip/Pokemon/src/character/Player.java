/**
 * Defines the structure of the player.
 * @author 
 * @version 1.00.00
 */

package character;

import main.*;
import pokemon.*;
import item.*;

import javafx.scene.image.*;
import javafx.scene.shape.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;


public class Player extends Trainer {
	private Bag bagView;
	private PokemonMenu partyMenu;
	
	public Player() {
		super();
		this.name = "Player";


		// testing
		Pokemons testPikachu = new Pikachu();

		// testing mathew level up health error
		// System.out.println(testPikachu.getHealth() + "/"+ testPikachu.getHp() + "=" + ((double)testPikachu.getHealth()/testPikachu.getHp()));
		// testPikachu.setHealth((int)(testPikachu.getHealth() * .75));
		// System.out.println(testPikachu.getHealth() + "/"+ testPikachu.getHp() + "=" + ((double)testPikachu.getHealth()/testPikachu.getHp()) + "\n");
		for(int i=0;i<30;i++){
			testPikachu.levelUp();
			// System.out.println(testPikachu.getHealth() + "/"+ testPikachu.getHp() + "=" + ((double)testPikachu.getHealth()/testPikachu.getHp()));
		}
		// testPikachu.setHealth((int)(testPikachu.getHealth() * Math.random()));

		this.party.add(testPikachu);
		

		
		// testing items
		this.pokeballs.add(new PokeBall());
		this.pokeballs.add(new MasterBall());
		this.pokeballs.add(new UltraBall());
		this.medicines.add(new Potion());
		this.medicines.add(new FullRestore());
		this.medicines.add(new MaxPotion());
		



		// making the bag after adding items
		this.bagView = new Bag(this);
		// make the pokemon party view
		this.partyMenu = new PokemonMenu(this);
		
		
		
		// design for looking up
		for (int i = 0; i < 4; i ++) {
			ImageView image = new ImageView("file:res/player/LookingUp" + i + ".png");
			image.setFitWidth(Entity.SCALEFACTOR * .8);
			image.setFitHeight(Entity.SCALEFACTOR * .8);
			image.setLayoutX(Entity.SCALEFACTOR * .1);
			image.setLayoutY(Entity.SCALEFACTOR * .1);
			image.setCache(true);
			Pane design = new Pane();
			design.getChildren().add(image);
			this.lookingUp[i] = design;
		}

		// design for looking down
		for (int i = 0; i < 4; i ++) {
			ImageView image = new ImageView("file:res/player/LookingDown" + i + ".png");
			image.setFitWidth(Entity.SCALEFACTOR * .8);
			image.setFitHeight(Entity.SCALEFACTOR * .8);
			image.setLayoutX(Entity.SCALEFACTOR * .1);
			image.setLayoutY(Entity.SCALEFACTOR * .1);
			image.setCache(true);
			Pane design = new Pane();
			design.getChildren().add(image);
			this.lookingDown[i] = design;
		}

		// design for looking left
		for (int i = 0; i < 4; i ++) {
			ImageView image = new ImageView("file:res/player/LookingLeft" + i + ".png");
			image.setFitWidth(Entity.SCALEFACTOR * .8);
			image.setFitHeight(Entity.SCALEFACTOR * .8);
			image.setLayoutX(Entity.SCALEFACTOR * .1);
			image.setLayoutY(Entity.SCALEFACTOR * .1);
			image.setCache(true);
			Pane design = new Pane();
			design.getChildren().add(image);
			this.lookingLeft[i] = design;
		}

		// design for looking right
		for (int i = 0; i < 4; i ++) {
			ImageView image = new ImageView("file:res/player/LookingRight" + i + ".png");
			image.setFitWidth(Entity.SCALEFACTOR * .8);
			image.setFitHeight(Entity.SCALEFACTOR * .8);
			image.setLayoutX(Entity.SCALEFACTOR * .1);
			image.setLayoutY(Entity.SCALEFACTOR * .1);
			image.setCache(true);
			Pane design = new Pane();
			design.getChildren().add(image);
			this.lookingRight[i] = design;
		}


		this.body.getChildren().add(lookingDown[0]);
		this.lookDown = true;
	}

	public Bag getBagView(){return bagView;}
	
	public PokemonMenu getPartyMenu() {return partyMenu;}
	public void setPartyMenu(PokemonMenu p) {partyMenu = p;}
	


}