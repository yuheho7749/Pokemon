package move;

public class PoisonJab extends Move {
	
	public PoisonJab() {
		this.name = "PoisonJab";
		this.description = "	The target is stabbed with a tentacle or arm steeped in poison. This may also poison the target.";

		this.power = 80;
		this.accuracy = 1;
		this.recoil = 0;
		this.isAttack = true;
		this.isPhysical = true;
		this.priority = false;

		this.pp = 20;
		this.maxPP = 20;

		this.type = "Poison";
		this.statusEffect = "Poisoned";
		this.statusChance = 0.2;
	}
}